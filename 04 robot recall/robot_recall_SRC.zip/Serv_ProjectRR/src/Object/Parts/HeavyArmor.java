package Object.Parts;

import Item.Barrier;
import Object.Projectile.Ammo;
import Object.Projectile.MGAmmo;
import Object.Projectile.Projectile;

public class HeavyArmor extends Top{

	public HeavyArmor(int modelNum, int maxHP, int skillDelay, int maxSkill) {
		// TODO Auto-generated constructor stub
		super(modelNum);
	
		this.width = 110;
		this.height = 64;
		
		this.skillDelay = skillDelay;
		this.skillStart = skillDelay;
		this.maxSkill = maxSkill;
		this.maxHP = maxHP;
		this.curSkill = this.maxSkill;
		this.HP = this.maxHP;
		
		weight =2;
		
		
	}



	public boolean update() {
		if (skillStart < skillDelay)
			skillStart++;
		return false;
	}

	// for single mode command
	public void skill() {
		if (curSkill<= 0 || skillStart < skillDelay) {
			return;
		}
		if (foward)
			myChannel.accountObj(team,Barrier.OBJTYPE, x+100, y-50,foward);
		else
			myChannel.accountObj(team,Barrier.OBJTYPE, x-100, y-50,foward);
		curSkill--;
		skillStart = 0;
	}
	
	@Override
	public void isShoot(Projectile other) {
		// TODO Auto-generated method stub
		int dmg = other.getDmg();
		
		if(other instanceof Ammo)
		{
			dmg *= 1.3;
		}
		else if(other instanceof MGAmmo)
		{
			dmg *= 0.75;
			if(dmg==0) dmg = 1;
		}

		
		HP = HP - dmg;
		myChannel.getCaster().sendPak4(other.getMother().id,this.id,dmg,other.getVib(),false);
		
		//score account
		if(other.myChannel.getUser(other.getMother().id)!=null)
			other.myChannel.getUser(other.getMother().id).deal += dmg;
		if(HP<=0)
			other.myChannel.getUser(other.getMother().id).kill++;
		
	}
}
