package Object.Parts;

import Object.Projectile.Ammo;

public class MachineGun extends Weapon {
	static int runout[];
	int runoutIndex;
	int totShot;

	public MachineGun(int modelNum, int maxBullet, int shotDelay, int reloadDelay, int range, int damage, int totShot) {
		super(modelNum);
		this.reloadStartTime = 0;
		this.maxAngle = 50;
		this.minAngle = 50;
		this.shotLock = false;

		runout = new int[5];
		for(int i=0;i<5;i++)
			if(i%2 ==0)
				runout[i] = i*2;
			else
				runout[i] = -(i*2-1);
		
		runoutIndex =0;
		
		this.range = range;
		this.damage = damage;
		this.maxBullet = maxBullet;
		this.curBullet = this.maxBullet;
		this.shotDelay = shotDelay;
		this.shotStart = shotDelay;
		this.reloadDelay = reloadDelay;
		this.totShot = totShot;
		
		weight = 1;
	}

	@Override
	public void spinAngle(boolean pos) {
		// check angle bound
		if (curAngle > 50) {
			curAngle = 50;
		} else if (curAngle < -50) {
			curAngle = -50;
		}

		// up pos, down neg
		if (pos) {
			this.curAngle -= 2;
		} else {
			this.curAngle += 2;
		}
	}
	
	@Override
	public boolean canShot(){
		// delay
		if (shotStart < shotDelay) {
			return false;
		}
		// shotLock
		if (shotLock) {
			return false;
		}
		return true;
	}
	
	@Override
	public void shot() {
		
		// angle, start xy, team, damage
		int tmpAngle = curAngle;
		if (!foward) {
			if (tmpAngle == 0) {
				tmpAngle += 180;
			} else if (tmpAngle < 0) {
				tmpAngle = 180 - tmpAngle;
			} else if (curAngle > 0) {
				tmpAngle = (180 - tmpAngle);
			}	
		}
		int tmpShotX = foward? shotX : shotX +10;
		int tmpShotY = 0;
		
		if(tmpAngle ==0 || tmpAngle==180)
		{
			tmpShotY =  shotY;
		}
		else if(tmpAngle >180 || tmpAngle<0) 
		{
			if(master.getBottom() instanceof Copter)
				tmpShotY = shotY - 10;
			else
				tmpShotY = shotY;
		}
		else
		{
			if(master.getBottom() instanceof Copter)
				tmpShotY = shotY +13;
			else
				tmpShotY = shotY+10;
		}
		
		for(int i=0;i<totShot;i++)
		{
			if( runoutIndex == 4 ) runoutIndex = 0;
			else runoutIndex +=1;
			myChannel.getProjList().add(new Ammo(myChannel,this,curBullet,range, tmpAngle + runout[runoutIndex], tmpShotX,tmpShotY,team, damage, true,i*2+1));
			curBullet--;
		}
		shotStart = 0;
		
		// reload
		if (!shotLock && curBullet == 0) {
			setReload();
			return;
		}
		
	}

	
	@Override
	public boolean update() {
		if (shotLock) {
			reloadStartTime++;
		}
		if (reloadStartTime >= reloadDelay) {
			reload();
		}
		if(shotStart < shotDelay)
			shotStart++;
		

		return false;
	}

}