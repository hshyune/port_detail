package Object.Parts;

import java.awt.Graphics2D;


public class Copter extends Bottom{
	public Copter(int modelNum, int mvSpeed, int weight, float jump) {
		super(modelNum);
		// set State Idle
		foward = true;
		jumpLock = false;

		vX = 0;
		vY = 0;
		state = IDLE;

		this.width = 150;
		this.height = 55;
		//System.out.println(width + " " + height);
		
		this.jumpPower = (int)(height * jump);
		this.mvSpeed = mvSpeed;
		this.weight = weight;
	}

	
	@Override
	public void setStMove() {
		state = MOVE;
	}
	
	@Override
	public void setStJump(boolean dirjump) {
		if (dirjump) {
			System.out.println("dir");
			state = DIR_JUMP;
		} else {
			state = JUMP;
		}
	}
	@Override
	public void setStJumpDown() {
		jumpLock = false;
		state = JUMP_DOWN;
	}

	@Override
	protected void jump(boolean dirjump) {
		if (dirjump) {
			if (foward) {
				vX += mvSpeed;
			} else {
				vX -= mvSpeed;
			}
		}
		
		vY = -7;
		jumpCur -= vY;
		setStJumpDown();
	}
	
	@Override
	public void move() {
		
		if(foward)
		{
			vX += mvSpeed;
		}
		else
		{
			vX -= mvSpeed;
		}
		
		if(isFloating())
		{
			vY = 5;
			
			int landY = getLandingPoint();
	
			if (landY != 0) {
				vY = landY - (y + height);
			}
		}
		setStIdle();
	}
	
	@Override
	public void jumpDown() {

		vY = 5;
		
		int landY = getLandingPoint();

		if (landY != 0) {
			vY = landY - (y + height);
			setStIdle();
		}
	}

	@Override
	public boolean update() {
		// TODO Auto-generated method stub
		
		
		
		if(jumpCur >= jumpPower){
			this.setStJumpDown();
		}
		if(!isFloating() && jumpCur>0)
			jumpCur -= 5;

		setLocation(x + vX, y + vY);

		vX = 0;
		vY = 0;

		switch (state) {
		case IDLE:
			idle();
			break;
		case MOVE:
			move();
			break;
		case JUMP:
			jump(false);
			break;
		case DIR_JUMP:
			jump(true);
			break;
		case JUMP_DOWN:
			jumpDown();
			break;
		}
		
		
		if (isFloating() && state < JUMP) {
			jumpLock = true;
			setStJumpDown();
		}
		
		
		return false;
		
	}
}
