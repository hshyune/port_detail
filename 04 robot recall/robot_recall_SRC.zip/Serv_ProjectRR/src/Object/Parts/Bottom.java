package Object.Parts;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Collections;

import Object.Container;
import Object.GameObject;
import Object.Land;
import Interfaces.*;

public class Bottom extends GameObject implements Dropable {

	protected Container master;
	protected int modelNum;
	
	protected boolean foward, jumpLock;
	protected int mvSpeed, jumpPower, jumpCur;
	protected int vX, vY;
	protected int state, weight, maxWeight;

	public final static int IDLE = 0;
	public final static int MOVE = 1;
	public final static int JUMP = 2;
	public final static int DIR_JUMP = 3;
	public final static int JUMP_DOWN = 4;

	public Bottom(int modelNum) {
		// set State Idle
		this.modelNum = modelNum;
		foward = true;
		jumpLock = false;
		mvSpeed = 5;
		vX = 0;
		vY = 0;
		state = IDLE;
		jumpCur = 0;
		jumpPower = 100;
		this.width = 50;
		this.height = 50;
	}

	// getter
	public boolean getJumpLock() {
		return this.jumpLock;
	}
	public void setJumpLock(boolean lock)
	{
		jumpLock = lock;
	}

	// set State method
	public void setDir(boolean foward) {
		this.foward = foward;
	}

	public void setStIdle() {
		state = IDLE;
		this.jumpLock = false;
	}

	public void setStMove() {
		if(this.jumpLock)
			return;
		state = MOVE;
	}

	public void setStJump(boolean dirjump) {
		this.jumpLock = true;
		if (dirjump) {
			state = DIR_JUMP;
		} else {
			state = JUMP;
		}
		jumpCur = jumpPower;
	}

	public void setStJumpDown() {
		state = JUMP_DOWN;
		jumpCur = 0;
	}

	// do state method
	protected void idle() {
		vX = 0;
		vY = 0;
	}

	protected void move() {
		if (foward) {
			vX += mvSpeed;
		} else {
			vX -= mvSpeed;
		}
		setStIdle();
	}

	protected void jump(boolean dirjump) {
		if (dirjump) {
			if (foward) {
				vX += mvSpeed;
			} else {
				vX -= mvSpeed;
			}
		}

		jumpCur = (jumpCur / 2) - 1;
		vY -= jumpCur;

		if (jumpCur <= 0) {
			setStJumpDown();
		}
	}

	@Override
	public void jumpDown() {
		jumpCur = (jumpCur * 2) + 1;
		vY += jumpCur;

		int landY = getLandingPoint();

		if (landY != 0) {
			vY= landY - (y + height);
			setStIdle();
			jumpCur = jumpPower;

		}
	}

	@Override
	public boolean update() {
		// TODO Auto-generated method stub
		

		switch (state) {
		case IDLE:
			idle();
			break;
		case MOVE:
			move();
			break;
		case JUMP:
			jump(false);
			break;
		case DIR_JUMP:
			jump(true);
			break;
		case JUMP_DOWN:
			jumpDown();
			break;
		}

		if (isFloating() && state < JUMP) {
			jumpLock = true;
			setStJumpDown();
		}
		
		setLocation(x + vX, y + vY);
		
		vX = 0;
		vY = 0;
		

		return false;
	}

	@Override
	public boolean isFloating() {
		Line2D underLine = new Line2D.Float(x, (y + height + 1), x + width, (y + height + 1));
		ArrayList<GameObject> map = myChannel.getObjList();
		for (GameObject tmp : map) {
			if (tmp instanceof Land) {
				if (((Land) tmp).getBound().intersectsLine(underLine)) {
					return false;
				}
			}
		}
		return true;
	}

	@Override
	public int getLandingPoint() {
		ArrayList<GameObject> map = myChannel.getObjList();
		ArrayList<Land> lands = new ArrayList<Land>();
		Rectangle2D nextPhase = new Rectangle2D.Float(x, y+height , width, vY);
		for (GameObject tmp : map) {
			if (tmp instanceof Land) {
				if (((Land) tmp).getTopLine().intersects(nextPhase)) {
					lands.add((Land) tmp);
				}
			}
		}

		int min = 10000;
		if (lands.size() != 0) {
			for (Land tmp : lands) {
				if (tmp.getTopLine().getY1() < min)
					min = (int) (tmp.getTopLine().getY1());
			}
			return min;
		}

		return 0;
	}
	
	public int getModelNum()
	{
		return modelNum;
	}
	
	public void setMaster(Container master)
	{
		this.master = master;
	}
	
	public int getWeight()
	{
		return weight;
	}

}
