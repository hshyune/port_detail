package Object.Parts;

import Object.Projectile.MGAmmo;
import Object.Projectile.Missle;
import Object.Projectile.Projectile;

public class FlateArmor extends Top {

	private boolean isFlame;
	
	public FlateArmor(int modelNum,int maxHP, int skillDelay, int maxSkill) {
		// TODO Auto-generated constructor stub
		super(modelNum);
		this.width = 119;
		this.height = 82;
		this.isFlame = false;
		
		
		this.skillDelay = skillDelay;
		this.skillStart = skillDelay;
		this.maxSkill = maxSkill;
		this.maxHP = maxHP;
		this.curSkill = this.maxSkill;
		this.HP = this.maxHP;
		
		weight =3;
		
	}
	@Override
	public boolean update() {
		if (isFlame) {
			if(skillStart >= 60){
				master.getWeapon().enforce(false);
				isFlame = false;
			}
		}
		if(skillStart<skillDelay)
			skillStart++;
		return false;
	}
	@Override
	public void skill() {
		if (isFlame) {
			return;
		}
		if (curSkill<= 0 || skillStart < skillDelay) {
			return;
		}
		// set damage increment
		isFlame = true;
		curSkill--;
		skillStart=0;
		master.getWeapon().enforce(true);
	}
	
	@Override
	public void isShoot(Projectile other) {
		// TODO Auto-generated method stub
		int dmg = other.getDmg();
		
		if(other instanceof Missle)
		{
			dmg *= 1.3;
		}
		else if(other instanceof MGAmmo)
		{
			dmg *= 0.75;
			if(dmg==0) dmg = 1;
		}

		
		HP = HP - dmg;
		myChannel.getCaster().sendPak4(other.getMother().id,this.id,dmg,other.getVib(),false);

		//score account
		if(other.myChannel.getUser(other.getMother().id)!=null)
			other.myChannel.getUser(other.getMother().id).deal += dmg;
		if(HP<=0)
			other.myChannel.getUser(other.getMother().id).kill++;
	}
	
}
