package Object.Parts;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;


public class Biwalk extends Bottom {

	public Biwalk(int modelNum, int mvSpeed, int weight, float jump) {
		super(modelNum);
		// set State Idle
		foward = true;
		jumpLock = false;
		vX = 0;
		vY = 0;
		state = IDLE;

		this.width = 47;
		this.height = 46;
		this.jumpPower = (int)(height * jump);
		this.mvSpeed = mvSpeed;
		this.weight = weight;
	}


}
