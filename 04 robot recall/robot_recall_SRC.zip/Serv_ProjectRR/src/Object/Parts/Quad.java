package Object.Parts;

public class Quad extends Bottom {

	public Quad(int modelNum, int mvSpeed, int weight, float jump) {
		
		super(modelNum);

		// set State Idle
		foward = true;
		jumpLock = false;
		vX = 0;
		vY = 0;
		state = IDLE;

		this.width = 124;
		this.height = 56;
		this.jumpPower = (int)(height * jump);
		this.mvSpeed = mvSpeed;
		this.weight = weight;
	}

	

}
