package Object.Parts;

import Object.Projectile.Missle;

public class Rocket extends Weapon {
	public Rocket(int modelNum, int maxBullet, int shotDelay, int reloadDelay, int range, int damage) {
		super(modelNum);
		this.reloadStartTime = 0;
		this.maxAngle = 50;
		this.minAngle = 50;
		this.shotLock = false;
		
		this.range = range;
		this.damage = damage;
		this.maxBullet = maxBullet;
		this.curBullet = this.maxBullet;
		this.shotDelay = shotDelay;
		this.shotStart = shotDelay;
		this.reloadDelay = reloadDelay;
		
		weight = 3;
	}

	public void spinAngle(boolean pos) {
		// check angle bound
		if (curAngle > 50) {
			curAngle = 50;
		} else if (curAngle < -50) {
			curAngle = -50;
		}

		// up pos, down neg
		if (pos) {
			this.curAngle -= 1;
		} else {
			this.curAngle += 1;
		}
	}

	
	@Override
	public boolean canShot(){
		// delay
		if (shotStart < shotDelay) {
			return false;
		}
		// shotLock
		if (shotLock) {
			return false;
		}
		return true;
	}
	@Override
	public void shot() {
		
		
		

		// angle, start xy, team, damage
		int tmpAngle = curAngle - curAngle%10;
		if (!foward) {
			if (tmpAngle == 0) {
				tmpAngle += 180;
			} else if (tmpAngle < 0) {
				tmpAngle = 180 - tmpAngle;
			} else if (curAngle > 0) {
				tmpAngle = (180 - tmpAngle);
			}
			
		}
		int tmpShotX = foward? shotX : shotX +10;
		int tmpShotY = 0;
		
		if(tmpAngle ==0 || tmpAngle==180)
		{
			tmpShotY =  shotY;
		}
		else if(tmpAngle >180 || tmpAngle<0) 
		{
			if(master.getBottom() instanceof Copter)
				tmpShotY = shotY - 10;
			else
				tmpShotY = shotY;
		}
		else
		{
			if(master.getBottom() instanceof Copter)
				tmpShotY = shotY +13;
			else
				tmpShotY = shotY+10;
		}
		myChannel.getProjList().add(new Missle(myChannel,this,curBullet,range,tmpAngle, tmpShotX, tmpShotY, team, damage,0));
		curBullet--;
		shotStart = 0;
		
		// reload
		if (!shotLock && curBullet == 0) {
			setReload();
			return;
		}
		
	}
	
	


	public boolean update() {
		if (shotLock) {
			reloadStartTime++;
		}
		if (reloadStartTime >= reloadDelay) {
			reload();
		}
		if(shotStart < shotDelay)
			shotStart++;
		// set shot X Y
		

		return false;
	}

	public void reload() {
		curBullet = maxBullet;
		reloadStartTime = 0;
		shotLock = false;
	}
}
