package Object.Parts;

import Interfaces.Hitable;
import Item.HealPack;
import Object.Container;
import Object.GameObject;
import Object.Projectile.Projectile;
import pkg.GameChannel;

public class Top extends GameObject implements Hitable {
	
	protected Container master;
	protected int modelNum;
	
	int weight;
	protected boolean foward;
	protected int skillDelay;
	protected int skillStart;
	protected int curSkill;
	protected int maxSkill;
	
	Top(int modelNum) {
		this.modelNum = modelNum;
		this.maxHP = 100;
		this.HP = maxHP;
		this.foward = true;

	}

	public void setDir(boolean foward) {
		this.foward = foward;
	}


	@Override
	public boolean update() {
		// TODO Auto-generated method stub
		return false;
	}
	
	public int getDmg() {
		return 0;
	}

	@Override
	public boolean isCollision(GameObject other) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void isShoot(Projectile other) {
		// TODO Auto-generated method stub
		HP = HP - other.getDmg();
	}
	
	public void isHeal(HealPack heal) {
		// TODO Auto-generated method stub
		
		if (HP + heal.getHeal() >= maxHP) {
			HP = maxHP;
		} else {
			HP = HP + heal.getHeal();
		}
		myChannel.getCaster().sendPak4(heal.id,this.id,heal.getHeal(),0,true);
	}

	public void skill() {

	}
	
	public void repair()
	{
		HP = maxHP;
		curSkill = maxSkill;
	}
	
	public int getModelNum()
	{
		return modelNum;
	}
	
	public void setMaster(Container master)
	{
		this.master = master;
	}
	
	public int getWeight()
	{
		return weight;
	}

}
