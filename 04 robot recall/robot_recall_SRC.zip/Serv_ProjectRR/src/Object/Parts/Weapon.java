package Object.Parts;



import Object.Container;
import Object.GameObject;

public abstract class Weapon extends GameObject {

	protected Container master;
	protected int modelNum;
	
	protected long shotStart, shotDelay, reloadDelay, reloadStartTime;
	protected int maxAngle, minAngle, curAngle;
	protected int maxBullet, curBullet;
	protected int weight, damage;
	protected int shotX, shotY;
	protected boolean shotLock, foward;
	protected int range;	

	public Weapon(int modelNum) {
		this.modelNum = modelNum;
		this.shotDelay = 0;
		this.reloadDelay = 0;
		this.reloadStartTime = 0;
		this.maxAngle = 50;
		this.minAngle = -50;
		this.curAngle = 0;
		this.weight = 0;
		this.shotLock = false;
		this.maxBullet = 15;
		this.curBullet = maxBullet;
		this.foward = true;
		shotX = x;
		shotY = y;
	}


	@Override
	public boolean update() {
	// TODO Auto-generated method stub
		return false;
	}

	abstract public boolean canShot();
	abstract public void shot();
	
	public void spinAngle(boolean pos) {
		if (pos) {
			this.curAngle -= 2;
		} else {
			this.curAngle += 2;
		}
	}
	
	public int getAngle() {
		return this.curAngle;
	}
	
	public void setAngle(int angle){
		this.curAngle = angle;
	}

	public void setDir(boolean foward) {
		this.foward = foward;
	}

	public void setReload() {
		this.shotLock = true;
		this.reloadStartTime = 0;
	}
	
	public void reload() {
		curBullet = maxBullet;
		reloadStartTime = 0;
		shotLock = false;
	}

	public void setShotLocation(int x, int y) {
		this.shotX = x;
		this.shotY = y;
	}
	
	public int getShotX()
	{
		return shotX;
	}
	public int getShotY()
	{
		return shotY;
	}
	
	public int getModelNum()
	{
		return modelNum;
	}
	
	public int getCurBullet()
	{
		return curBullet;
	}
	
	public void setCurBullet(int curBullet)
	{
		this.curBullet = curBullet;
	}

	
	
	public void enforce(boolean on) {
		if (on) {
			this.damage = (int) ((double) damage * 1.5);
		} else {
			this.damage = damage / 3 * 2;
		}
	}
	
	public void setMaster(Container master)
	{
		this.master = master;
	}
	
	public int getWeight()
	{
		return weight;
	}

}
