package Object;

import java.awt.geom.Rectangle2D;

import pkg.GameChannel;

public abstract class GameObject {
	
	protected int HP;
	protected int maxHP;
	public GameChannel myChannel;
	public int id;
	public int x;
	public int y;
	protected int width;
	protected int height;
	protected boolean life;
	public byte team;

	public GameObject() {
		this.id = -1;
		this.team = GameChannel.TNONE;
		myChannel = null;
	}

	abstract public boolean update();

	public void setLocation(int x, int y) {
		this.x = x;
		this.y = y;
	}

	public Rectangle2D getBound() {
		return new Rectangle2D.Float(this.x, this.y, this.width, this.height);
	}

	public int getWidth() {
		return this.width;
	}

	public int getHeight() {
		return this.height;
	}

	public int getX() {
		return this.x;
	}

	public int getY() {
		return this.y;
	}
	
	public int getHP()
	{
		return HP;
	}
	
	public int getMaxHP()
	{
		return maxHP;
	}
}
