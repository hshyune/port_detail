package Object;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Line2D;

public class Land extends GameObject {

	public Land(int x, int y, int width, int height) {
		setLocation(x, y);
		this.width = width;
		this.height = height;
	}


	@Override
	public boolean update() {
		// TODO Auto-generated method stub
		return false;
	}

	public Line2D getTopLine() {
		return new Line2D.Float(x, y, x + width, y);
	}
}
