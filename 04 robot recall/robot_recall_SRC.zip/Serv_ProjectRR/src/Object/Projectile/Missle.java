package Object.Projectile;

import java.awt.geom.Rectangle2D;
import java.util.ArrayList;

import Interfaces.Hitable;
import Object.GameObject;
import Object.Parts.Weapon;
import pkg.GameChannel;

public class Missle extends Projectile {
	private int r=-25,r2=0,r3=25;
	

	public Missle(GameChannel myChannel, Weapon mother, int id, int range, int angle, int startX, int startY, byte team, int damage, int preload) {
		super(myChannel,mother,id,angle, team, damage);
		setLocation(startX, startY);
		this.preload = preload;
		this.width = 20;
		this.height = 20;
		this.life = 1;
		this.range = range;
		this.dstX = x + (int)(range * Math.cos((angle) *radcal));
		this.dstY = y + (int)(range * Math.sin((angle) *radcal));
		this.width = 20;
		this.height = 20;
		vib = 7;
		
	}

	@Override
	public boolean update() {
		if(preload>0){ 
			preload--;
			return false;
		}
		
		x+=(range/10 * Math.cos((angle ) *radcal));
		y+=(range/10 * Math.sin((angle ) *radcal));

		if(r>25)
			r=-26;
		if(r2>25)
			r2=-26;
		if(r3>25)
			r3=-26;
		r+=2;
		r2+=2;
		r3+=2;
		
		if( (angle >90 && angle < 270) ? dstX  >= x : dstX <=x) return true;
		//r+=speed;
		return false;
	}
	
	
	
	@Override
	public boolean isCollision(GameObject other) {
		// TODO Auto-generated method stub
		Rectangle2D bound = new Rectangle2D.Float(x, y, width, height);
		if (bound.intersects(other.getBound())) {
			return true;
		} else
			return false;
	}


	@Override
	public void isShoot(Projectile other) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void attack() {
		// TODO Auto-generated method stub
		
		if(preload>0) return;
		if(life ==0) return;
		
		ArrayList<GameObject> objectList = myChannel.getObjList();
		
		for (GameObject tmp : objectList) {
			if (tmp instanceof Hitable) {
				if (this.isCollision(tmp) && team != tmp.team) {
					((Hitable) tmp).isShoot(this);
					life = 0;
					//myChannel.getCaster().sendPak4(this.mother.id,tmp.id,this.getDmg(),this.getVib(),false);
					//System.out.println("hurt" + this.getDmg() + "/" + HP);
				}	

			}
		}
	}
}
