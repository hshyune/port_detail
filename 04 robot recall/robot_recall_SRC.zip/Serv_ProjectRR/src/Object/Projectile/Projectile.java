package Object.Projectile;

import java.awt.geom.Line2D;
import java.awt.geom.Point2D;

import Interfaces.Hitable;
import Object.GameObject;
import Object.Parts.Weapon;
import pkg.GameChannel;

public abstract class Projectile extends GameObject implements Hitable {

	public static final double radcal = Math.PI / 180;
	
	protected int angle, damage, life;

	// hitscan
	protected Weapon mother;
	protected int range;
	protected int dstX, dstY;
	protected Line2D scan;
	protected Point2D endPoint;
	protected boolean foward;
	protected int vib;
	protected int preload;

	public Projectile() {

	}

	public Projectile(GameChannel myChannel, Weapon mother, int id,int angle, byte team, int damage) {
		this.myChannel = myChannel;
		this.mother = mother;
		this.id = id;
		this.angle = angle;
		this.team = team;
		this.damage = damage;

	}

	@Override
	public boolean update() {
		// TODO Auto-generated method stub
		return false;
	}

	public int getDmg() {
		return this.damage;
	}

	public boolean isCollision(GameObject tmp) {
		// TODO Auto-generated method stub
		return false;
	}

	// hitscan
	abstract public void attack();
	
	public int getVib()
	{
		return vib;
	}
	
	public Weapon getMother()
	{
		return mother;
	}
}
