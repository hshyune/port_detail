package Object.Projectile;

import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.util.ArrayList;

import Interfaces.Hitable;
import Object.GameObject;
import Object.Parts.Weapon;
import pkg.GameChannel;

public class MGAmmo extends Projectile {

	int tail;


	public MGAmmo() {
		this.range = 0;
	}

	public MGAmmo(GameChannel myChannel,Weapon mother, int id,int range, int angle, int startX, int startY, byte team, int damage, boolean foward, int preload) {
		super(myChannel,mother,id,angle, team, damage);
		setLocation(startX, startY);
		this.life = 1;
		this.range = range;
		this.dstX =  x + (int)(range * Math.cos((angle) *radcal)); //(int) (Math.cos(Math.toRadians(angle)) * range);
		this.dstY =  y + (int)(range * Math.sin((angle) *radcal)); //(int) (Math.sin(Math.toRadians(angle)) * range);
		this.foward = foward;
		this.scan = new Line2D.Float(x, y, dstX, dstY);
		this.endPoint = new Point2D.Float(dstX, dstY);
		this.preload =preload;
		this.vib = 3;
		this.tail = range;
	}



	@Override
	public boolean update() {
		
		if(preload >0)
		{
			preload --;
			return false;
		}
		
		if((angle >90 && angle < 270) ? dstX  < x : dstX >x)
		{
			int nextX = (int)(range * Math.cos((angle ) *radcal));
			int nextY =	(int)(range * Math.sin((angle ) *radcal));
			scan = new Line2D.Float(x, y, x +nextX, y + nextY);
			x+= nextX;
			y+= nextY;
		}
		
		if(tail >0)
			tail -= range/8;
		else 
			return true;
		
		return false;
	}

	public Point2D getCollisionPoint(GameObject other) {
		int x, y;

		double a = (scan.getY2() - scan.getY1()) / (scan.getX2() - scan.getX1());
		double b = scan.getY1() - scan.getX1() * a;

		if (foward) {
			x = (int) other.getBound().getMinX();
			y = (int) (a * x + b);
		} else {
			x = (int) other.getBound().getMaxX();
			y = (int) (a * x + b);
		}
		// System.out.println(x + " " + y + " / " + getDistance(x, y));
		return new Point2D.Float(x, y);
	}
	
	public int getDistance(Point2D p) {
		int diffX = this.x - (int) p.getX();
		int diffY = this.y - (int) p.getY();
		int result = (int) Math.sqrt((double) (diffX * diffX + diffY * diffY));
		return result;
	}
	
	public void setEndPoint(Point2D p) {
		this.endPoint = p;
		this.dstX = (int) p.getX();
		this.dstY = (int) p.getY();
		scan.setLine(new Point2D.Float(x, y), new Point2D.Float(dstX, dstY));
		
	}
	
	@Override
	public boolean isCollision(GameObject other) {
		// TODO Auto-generated method stub
		if (scan.intersects(other.getBound())) {
			return true;
		} else
			return false;
	}

	@Override
	public void isShoot(Projectile other) {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void attack()
	{
		if(preload>0) return;
		if(life ==0) return;
		
		ArrayList<GameObject> tmpList = new ArrayList<GameObject>();
		ArrayList<GameObject> objectList = myChannel.getObjList();
		for (GameObject tmp : objectList) {
			if (tmp instanceof Hitable) {
				if (this.isCollision(tmp)) {
					if(tmp.team != this.team)
						tmpList.add(tmp);

				}
			}
		}
		
		if (tmpList.size() != 0) {
			int distance = 9999;
			int index = 9999;
			int min = 9999;
			for (int j = 0; j < tmpList.size(); j++) {
				
				distance = this.getDistance(this.getCollisionPoint(tmpList.get(j)));
				
				if (distance < min) {
					min = distance;
					index = j;
				}
			}
			this.setEndPoint(this.getCollisionPoint(tmpList.get(index)));
			((Hitable) tmpList.get(index)).isShoot(this);
			life = 0;
			//myChannel.getCaster().sendPak4(this.mother.id,tmpList.get(index).id,this.getDmg(),this.getVib(),false);
			//System.out.println("hurt" + this.getDmg() + "/" + HP);
		}
	}
}
