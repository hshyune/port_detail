package Object;

import java.awt.geom.Rectangle2D;

import Interfaces.Hitable;
import Item.HealPack;
import Object.Parts.Bottom;
import Object.Parts.Top;
import Object.Parts.Weapon;
import Object.Projectile.Projectile;
import pkg.GameChannel;

public class Container extends GameObject implements Hitable {

	Top top;
	Bottom bot;
	Weapon weapon;
	boolean foward;

	public Container(int x, int y, int id, byte team,  Top top, Bottom bot, Weapon weapon) {
		bot.setLocation(x, y);
		//System.out.println(bot.getX() + " " + bot.getY());
		// test code
		this.top = top;
		this.bot = bot;
		this.weapon = weapon;
		this.foward = true;
		setMaster();
		setId(id);
		setTeam(team);
	}

	public Container(int x, int y, int width, int height) {
		setLocation(x, y);
		this.width = width;
		this.height = height;
	}
	
	public void setId(int id)
	{
		this.id = id;
		this.top.id = this.id;
		this.bot.id = this.id;
		this.weapon.id = this.id;
	}
	
	public void channelSync(GameChannel ch)
	{
		this.myChannel = ch;
		this.top.myChannel = ch;
		this.bot.myChannel = ch;
		this.weapon.myChannel = ch;
	}

	// bottom parts command
	public void move(boolean foward) {

		this.foward = foward;
		if (foward) {
			bot.setDir(this.foward);
		} else {
			bot.setDir(this.foward);
		}

		bot.setStMove();
	}

	public void jump(boolean dirjump) {
		if (bot.getJumpLock())
			return;
		bot.setStJump(dirjump);
	}
	
	public boolean isJumping()
	{
		return bot.getJumpLock();
	}

	// weapon parts command
	public void spinAngle(boolean pos) {
		if (pos) {
			weapon.spinAngle(pos);
		} else {
			weapon.spinAngle(pos);
		}
	}

	public void shot() {
		if(weapon.canShot())
		{
			myChannel.getCaster().sendPak4(id,weapon.getShotX(),weapon.getShotY(),weapon.getAngle(),weapon.getCurBullet());
			weapon.shot();
		}
	}

	public void reload() {
		weapon.setReload();
	}
	
	public void skill()
	{
		top.skill();
	}
	
	public void repair(){
		weapon.reload();
		top.repair();
	}
	
	public void dimensionSync(int x, int y,int angle)
	{
		bot.setLocation(x, y);
		setLocation(bot.getX(), bot.getY());
		top.setLocation(x + bot.getWidth() / 2 - top.getWidth() / 2, y - top.getHeight());
		if (foward) {
			weapon.setLocation(bot.getX() - bot.getWidth() / 2, bot.getY() + 15);
		} else {
			weapon.setLocation(bot.getX() + bot.getWidth() / 2, bot.getY() + 15);
		}
		weapon.setAngle(angle);
		
	}

	@Override
	public Rectangle2D getBound() {
		return new Rectangle2D.Float(this.top.x, this.top.y, this.top.width + this.bot.width, this.top.height +this.bot.height);
	}
	
	@Override
	public boolean isCollision(GameObject other) {
		// TODO Auto-generated method stub
		if(this.top.getBound().intersects(other.getBound())){
			return true;
		}
		if(this.bot.getBound().intersects(other.getBound())){
			return true;
		}
		return false;
	}

	@Override
	public void isShoot(Projectile other) {
		// TODO Auto-generated method stub
		top.isShoot(other);
	}
	
	public void isHeal(HealPack heal) {
		// TODO Auto-generated method stub
		top.isHeal(heal);
	}

	@Override
	public boolean update() {
		// TODO Auto-generated method stub
		synchronized(this)
		{
			bot.update();
			setLocation(bot.getX(), bot.getY());
	
			// set top
			top.setLocation(x + bot.getWidth() / 2 - top.getWidth() / 2, y - top.getHeight());
			top.update();
			top.setDir(this.foward);
	
			// set weapon
			weapon.setDir(this.foward);
			if (foward) {
				weapon.setLocation(bot.getX() - bot.getWidth() / 2, bot.getY() + 15);
			} else {
				weapon.setLocation(bot.getX() + bot.getWidth() / 2, bot.getY() + 15);
			}
			weapon.setShotLocation(foward? bot.x + bot.width/4*3 - top.width/4: bot.x + top.width/4, top.y+top.height/4*3);
			weapon.update();
		}
		
		if(bot.y>2500) 
			top.HP = 0;
		if(top.getHP()<=0)
		{
			if(myChannel.getUser(id) != null)
				myChannel.getUser(id).death++;
			return true;
		}
		else return false;
	}

	public void setDir(boolean foward) {
		if (foward) {
			this.foward = foward;
			this.top.setDir(foward);
			this.bot.setDir(foward);
			this.weapon.setDir(foward);
		} else {
			this.foward = foward;
			this.top.setDir(foward);
			this.bot.setDir(foward);
			this.weapon.setDir(foward);
		}
	}

	public void setTeam(byte team)
	{
		this.team = team;
		this.top.team = team;
		this.bot.team = team;
		this.weapon.team = team;
	}
	
	public int getModelNum(String type)
	{
		switch(type)
		{
		case "Weapon":
			return this.weapon.getModelNum();
		case "Bottom":
			return this.bot.getModelNum();
		case "Top":
			return this.top.getModelNum();
		}
		return -1;
		
	}
	
	public Weapon getWeapon()
	{
		return weapon;
	}
	
	public Top getTop()
	{
		return top;
	}
	
	public Bottom getBottom()
	{
		return bot;
	}
	
	public void setMaster()
	{
		weapon.setMaster(this);
		top.setMaster(this);
		bot.setMaster(this);
	}

}
