package Item;

import java.awt.Color;
import java.awt.Graphics2D;

import pkg.GameChannel;

public class Barrier extends Item {

	public static final int OBJTYPE = 3;
	
	boolean foward;

	public Barrier(byte team,int id, int x, int y, GameChannel myChannel, boolean foward) {
		super(id,x,y,myChannel);
		this.foward = foward;
		this.team = team;
		this.maxHP = 800;
		this.HP = maxHP;
		// 43 117
		this.width = 43;
		this.height = 117;
		// TODO Auto-generated constructor stub
	}

	public boolean update() {
		if (isFloating()) {
			jumpDown();
		}
		if (HP <= 0)
			return true;
		return false;
	}



	public void drawHPBar(Graphics2D g, int cameraX, int cameraY) {
		// width 60 height 5
		int blankX;
		int blankY = 20;
		int length = 40;
		g.setColor(Color.black);
		g.drawRect(x - cameraX, y - cameraY - blankY, length + 2, 5 + 2);

		int percentage = (int) ((length + 1) * ((double) HP / (double) maxHP));
		g.setColor(Color.blue);
		g.fillRect(x - cameraX + 1, y - cameraY - blankY + 1, percentage, 6);
	}
	
	@Override
	public int getObjType()
	{
		return 2;
	}
	
}