package Item;

import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

import Interfaces.Dropable;
import Interfaces.Hitable;
import Object.GameObject;
import Object.Land;
import Object.Projectile.Projectile;
import pkg.GameChannel;
import pkg.Main;

public class Item extends GameObject implements Hitable, Dropable {

	public static final int OBJTYPE = 1;
	
	protected int vY;

	public Item(int id,int x, int y, GameChannel myChannel) {
		
		this.id = id;
		this.myChannel = myChannel;
		
		this.maxHP = 500;
		this.HP = this.maxHP;
		this.x = x;
		this.y = y;
		vY = 0;
		width = 60;
		height = 60;

	}

	@Override
	public boolean isFloating() {
		Line2D underLine = new Line2D.Float(x, (y + height + 1), x + width, (y + height + 1));
		ArrayList<GameObject> map = myChannel.getObjList();
		for (GameObject tmp : map) {
			if (tmp instanceof Land) {
				if (((Land) tmp).getBound().intersectsLine(underLine)) {
					return false;
				}
			}
		}
		return true;
	}

	@Override
	public int getLandingPoint() {
		ArrayList<GameObject> map = myChannel.getObjList();
		ArrayList<Land> lands = new ArrayList<Land>();
		Rectangle2D nextPhase = new Rectangle2D.Float(x, y + height, width, vY);
		for (GameObject tmp : map) {
			if (tmp instanceof Land) {
				if (((Land) tmp).getTopLine().intersects(nextPhase)) {
					lands.add((Land) tmp);
				}
			}
		}

		int min = 1000;
		if (lands.size() != 0) {
			for (Land tmp : lands) {
				if (tmp.getTopLine().getY1() < min)
					min = (int) tmp.getTopLine().getY1();
			}
			return min;
		}

		return 0;
	}

	@Override
	public void jumpDown() {
		vY = 8;

		int landY = getLandingPoint();

		if (landY != 0) {
			vY = landY - (y + height);
		}
		y += vY;
	}

	@Override
	public boolean isCollision(GameObject other) {
		// TODO Auto-generated method stub
		if(this.getBound().intersects(other.getBound())){
			return true;
		}
		return false;
	}

	@Override
	public void isShoot(Projectile other) {
		// TODO Auto-generated method stub
		HP = HP - other.getDmg();
		myChannel.getCaster().sendPak4(other.getMother().id,this.id,other.getDmg(),other.getVib(),false);
		
	}

	@Override
	public boolean update() {
		// TODO Auto-generated method stub
		if (isFloating()) {
			jumpDown();
		}
		if (HP <= 0) {
			return true;
		}
		return false;
	}
	
	public int getObjType()
	{
		return 0;
	}

}