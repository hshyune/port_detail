package Item;

import java.awt.Graphics2D;

import Object.GameObject;
import pkg.GameChannel;



public class HealPack extends Item {

	public static final int OBJTYPE = 2;
	
	int life;
	int heal;
	boolean isEatable;

	public HealPack(int id,int x, int y, GameChannel myChannel) {
		super(id,x,y,myChannel);

		this.width = 52;
		this.height = 63;
		this.life = 1;
		this.heal = 250;
		this.HP = 50;
		this.isEatable = false;

		// TODO Auto-generated constructor stub
	}

	public boolean update() {
		if (isFloating()) {
			jumpDown();
		}else{
			isEatable = true;
		}
		if(life == 0 || HP <= 0)
			return true;
		return false;
	}
	
	@Override
	public boolean isCollision(GameObject other) {
		// TODO Auto-generated method stub
		if(this.getBound().intersects(other.getBound()) && isEatable){
			return true;
		}
		return false;
	}
	
	public int getHeal(){
		this.life = 0;
		return heal;
	}
	
	@Override
	public int getObjType()
	{
		return 1;
	}

}
