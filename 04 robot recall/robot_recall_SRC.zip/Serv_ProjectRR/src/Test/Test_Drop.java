package Test;

import static org.junit.Assert.fail;

import java.util.ArrayList;

import org.junit.Test;

import Object.Container;
import Object.ContainerFactory;
import Object.GameObject;
import Object.Land;
import pkg.GameChannel;

public class Test_Drop {

	
	
	@Test
	public void test() {
		//fail("Not yet implemented");
		
		
		// �׽�Ʈ ȯ�� �����
		GameChannel gch = new GameChannel("test",0);
		gch.setActivated(true);
		
		ArrayList<GameObject> objList = gch.getObjList();
		
		objList.add(new Land(0,700,100,30));
		objList.add(new Land(0,800,200,30));
		
		Container c;
		for(int i=0;i<25;i++)
		{
			c = ContainerFactory.genContainer(GameChannel.TBLUE, i*10, 0, 0, 0, 0, 0);
			c.channelSync(gch);
			objList.add(c);
		}
		
		
		// 5000������ ������Ʈ
		for(int i=0;i<5000;i++)
		{
			for(GameObject g : objList)
				g.update();
		}
		
	
		// �� �׽�Ʈ �κ����� �ùٸ� ��ġ�� �����ߴ��� Ȯ��
		for(int i=0;i<25;i++)
		{
			int index = i+2;
			switch(objList.get(index).getX()/101)
			{
			case 0:
				if(objList.get(index).getY() + objList.get(index).getHeight()> 700 && objList.get(index).getY() + objList.get(index).getHeight()< 800)
					fail("fail : 2 floor landing bot ["+ i +"] , now pos [ " + objList.get(index).getX() + ", " + objList.get(index).getY() + " ]");
				break;
			case 1:
				if(objList.get(index).getY() + objList.get(index).getHeight()> 800)
					fail("fail : 1 floor landing bot [" + i +"] , now pos [ " + objList.get(index).getX() + ", " + objList.get(index).getY() + " ]");
				break;
			case 2:
				if(!objList.get(index).update())
					fail("fail : drop dead bot [" + i +"] , now pos [ "+ objList.get(index).update()+ " ], now pos [ " + objList.get(index).getX() + ", " + objList.get(index).getY() + " ]");
				break;
			}
		}
	}

}
