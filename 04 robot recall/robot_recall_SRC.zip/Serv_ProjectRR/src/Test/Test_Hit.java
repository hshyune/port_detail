package Test;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Test;

import Object.Container;
import Object.ContainerFactory;
import Object.Parts.Weapon;
import Object.Projectile.Ammo;
import Object.Projectile.MGAmmo;
import Object.Projectile.Missle;
import Object.Projectile.Projectile;
import pkg.GameChannel;

public class Test_Hit {

	@Test
	public void test() {
		//fail("Not yet implemented");
		GameChannel gch = new GameChannel("test",0);
		boolean valid = false;
		
		Container l = ContainerFactory.genContainer(GameChannel.TBLUE, 300, 300, 0, 0, 0, 0);
		l.channelSync(gch);
		gch.getObjList().add(l);
		
		l.update();
		
		
		// ammo �׽�Ʈ
		gch.getProjList().add(new Ammo(gch,l.getWeapon(),-1,500,0,300 - (int)(300*Math.cos(0 / Projectile.radcal)),
				300- (int)(300*Math.sin(0 / Projectile.radcal)),GameChannel.TRED,1,true,0));
		
		
		for(int i=0;i<10;i++)
		{
			for(Projectile p : gch.getProjList())
			{
				p.attack();
				p.update();
				System.out.println(p.x +"," + p.y +":" + l.getX()+","+l.getY() +":" +p.update());
			}
		}
	
		assertEquals(l.getTop().getHP()+1 , l.getTop().getMaxHP());
		
		// mgammo �׽�Ʈ
		gch.getProjList().add(new MGAmmo(gch,l.getWeapon(),-1,500,0,300 - (int)(300*Math.cos(0 / Projectile.radcal)),
				300- (int)(300*Math.sin(0 / Projectile.radcal)),GameChannel.TRED,1,true,0));
		
		
		for(int i=0;i<10;i++)
		{
			for(Projectile p : gch.getProjList())
			{
				p.attack();
				p.update();
				System.out.println(p.x +"," + p.y +":" + l.getX()+","+l.getY() +":" +p.update());
			}
		}
	
		assertEquals(l.getTop().getHP()+2 , l.getTop().getMaxHP());
		
		// missle �׽�Ʈ
		gch.getProjList().add(new Missle(gch,l.getWeapon(),-1,500,0,300 - (int)(300*Math.cos(0 / Projectile.radcal)),
				300- (int)(300*Math.sin(0 / Projectile.radcal)),GameChannel.TRED,1,0));
		
		for(int i=0;i<10;i++)
		{
			for(Projectile p : gch.getProjList())
			{
				p.attack();
				p.update();
				System.out.println(p.x +"," + p.y +":" + l.getX()+","+l.getY() +":" +p.update());
			}
		}
	
		assertEquals(l.getTop().getHP()+3 , l.getTop().getMaxHP());
		
	}

}
