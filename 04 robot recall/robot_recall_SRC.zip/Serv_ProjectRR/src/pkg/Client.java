package pkg;
import java.io.IOException;
import java.net.StandardSocketOptions;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import Object.Container;
import Object.ContainerFactory;



public class Client {

	private String id;
	private boolean ready;
	
	private SocketChannel socketChannel;
	private ByteBuffer recvBuffer;
	private Remocon ctrl;
	private Container []mybot;
	private GameChannel myChannel;
	private int index;
	private byte team;
	
	public int kill=0;
	public  int death=0;
	public int deal=0;
	
	public Client()
	{
		id = "";
		ready = false;
		myChannel = null;
		index = -1;
	}
	
	public Client(SocketChannel socketChannel) throws IOException
	{
		id = "";
		ready = false;
		this.socketChannel = socketChannel;
		this.socketChannel.setOption(StandardSocketOptions.TCP_NODELAY, true);
		this.socketChannel.configureBlocking(false);
		SelectionKey selectionKey = socketChannel.register(Server.getInstance().selector, SelectionKey.OP_READ);
		selectionKey.attach(this);
		
		recvBuffer = ByteBuffer.allocate(4096);
		
		
		mybot = new Container[3];
		
		
		myChannel = null;
		index = -1;
		ctrl = new Remocon();
		
	}
	
	
	
	////////////////
	// ��Ŷ ó�� ��� �޼ҵ�
	////////////////

	
	
	public void recv(SelectionKey selectionKey) 
	{
		try
		{
			
			recvBuffer.limit(4096);
			int byteCount = socketChannel.read(recvBuffer);
			
			if (byteCount == -1)
				throw new IOException();
			
			recvBuffer.flip();
			
			recvProc();
			
			
			//Charset charset = Charset.forName("UTF-8");
			//String data = charset.decode(byteBuffer).toString();
			//System.out.println("recv : " + byteBuffer + data);
			
		}
		catch(Exception e)
		{
			System.out.println("dis connect ");
			// ����ó��
			if(myChannel != null)
			{
				sendPak2((byte)2,this,false);
				if(	myChannel.getUserNum() == 1)
				{
					// ��� ó��
					int drid = myChannel.getId();
					Main.deleteRoom(this,myChannel);
					sendPak1(drid);
				}
				else
					myChannel.outUser(this);
			}
			Server.getInstance().clntList.remove(this);
			try
			{
				socketChannel.close();
			} catch(IOException e2)
			{
				e2.printStackTrace();
			}
		}
		Server.getInstance().wakeup();
	}
	
	private void recvProc()
	{
		int x;
		int y;
		int angle;
		byte sig;
		while(true)
		{
			sig = Server.completeRecv(recvBuffer);
			switch(sig)
			{
			case -1:
				return;
			// �α���
			case 0:
				reactPak0();
				break;
			// ȸ������
			case 1:
				reactPak1();
				break;
			// �� �����
			case 2:
				// decode
				reactPak2();
				break;
			// �� ����
			case 3:
				// decode
				reactPak3();
				break;
			// �� ������
			case 4:
				reactPak4();
				break;
			// build room �κ� ���� ��ȣ
			case 5:
				reactPak5();
				break;
			case 6:
				ready = !ready;
				sendPak2((byte)0,this,false);
				// �׽�Ʈ��
				System.out.println("��Ŷ �׽�Ʈ [�غ�] : "+ ready);
				break;
			case 7:
				byte team = recvBuffer.get();
				recvBuffer.compact();
				recvBuffer.flip();
				if(myChannel.changeTeam(this,team))
					sendPak2((byte)3,this,false);
				break;
			case 8:
				String msg = Server.cutString(recvBuffer);
				sendPak3(true,msg);
				
				break;
			case 9:
				// keyset ó�� �Լ� ( �ش��ϴ� Ű�� �÷��ְ� / �����ְ�  ���� ��ġ�� ����� XY�� 8����Ʈ �߰��Ͽ� ��Ƽĳ��Ʈ )
				byte keyType = recvBuffer.get();
				byte flag = recvBuffer.get();
				x =  recvBuffer.getInt();
				y =  recvBuffer.getInt();
				angle = recvBuffer.getInt();
				recvBuffer.compact();
				recvBuffer.flip();
				sendPak4(myChannel.controlKey(index, keyType, x,y,angle, flag));
				// �׽�Ʈ��
				//System.out.println("��Ŷ �׽�Ʈ[��Ʈ�� ����] : " + (int)keyType + "-" + flag);
				break;
			case 10:
				byte responNum = recvBuffer.get();
				recvBuffer.compact();
				recvBuffer.flip();
				myChannel.accountContainer(index, responNum-11);
				break;
			}
		}
	}
	
	private void reactPak0()
	{
		
		// decode
		String lid = Server.cutString(recvBuffer);
		String lpw = Server.cutString(recvBuffer);
		// process
		// id�� pw�� ���� �����Ͽ� ��ȿ���� �˻�
		byte valid = 0;
		int totalLen = 1;
		if(Server.getInstance().dbmgr.validID(lid, lpw))
		{
			valid = 1;
			totalLen = 37; // 12*3 +1
			
		}
		ByteBuffer data = ByteBuffer.allocate(totalLen);
		data.put(valid);
		
		if(valid == 1)
		{
			for(int i=0;i<3;i++)
			{
				mybot[i] = Server.getInstance().dbmgr.getBot(lid, i);
				data.putInt(mybot[i].getWeapon().getModelNum());
				data.putInt(mybot[i].getTop().getModelNum());
				data.putInt(mybot[i].getBottom().getModelNum());
			}
			this.id = lid;
		}
		
		
		// react
		sendPak0((byte)0,totalLen,data);
		if(valid ==1)
			syncRoomList();
		
		// 1 self cast
		// �׽�Ʈ�� ���
		System.out.print("��Ŷ �׽�Ʈ [�α���] : " + lid +":"+ lpw +" ");
	}
	private void reactPak1()
	{
		// decode
		String sid = Server.cutString(recvBuffer);
		String spw = Server.cutString(recvBuffer);
		// process
		// id�� pw ��ȿ�� �˻�
		
		byte valid = 0;
		if(Server.getInstance().dbmgr.signID(sid,spw))
			valid = 1;
		
		ByteBuffer data = ByteBuffer.allocate(1);
		data.put(valid);
		// react
		sendPak0((byte)1,1,data);
		// �׽�Ʈ�� ���
		System.out.print("��Ŷ �׽�Ʈ [ȸ������] : " + sid +":"+ spw +" ");
	}
	private void reactPak2()
	{
		String rname = Server.cutString(recvBuffer);
		// process
		// �� ����
		Main.makeRoom(this,rname);
		ByteBuffer rnameByte = Server.encodeString(rname);
		int totalLen = 4 + 4 + rnameByte.limit(); 
		ByteBuffer data = ByteBuffer.allocate(totalLen);
		data.putInt(myChannel.getId());
		data.putInt(rnameByte.limit());
		data.put(rnameByte);
		// react
		sendPak0((byte)2,totalLen,data);
		// �� �߰�
		sendPak1(rname,myChannel.getId(),false);
		// ��ũ ä��
		syncChannel();
		// �׽�Ʈ�� ���
		System.out.print("��Ŷ �׽�Ʈ [�� ����] : " + rname +" ");
	}
	private void reactPak3()
	{
		
		int rid = recvBuffer.getInt();
		recvBuffer.compact();
		recvBuffer.flip();
		
		
		String rname;
		ByteBuffer rnameByte;
		boolean valid = Main.joinRoom(this, rid);
		
		if(valid)
		{
			rname = Main.gameChannel.get(rid).getName();
			rnameByte = Server.encodeString(rname);
		}
		else
		{
			rname ="";
			rnameByte = Server.encodeString(rname);
		}
		
		// process
		
		int totalLen =  1 + 4 +  4 + 4 + rnameByte.limit();
		ByteBuffer data = ByteBuffer.allocate(totalLen);
		
		if(valid)
			data.put((byte)1);
		else
			data.put((byte)0);
		data.putInt(index);
		data.putInt(rid);
		data.putInt(rnameByte.limit());
		data.put(rnameByte);
		// react
		sendPak0((byte)3,totalLen,data); 
		// ���� �˸� & �� �� ���� �˸�
		sendPak2((byte)1,this,false);
		sendPak2((byte)3,this,false);
		// ä�� ��ũ
		syncChannel();
		// �׽�Ʈ�� ���
		System.out.print("��Ŷ �׽�Ʈ [�� ����] : " + rid + " ");
	}
	private void reactPak4()
	{
		// decode
		// process
		int remain = myChannel.getUserNum()-1;
		
		// ���� �˸�
		sendPak2((byte)2,this,false);
		if(remain == 0)
		{
			// ��� ó��
			int drid = myChannel.getId();
			Main.deleteRoom(this,myChannel);
			// �� ����
			sendPak1(drid);
		}
		else
		{
			// ���� ó��
			myChannel.outUser(this);
		}
		// react
		sendPak0((byte)4,0,null);
		// �� ����Ʈ ��ũ
		syncRoomList();
		// �׽�Ʈ�� ���
		System.out.print("��Ŷ �׽�Ʈ [�� ����] : ");
	}
	private void reactPak5()
	{
		// decode
		int robotNum=0, WNum=0, TNum=0, BNum;
		robotNum = recvBuffer.getInt();
		WNum = recvBuffer.getInt();
		TNum = recvBuffer.getInt();
		BNum = recvBuffer.getInt();
		recvBuffer.compact();
		recvBuffer.flip();
		// process
		// �� �۾��� ��ȿ���� Ȯ��
		Container output = ContainerFactory.genContainer(GameChannel.TNONE, 0, 0, 0, WNum, TNum, BNum);
		System.out.println("build comp" + robotNum +"bot..!");
		
		ByteBuffer data = ByteBuffer.allocate(17);
		if(output != null)
		{
			data.put((byte)1);
			mybot[robotNum] = output;
			// db�� ������Ʈ
			Server.getInstance().dbmgr.buildUpdate(id, robotNum, WNum, TNum, BNum);
		}
		else
		{
			data.put((byte)0);
		}
		data.putInt(robotNum);
		data.putInt(WNum);
		data.putInt(TNum);
		data.putInt(BNum);
		// react
		sendPak0((byte)5,17,data);
		
		// �׽�Ʈ�� ���
		//System.out.println("��Ŷ �׽�Ʈ [����] : " + "����" + robotNum + "����" + partNum + "��" + modelNum);
	}	


	// React ��Ŷ 
	public void sendPak0(byte sig, int dataLen, ByteBuffer data)
	{
		ByteBuffer byteBuffer = ByteBuffer.allocate(dataLen+6);
		
		byteBuffer.putInt(dataLen+6);
		byteBuffer.put((byte)0);
		byteBuffer.put(sig);
		if(dataLen != 0)
		{
			data.flip();
			byteBuffer.put(data);
		}
		byteBuffer.flip();
		castToSelf(byteBuffer);
		
		// �׽�Ʈ�� ���
		System.out.print(sig + "��ȣ ����ó�� : "+ (dataLen +6) +" ");
		
	}
	
	// Room List Process ��Ŷ
	public void sendPak1()
	{
		int totalLen = 4 + 1 + 1;
		ByteBuffer byteBuffer = ByteBuffer.allocate(totalLen);
		
		byteBuffer.putInt(totalLen);
		byteBuffer.put((byte)1);
		byteBuffer.put((byte)0);
		
		byteBuffer.flip();
		castToSelf(byteBuffer);
		
		// �׽�Ʈ�� ���
		System.out.print("���ӹ� ����Ʈ ���� ");
	}
	public void sendPak1(String rname, int rid, boolean sync)
	{
		ByteBuffer _rname = Server.encodeString(rname);
		int totalLen = 4 + 1 + 1 + 4 + 4 + _rname.limit();
		ByteBuffer byteBuffer = ByteBuffer.allocate(totalLen);
		
		byteBuffer.putInt(totalLen);
		byteBuffer.put((byte)1);
		byteBuffer.put((byte)1);
		byteBuffer.putInt(rid);
		byteBuffer.putInt(_rname.limit());
		byteBuffer.put(_rname);
		
		byteBuffer.flip();
		
		if(sync)
			castToSelf(byteBuffer);
		else
			castToawaiters(byteBuffer);
		
		// �׽�Ʈ�� ���
		System.out.print("["+rid +"]"+ rname+ "���߰�" + sync+" ");
	}
	public void sendPak1(int rid)
	{
		int totalLen = 4 + 1 + 1 + 4;
		ByteBuffer byteBuffer = ByteBuffer.allocate(totalLen);
		
		byteBuffer.putInt(totalLen);
		byteBuffer.put((byte)1);
		byteBuffer.put((byte)2);
		byteBuffer.putInt(rid);
		
		byteBuffer.flip();
		castToawaiters(byteBuffer);
		// �׽�Ʈ�� ���
		System.out.print("["+rid + "]������ ");
	}
	private void syncRoomList()	// room list sync react
	{
		
		Iterator itr = Main.gameChannel.entrySet().iterator();
		int id;
		String name;
		
		sendPak1();
		while(itr.hasNext())
		{
			Map.Entry<Integer,GameChannel> set = (Entry<Integer, GameChannel>)itr.next();
			
			name = set.getValue().getName();
			id = set.getKey();
			sendPak1(name,id,true);
			//�׽�Ʈ�� 
			System.out.print("["+ id + "]" +name +" ");
		}
		

	}
	
	// game channel process ��Ŷ
	public void sendPak2(byte sig, Client c,  boolean sync)
	{
		int totalLen ;
		ByteBuffer _buffer;
		ByteBuffer byteBuffer = null;
		
		switch(sig)
		{
		case 0:
			totalLen = 4 + 1 + 1 + 4 + 1;
			byteBuffer = ByteBuffer.allocate(totalLen);
			byteBuffer.putInt(totalLen);
			byteBuffer.put((byte)2);
			byteBuffer.put(sig);
			byteBuffer.putInt(c.getIndex());
			if(c.getReady())
				byteBuffer.put((byte)1);
			else
				byteBuffer.put((byte)0);
			// �׽�Ʈ�� ���
			System.out.print("���� ä�� �غ� ��ȣ ");
			break;
		case 1:
			_buffer = Server.encodeString(c.getId());
			totalLen = 4 + 1 + 1 + 4 + 4 + _buffer.limit();
			byteBuffer = ByteBuffer.allocate(totalLen);
			byteBuffer.putInt(totalLen);
			byteBuffer.put((byte)2);
			byteBuffer.put(sig);
			byteBuffer.putInt(c.getIndex());
			byteBuffer.putInt(_buffer.limit());
			byteBuffer.put(_buffer);
			// �׽�Ʈ�� ���
			System.out.print("���� ä�� ����" + id +"<"+index+">");
			break;
		case 2:
			totalLen = 4 + 1 + 1 + 4;
			byteBuffer = ByteBuffer.allocate(totalLen);
			byteBuffer.putInt(totalLen);
			byteBuffer.put((byte)2);
			byteBuffer.put(sig);
			byteBuffer.putInt(c.getIndex());
			// �׽�Ʈ�� ���
			//System.out.print("���� ä�� ���� "+ id +"<"+index+">");
			break;
		case 3:
			totalLen = 4 + 1 + 1 + 4 + 1;
			byteBuffer = ByteBuffer.allocate(totalLen);
			byteBuffer.putInt(totalLen);
			byteBuffer.put((byte)2);
			byteBuffer.put(sig);
			byteBuffer.putInt(c.getIndex());
			byteBuffer.put(c.getTeam());
			//System.out.print("�� ����" + team + "<" +index +">");
			break;
		case 4:
			totalLen = 4 + 1 + 1;
			byteBuffer = ByteBuffer.allocate(totalLen);
			byteBuffer.putInt(totalLen);
			byteBuffer.put((byte)2);
			byteBuffer.put(sig);
			//System.out.print("���� ����");
			break;
		case 5:
			totalLen = 4 + 1 + 1 + 4 + 4 + 4 + 4;
			byteBuffer = ByteBuffer.allocate(totalLen);
			byteBuffer.putInt(totalLen);
			byteBuffer.put((byte)2);
			byteBuffer.put(sig);
			byteBuffer.putInt(c.getIndex());
			byteBuffer.putInt(kill);
			byteBuffer.putInt(death);
			byteBuffer.putInt(deal);
			//System.out.print("���� ��� ����");
			break;
			
		}
		byteBuffer.flip();
		if(sync)
			castToSelf(byteBuffer);
		else
			castToChannel(byteBuffer);

	}
	private void syncChannel()
	{
		String name;
		boolean ready;
		for(int i=0;i<6;i++)
		{
			if(myChannel.getUser(i) != null)
			{
				sendPak2((byte)3,myChannel.getUser(i),true);
				sendPak2((byte)1,myChannel.getUser(i),true);
				sendPak2((byte)0,myChannel.getUser(i),true);
			}
				
		}
	}
	
	public void sendPak3(boolean isChat,String msg)
	{
		
		if(isChat)
			msg = id.concat(" : " + msg);
		else
			msg = new String("<!> ").concat(msg);
		
		ByteBuffer _buffer = Server.encodeString(msg);
		int totalLen = 4 + 1 + 4 + _buffer.limit();
		ByteBuffer byteBuffer = ByteBuffer.allocate(totalLen);
		
		byteBuffer.putInt(totalLen);
		byteBuffer.put((byte)3);
		byteBuffer.putInt(_buffer.limit());
		byteBuffer.put(_buffer);
		byteBuffer.flip();
		
		if(myChannel == null)
			castToawaiters(byteBuffer);
		else
			castToChannel(byteBuffer);
		
		// �׽�Ʈ�� ���
		System.out.println("��Ŷ �׽�Ʈ [ä��] : " + msg);
	}
	
	public void sendPak4(ByteBuffer byteBuffer)
	{
		if(byteBuffer != null)
		{
			byteBuffer.flip();
			castToChannel(byteBuffer);
		}
	}
	
	public void sendPak4( int actor, int reactor, int point, int vib, boolean isUp)
	{
		int totalLen = 4 + 1 + 1 + 4 + 4 + 4 + 4 + 1;
		ByteBuffer byteBuffer = ByteBuffer.allocate(totalLen);
		
		byteBuffer.putInt(totalLen);
		byteBuffer.put((byte)4);
		byteBuffer.put((byte)1);
		byteBuffer.putInt(actor);
		byteBuffer.putInt(reactor);
		byteBuffer.putInt(point);
		byteBuffer.putInt(vib);
		if(isUp)
		{
			byteBuffer.put((byte)1);
		}
		else
		{
			byteBuffer.put((byte)0);
		}
		
		byteBuffer.flip();
		
		castToChannel(byteBuffer);
	}
	
	public void sendPak4( boolean alive, byte team, boolean foward, int id, int objType,int x, int y)
	{
		int totalLen = 4 + 1 + 1 + 1 + 1 + 1 + 4 + 4 + 4 + 4;
		ByteBuffer byteBuffer = ByteBuffer.allocate(totalLen);
		
		byteBuffer.putInt(totalLen);
		byteBuffer.put((byte)4);
		byteBuffer.put((byte)2);

		if(alive)
			byteBuffer.put((byte)1);
		else
			byteBuffer.put((byte)0);
		
		byteBuffer.put(team);
		if(foward)
			byteBuffer.put((byte)1);
		else
			byteBuffer.put((byte)0);
		byteBuffer.putInt(id);
		byteBuffer.putInt(objType);
		byteBuffer.putInt(x);
		byteBuffer.putInt(y);
		
		byteBuffer.flip();
		
		castToChannel(byteBuffer);
	}
	
	public void sendPak4( byte team,int id, int weaponNum, int topNum, int bottomNum, int x, int y)
	{

		int totalLen = 4 + 1 + 1+ 1 + 4 + 4 + 4 + 4 + 4 + 4;
		ByteBuffer byteBuffer = ByteBuffer.allocate(totalLen);
		
		byteBuffer.putInt(totalLen);
		byteBuffer.put((byte)4);
		byteBuffer.put((byte)3);
		
		byteBuffer.put((byte)team);
		byteBuffer.putInt(id);
		byteBuffer.putInt(weaponNum);
		byteBuffer.putInt(topNum);
		byteBuffer.putInt(bottomNum);
		byteBuffer.putInt(x);
		byteBuffer.putInt(y);
		
		byteBuffer.flip();
		castToChannel(byteBuffer);
	}
	
	public void sendPak4(int id, int x, int y, int angle, int remain)
	{
		int totalLen = 4 + 1 + 1 + 4 + 4 + 4 + 4 + 4;
		ByteBuffer byteBuffer = ByteBuffer.allocate(totalLen);
		byteBuffer.putInt(totalLen);
		byteBuffer.put((byte)4);
		byteBuffer.put((byte)4);
		
		byteBuffer.putInt(id);
		byteBuffer.putInt(x);
		byteBuffer.putInt(y);
		byteBuffer.putInt(angle);
		byteBuffer.putInt(remain);
		
		byteBuffer.flip();
		castToChannel(byteBuffer);
		//System.out.println("shot!");
	}
	
	public void sendPak4(byte pur, byte red, byte blue)
	{
		int totalLen = 4 + 1 + 1 + 3;
		ByteBuffer byteBuffer = ByteBuffer.allocate(totalLen);
		byteBuffer.putInt(totalLen);
		byteBuffer.put((byte)4);
		byteBuffer.put((byte)5);
		byteBuffer.put((byte)pur);
		byteBuffer.put((byte)red);
		byteBuffer.put((byte)blue);
		
		
		byteBuffer.flip();
		castToChannel(byteBuffer);
	}
	
	//���� ���� �Ǵ� ��Ŷ
	private void castToSelf(ByteBuffer byteBuffer)
	{
		try
		{
			System.out.print("<castSELF "+id+">");
			socketChannel.write(byteBuffer);
		}
		catch(IOException ioe)
		{
			Server.getInstance().clntList.remove(this);
		}
	}
	
	//���� ä��
	private void castToChannel(ByteBuffer byteBuffer)
	{
		for(int i=0;i<6;i++ )
		{

			try
			{
				if(myChannel.getUser(i) != null)
				{
					
					myChannel.getUser(i).socketChannel.write(byteBuffer);
					byteBuffer.flip();
					//System.out.print("<castCH "+Server.getInstance().clntList.get(i).id+">");
				}
			}
			catch(IOException ioe)
			{
				if(Server.getInstance().clntList.size()>i)
					Server.getInstance().clntList.remove(i);
			}
		}
		Server.getInstance().wakeup();
	}
	
	//���� ĳ����
	private void castToawaiters(ByteBuffer byteBuffer)
	{
		int len = Server.getInstance().clntList.size();
		for(int i=0;i<len;i++ )
		{

			try
			{
				if(Server.getInstance().clntList.get(i).getMyChannel()==null)
				{
					System.out.print("<castAW "+Server.getInstance().clntList.get(i).id+">");
					Server.getInstance().clntList.get(i).socketChannel.write(byteBuffer);
					byteBuffer.flip();
				}
			}
			catch(IOException ioe)
			{
				if(Server.getInstance().clntList.size()>i)
					Server.getInstance().clntList.remove(i);
			}
		}
		Server.getInstance().wakeup();
	}
	
	//��ü ĳ����
	private void castToAll(ByteBuffer byteBuffer)
	{
		int len = Server.getInstance().clntList.size();
		for(int i=0;i<len;i++ )
		{

			try
			{
				System.out.print("<castALL "+ Server.getInstance().clntList.get(i).id +">");
				Server.getInstance().clntList.get(i).socketChannel.write(byteBuffer);
				byteBuffer.flip();
			}
			catch(IOException ioe)
			{
				if(Server.getInstance().clntList.size()>i)
					Server.getInstance().clntList.remove(i);
			}
		}
		Server.getInstance().wakeup();
	}
	
	/////////////////////////////
	// encapsulation
	////////////////////////////
	public SocketChannel getSocketChannel() {
		return socketChannel;
	}

	public Container getBot(int index)
	{
		return mybot[index];
	}
	
	public void setBot(int index, Container bot)
	{
		mybot[index] = bot;
	}

	public Remocon getCtrl()
	{
		return ctrl;
	}

	public void setMyChannel(GameChannel gch)
	{
		myChannel = gch;
	}
	
	public GameChannel getMyChannel()
	{
		return myChannel;
	}
	
	public int getIndex()
	{
		return index;
	}
	
	public void setIndex(int index)
	{
		this.index = index;
	}
	
	public String getId()
	{
		return id;
	}
	
	public boolean getReady()
	{
		return ready;
	}
	
	public void setReady(boolean ready)
	{
		this.ready = ready;
	}
	
	public byte getTeam()
	{
		return team;
	}
	
	public void setTeam(byte team)
	{
		this.team = team;
		for(int i=0;i<3;i++)
			this.mybot[i].setTeam(team);
		
	}
	
	
	

}
