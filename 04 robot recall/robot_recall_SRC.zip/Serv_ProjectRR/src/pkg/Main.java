package pkg;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

public class Main {

	static int roomNum = 0;
	static HashMap<Integer, GameChannel> gameChannel = new HashMap<Integer, GameChannel>();
//	static ArrayList<GameChannel> gameChannel = new ArrayList<GameChannel>();
	
	public static void deleteRoom(Client c, GameChannel gch)
	{
		
		synchronized (gameChannel){
			gameChannel.remove(gch.getId());
			gch.outUser(c);
		}
		
	}
	
	public static void makeRoom(Client c, String name)
	{	
		
		synchronized (gameChannel){
			gameChannel.put(roomNum, new GameChannel(name,roomNum));
			gameChannel.get(roomNum).joinUser(c);
		}
		roomNum +=1;
	}
	
	// ���� ã�ư��°� ����Ʈ���� Ž���ؾߵǴ� ������ �̿�
	public static boolean joinRoom(Client c, int id)
	{
		System.out.print(" join_to_" +id+ " " );
		boolean result = false;
		synchronized (gameChannel){
			GameChannel gch = gameChannel.get(id);
			
			if(gch != null)
				result = gch.joinUser(c);

		}
		return result;
	}
	
	
	public static void main(String[] args) throws IOException
	{	
		Server.getInstance().init();
		
		long pretime=0, nowtime=0, difftime=0;
		long elapsed=0;
		while(true)
		{
			difftime = nowtime - pretime;
			pretime = System.currentTimeMillis();

			synchronized (gameChannel){
			
				Iterator itr = Main.gameChannel.entrySet().iterator();
				
				while(itr.hasNext())
				{
					
					Map.Entry<Integer,GameChannel> set = (Entry<Integer, GameChannel>)itr.next();
					set.getValue().update(difftime);
					
				}
			}

			
			nowtime = System.currentTimeMillis();
			
		}
		
	}
}
