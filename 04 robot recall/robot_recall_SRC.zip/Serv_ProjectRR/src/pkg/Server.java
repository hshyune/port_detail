package pkg;
import java.io.BufferedReader;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;

public class Server implements Runnable{

	
	private static Server instance = new Server();
	public static Server getInstance()
	{
		return instance;
	}
	
	public Selector selector;
	public ServerSocketChannel servChannel;
	public ArrayList<Client> clntList;
	private int port;
	private Thread thread;
	public DBManager dbmgr;
	
	private Server() 
	{
		selector = null;
		clntList = null;
		servChannel = null;
	}
	
	
	public void init()
	{
		dbmgr = new DBManager();
		port = 8000;
		// nio ä�� ����
		try {
			selector = Selector.open();
			clntList = new ArrayList<Client>();
			servChannel = ServerSocketChannel.open();
			servChannel.configureBlocking(false);
			servChannel.bind(new InetSocketAddress(port));
			servChannel.register(selector, SelectionKey.OP_ACCEPT);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		// ������ ����
		thread = new Thread(this);
		thread.start();
		System.out.println("server initialize");
	}

	
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("run");
		while (true) {
            try {
                int keyCount = selector.select();
                
                if (keyCount == 0) {
                    continue;
                }
                
                Set<SelectionKey> selectedKeys = selector.selectedKeys();
                Iterator<SelectionKey> iterator = selectedKeys.iterator();
                
                while (iterator.hasNext()) {
                    SelectionKey selectionKey = iterator.next();
                    
                    if (selectionKey.isAcceptable()) {
                        accept(selectionKey);
                    } else if (selectionKey.isReadable()) {
                        Client client = (Client) selectionKey.attachment();
                        client.recv(selectionKey);
                    } //else if (selectionKey.isWritable()) {
                        //Client client = (Client) selectionKey.attachment();
                        //client.send(selectionKey);
                    //}
                    
                    iterator.remove();
                }
                
            } catch (Exception e) {
            	e.printStackTrace();
                break;
            }
        }
	}
	
	public void wakeup()
	{
		if(selector != null)
			selector.wakeup();
	}
	
	public void accept(SelectionKey selectionKey)
	{
		try
		{
			ServerSocketChannel serverSocketChannel = (ServerSocketChannel) selectionKey.channel();
			SocketChannel socketChannel = serverSocketChannel.accept();
			
			System.out.println("Accept client" + socketChannel.getRemoteAddress());
			Client client = new Client(socketChannel);
			clntList.add(client);
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	// ��Ŷ �ٷ�� �Լ�
	
	// 0���� ���� length ��ŭ ���۸� �ڸ��� buffer���� compact�ؼ� ��ȯ
	static ByteBuffer cut( int length, ByteBuffer buffer)
	{
		ByteBuffer _buffer;
		int oldL = buffer.limit();
		buffer.limit(length);
		_buffer = buffer.duplicate(); // ������
		_buffer = _buffer.slice(); // �ʿ���� �κ� �����̽��ؼ� ����
		

		buffer.position(buffer.limit());
		buffer.limit(oldL);
		buffer.compact();
		buffer.flip();
		
		return _buffer;
	}
	
	static ByteBuffer encodeString(String str)
	{
		Charset charset = Charset.forName("UTF-8");
		ByteBuffer _buffer = charset.encode(str);
		return _buffer;
	}
	
	// [ ����/4 ][ �޼��� ] ����� ��Ŷ�� ��Ʈ������ �̾Ƴ���.
	static String cutString(ByteBuffer buffer)
	{
		String _buffer;
		Charset charset = Charset.forName("UTF-8");
		int len = buffer.getInt();
		int oldLimit;
		
		oldLimit = buffer.limit();
		buffer.limit(buffer.position()+len);
		
		_buffer = charset.decode(buffer).toString();
		
		buffer.position(buffer.limit());
		buffer.limit(oldLimit);
		buffer.compact();
		buffer.flip();
		
		return _buffer;
	}
	
	// [ ��ü ����/4 ] üũ  limit�� �� ���� �̻��϶��� �����Ѵ�.
	static byte completeRecv(ByteBuffer buffer)
	{	
		
		if(buffer.limit() < 4)
			return -1;
		
		if(buffer.getInt() > buffer.limit())
		{
			buffer.rewind();
			return -1;
		}
		else
		{
			byte signal = buffer.get();
			buffer.compact();
			buffer.flip();
			return signal;
		}
	}
	
	// ��� ������ Ȯ���Ͽ� ����� ���� ��Ŷ�� ĳ��Ʈ�� ���� �ٽ� ����
	static ByteBuffer wrapPacket(byte sig, ByteBuffer buffer)
	{
		ByteBuffer _buffer; 
		int dataLen;
		int totalLen;
		int oldLimit;
		// �������� ���� �б�
		dataLen  = buffer.getInt();
		// [��ü����/4][��ȣ/1][�����ͱ���/4][������/n]
		totalLen = 4 + 1 + 4 + dataLen;
		_buffer = ByteBuffer.allocate(totalLen);
		
		// ������� put
		_buffer.putInt(totalLen);
		_buffer.put(sig);
		_buffer.putInt(dataLen);
		
		// ������ �߶󳻱�
		oldLimit = buffer.limit();
		buffer.limit(buffer.position()+dataLen);
		_buffer.put(buffer);
		buffer.limit(oldLimit);
		buffer.compact();
		buffer.flip();
		
		// �ø�
		_buffer.flip();
		return _buffer;
		
	}
	
	


}
