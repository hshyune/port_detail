package pkg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.mysql.jdbc.exceptions.jdbc4.MySQLIntegrityConstraintViolationException;

import Object.Container;
import Object.ContainerFactory;

public class DBManager {
	static final String DRIVER = "com.mysql.jdbc.Driver";
//	static final String URL = "jdbc:mysql://localhost:3306/cap";
	static final String URL = "jdbc:mysql://localhost:3306/PRR";

//	private String ID = "root";
	private String ID = "cap";
//	private String PW = "anwjr123";
	private String PW = "1234";
	private String SSL = "?verifyServerCertificate=false&useSSL=false";

	private Connection conn = null;
	private Statement stmt = null;
	private ResultSet rs = null;

	public DBManager() {
		Driver();
		Connection();
	}

	public void Driver() {
		// load driver
		try {
			Class.forName(DRIVER);
			System.out.println("Driver Loaded.");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void Connection() {
		// "jdbc:mysql://localhost:3306/����ҵ����ͺ��̽���?user=root&password=�н�����"
		try {
			conn = DriverManager.getConnection(URL+ SSL, ID, PW);
			System.out.println("Connected!");
			stmt = conn.createStatement();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public boolean validID(String id, String pw)
	{
		try {
			String sql = "SELECT * FROM INFO WHERE id like '"+ id + "';";
			rs = stmt.executeQuery(sql);
			rs.next();
			if(pw.equals(rs.getString(3)))
				return true;
			else
				return false;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	public Container getBot(String id,int index)
	{
		int[] result = new int[3];
		try {
			String sql = "SELECT * FROM  R"+(index+1)+" WHERE id= '" + id + "';";
			rs = stmt.executeQuery(sql);
			if (rs.next()) {
				for (int i = 0; i < 3; i++) {
					result[i] = rs.getInt(i + 3);
				}
				return ContainerFactory.genContainer(GameChannel.TNONE, 0, 0, 0, result[0], result[1], result[2]);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public boolean signID(String id, String pw)
	{
		String sql = "";
		try {
			

			sql = "INSERT INTO INFO (id, pw, win, lose) VALUES('" + id + "'," + "'" + pw + "', " + "0, 0);";
			stmt.executeUpdate(sql);
			for(int i=0;i<3;i++)
			{
				sql = "INSERT INTO R"+(i+1)+" (id, W, T, B) VALUES ('" +id +"'," + 0 +"," +0 +"," +0+");";
				stmt.executeUpdate(sql);
			}
			return true;
		} catch (MySQLIntegrityConstraintViolationException de ) {
			// TODO Auto-generated catch block
			System.out.println("duplicated");
			return false;
		} catch(  SQLException e)
		{
			e.printStackTrace();
			return false;
		}
	}
	//String sql = "UPDATE INFO SET WIN=" + winstr + " ,LOSE=" + losestr + " WHERE _id=" + _idstr + ";";
	public void buildUpdate(String id, int rnum, int wnum, int tnum, int bnum)
	{
		String sql = "";
		try {
			

			sql = "UPDATE R"+(rnum+1)+" SET  W=" +wnum  + " ,T=" + tnum + " ,B =" +bnum +" WHERE id= '" + id + "';";
			stmt.executeUpdate(sql);
			
		} catch(  SQLException e)
		{
			e.printStackTrace();
		}
	}
	
	public void rankUpdate(boolean iswin)
	{
		String sql = "";
		try {
			

			//sql = "UPDATE R"+(rnum+1)+" SET  W=" +wnum  + " ,T=" + tnum + " ,B =" +bnum +" WHERE _id= '" + id + "';";
			stmt.executeUpdate(sql);
			
		} catch(  SQLException e)
		{
			e.printStackTrace();
		}
	}
}
