package pkg;

import java.nio.ByteBuffer;
import java.util.ArrayList;

import Interfaces.Hitable;
import Item.Barrier;
import Item.HealPack;
import Item.Item;
import Object.Container;
import Object.GameObject;
import Object.Land;
import Object.Projectile.Ammo;
import Object.Projectile.MGAmmo;
import Object.Projectile.Missle;
import Object.Projectile.Projectile;

public class GameChannel {

	public static final byte TNONE =2;
	public static final byte TRED =0;
	public static final byte TBLUE =1;
	
	
	
	
	private String name;
	private int id;
	
	
	private byte teamNum[];
	private byte score[];
	private byte purScore; 
	private Client[] userList;
	private Client caster; // ���� ���� ����, ä�ο��� ��Ŷ�� ���������� ����ϴ� Ŭ���̾�Ʈ ��ü.
	private int userNum;
	private boolean activated; // ������ true, ����� false
	
	int objId; // �����Ǵ� id��
	
	long delay;
	long count;
	long elapsed;

	private ArrayList<GameObject> objectList;
	private ArrayList<Projectile> projectileList;
	
	public GameChannel(String name, int id)
	{
		teamNum = new byte[2];
		teamNum[TRED] = 0;
		teamNum[TBLUE] = 0;
		score = new byte[2];
		score[TRED] = 0;
		score[TBLUE] = 0;
		purScore = 0;
		this.name = name;
		this.id = id;
		objectList = new ArrayList<GameObject>();
		projectileList = new ArrayList<Projectile>();
		userList = new Client[6];
		for(int i=0;i<6;i++)
			userList[i] = null;
		userNum =0;
		
		delay = 25;
		count = 5;
		elapsed =0;
		
		caster = new Client();
		caster.setMyChannel(this);
		objId = 6;
		
	}
	
	public void gameInit()
	{
		//bottom
		objectList.add(new Land(0, 700, 500, 37));
		objectList.add(new Land(460, 650, 300, 20));
		objectList.add(new Land(800, 650, 300, 20));
		objectList.add(new Land(1050, 700, 580, 37));
				
		//mid
		objectList.add(new Land(50, 620, 200, 30));
		objectList.add(new Land(50, 500, 200, 30));
		objectList.add(new Land(230, 570, 170, 20));
		objectList.add(new Land(450, 530, 650, 37));
		objectList.add(new Land(1100, 600, 150, 20));
		objectList.add(new Land(1230, 650, 200, 20));
		objectList.add(new Land(1350, 560, 280, 30));
					
		//top
		objectList.add(new Land(80, 430, 100, 20));
		objectList.add(new Land(160, 360, 250, 30));
		objectList.add(new Land(400, 420, 200, 20));
		objectList.add(new Land(580, 350, 350, 30));
		objectList.add(new Land(900, 450, 350, 30));
		objectList.add(new Land(1280, 380, 350, 30));

		purScore = (byte) userNum;
		
		for(int i=0;i<6;i++)
		{
			if(userList[i] != null)
			{
				for(int j=0;j<3;j++)
				{
					userList[i].getBot(j).setId(i);
					userList[i].getBot(j).channelSync(this);
					userList[i].getBot(j).repair();
				}
				accountContainer(i,0);
			}
		}
		
		for (int i = 0; i < 5; i++) {
			accountObj(TNONE,Item.OBJTYPE,i*(int)(Math.random()*1000),0,false);
		}
		caster.sendPak4(purScore,score[TRED],score[TBLUE]);
	}
	
	public void gameClose()
	{
		// game set
		activated = false;
		count = 5;
		objectList.clear();
		projectileList.clear();
		score[TRED]=0;
		score[TBLUE]=0;
		
		for(int i=0;i<6;i++)
		{
			if(userList[i]!=null)
			{
				userList[i].setReady(false);
				userList[i].getCtrl().clear();
				userList[i].sendPak2((byte)0, userList[i], false);
				userList[i].sendPak2((byte)5, userList[i], false);
				userList[i].kill = 0;
				userList[i].death = 0;
				userList[i].deal = 0;
			}
		}
		caster.sendPak2((byte)4, caster, false);
	}
	
	public void update(long difftime)
	{
		if(activated)
		{
			delay -= difftime;
			
			
			
			
			
			while(delay<0)
			{
				if(delay<0) delay+=25;
				for(int i=0;i<6;i++)
					if(userList[i] != null)
						userList[i].getCtrl().keyProcess();
				update_objpf();
			}
		}
		else
		{
			if(userNum >0 && teamNum[TRED] == teamNum[TBLUE])
			{
				for(int i=0;i<6;i++)
				{
					if(userList[i]!=null)
						if(!userList[i].getReady())
						{
							count = 5;
							elapsed = 0;
							return;
						}
							
				}
				
				elapsed += difftime;
				if(elapsed >1000)
				{
					elapsed -=1000;
					count -=1;
					caster.sendPak3(false,"���� �÷��̱��� "+count+"�� ���ҽ��ϴ�.");
					//System.out.println("���� �÷��̱��� "+count+"�� ���ҽ��ϴ�.");
					if(count ==0)
					{
						gameInit();
						caster.sendPak2((byte)4, caster, false);
						// ���� �ε�
						activated = true;
					}
				}
			}
			// ���� ready �������� Ȯ��
				// count 0 -> ���� Ȱ��ȭ ��Ŷ
				// -> �ƴϸ� �ð��缭 1�ʰ������� count
			// ����ready �ƴϸ� count �ʱ�ȭ
		}
	}
	
	public void update_objpf()
	{
		
		// shot
		//ArrayList<GameObject> tmpList = new ArrayList<GameObject>();
		// implements isCollision()
		int size = this.projectileList.size();
		for (int i = 0; i < size; i++)
			projectileList.get(i).attack();
		// healpack
		for (GameObject lhs : objectList) {
			if (lhs instanceof HealPack) {
				for (GameObject rhs : objectList) {
					if(rhs instanceof Container){
						if(((Container) rhs).isCollision((HealPack)lhs)){
							((Container) rhs).isHeal((HealPack) lhs);
							System.out.println("im healing!");
						}
					}
				}
			}
		}		
		
		
		int removeId;
		// update Objects
		size = this.objectList.size();
		for (int i = 0; i < size; i++) {
			if (objectList.get(i).update()) {
				removeId =objectList.get(i).id;
				GameObject g = objectList.remove(i);
				caster.sendPak4(false,(byte)-1,false,removeId,-1,-1,-1);
				size--;
				if(g instanceof Container)
				{
					if(++score[g.team == TRED ? TBLUE : TRED] == purScore)
					{
						gameClose();
						return;
					}
					else
					{
						caster.sendPak4(purScore,score[TRED],score[TBLUE]);
					}
				}
				System.out.println( score[TRED] + ":" + score[TBLUE] + " //" + purScore);
			}
		}
		// update Bullets
		size = this.projectileList.size();
		for (int i = 0; i < size; i++) {
			if (projectileList.get(i).update()) {
				removeId = projectileList.get(i).id;
				projectileList.remove(i);
				size--;
			}
		}
		
		

		
	}
	
	
	public void accountContainer(int i, int robotNum)
	{
		userList[i].getBot(robotNum).repair();
		
		userList[i].getCtrl().setReceiver(userList[i].getBot(robotNum));
		userList[i].getBot(robotNum).dimensionSync(300+50*i, 0,0);
		objectList.add(userList[i].getBot(robotNum));
		
		
		caster.sendPak4(userList[i].getTeam(),i,
				userList[i].getBot(robotNum).getModelNum("Weapon"),
				userList[i].getBot(robotNum).getModelNum("Top"),
				userList[i].getBot(robotNum).getModelNum("Bottom"),
				300+50*i,0);
	}
	
	public void accountObj(byte team, int objType, int x, int y,boolean foward)
	{
		switch(objType)
		{
		case Item.OBJTYPE:
			Item item = new Item(objId,x, y,this);
			objectList.add(item);
			break;
		case HealPack.OBJTYPE:
			HealPack hpack = new HealPack(objId,x,y,this);
			objectList.add(hpack);
			break;
		case Barrier.OBJTYPE:
			Barrier br = new Barrier(team, objId,x,y,this,foward);
			objectList.add(br);
			break;
		}
		caster.sendPak4(true,team, foward, objId++,objType,x,y);
		System.out.println("item ����");
	}
	
	public ByteBuffer controlKey(int index, byte keyType, int x, int y,int angle, byte flag)
	{
		Remocon ctrl = userList[index].getCtrl();
		
		System.out.println("Ű�Է�" + x +","+ y);
		// key control update
		int syncX ;
		int syncY ;
		if(ctrl.getReceiver().isJumping())
		{
			
			syncX = -1;
			syncY = -1;
		}
		else
		{
			ctrl.sync(x, y,angle);
			syncX = x;
			syncY = y;
		}
		
		if(flag==1)
		{
			ctrl.set((char)keyType);
		}
		else
		{
			ctrl.clear((char)keyType);
		}
		
		
		// generate keybuf
		int totalLen = 0;
		ByteBuffer syncBuf = null;
		// 5(skill)�� Ŭ�󿡼� ������ Ȱ��ȭ�Ǹ� ��ų�� ���� ��ü������ ���� �ʰ� ��ų�� �����Ѵ�.(�����ֱ� ���ؼ�)
		// 8(shot)�� ����ü ��ü�� ����ȭ�Ǿ��ϱ� ������ ������ ��Ŷ�� ������ ������ �߻�� ����ȭ�Ѵ�.
		if(keyType != 8)
		{
			totalLen = 4 + 1 + 1 + 4 + 1 + 1 + 4 + 4 +4;
			syncBuf = ByteBuffer.allocate(totalLen);
			
			syncBuf.putInt(totalLen);
			syncBuf.put((byte)4);
			syncBuf.put((byte)0);
			syncBuf.putInt(index);
			syncBuf.put(keyType);
			
			if(flag==1)
			{
				syncBuf.put((byte)1);
			}
			else
			{
				syncBuf.put((byte)0);
			}
			syncBuf.putInt(syncX);
			syncBuf.putInt(syncY);
			syncBuf.putInt(angle);
		}
		
		return syncBuf;
	}
	
	
	

	public boolean joinUser(Client c)
	{
		if(userNum == 6 || activated) return false;
		else
		{
			for(int i=0;i<6;i++)
				if(userList[i] == null)
				{
					userList[i] = c;
					c.setMyChannel(this);
					c.setIndex(i);
					userNum +=1;
					
					if(teamNum[TRED] <= teamNum[TBLUE])
					{
						teamNum[TRED]++;
						c.setTeam(TRED);
					}
					else
					{
						teamNum[TBLUE]++;
						c.setTeam(TBLUE);
					}
					System.out.println("\nR:"+teamNum[TRED] + "B"+teamNum[TBLUE]);
					return true;
				}
		}
		return false;
	}
	
	public void outUser(Client c)
	{
		if(activated)
			for(int i=0;i<objectList.size();i++)
			{
				if(objectList.get(i).id == c.getIndex())
					objectList.remove(i);
			}
		teamNum[userList[c.getIndex()].getTeam()]--;
		userList[c.getIndex()] = null;
		c.setMyChannel(null);
		c.setIndex(-1);
		c.setTeam(TNONE);
		c.setReady(false);
		userNum -=1;
	}
	
	public boolean isTeam(GameObject g, byte team)
	{
		if(g.team == team)
			return true;
		else
			return false;
	}
	
	public boolean changeTeam(Client c, byte team)
	{
		if(teamNum[team] <3)
		{
			teamNum[c.getTeam()]--;
			teamNum[team] ++;
			c.setTeam(team);
			return true;
		}
		else
			return false;
	}
	
	public boolean equalId(int id)
	{
		if(this.id == id)
			return true;
		else
			return false;
	}
	
	// encapsulation
	public int getId()
	{
		return id;
	}
	
	public String getName()
	{
		return name;
	}
	
	public int getUserNum()
	{
		return userNum;
	}
	
	public Client getCaster()
	{
		return caster;
	}
	
	public Client getUser(int i)
	{
		return userList[i];
	}
	
	public ArrayList<GameObject> getObjList()
	{
		return objectList;
	}
	
	public ArrayList<Projectile> getProjList()
	{
		return projectileList;
	}
	
	public void setActivated(boolean activated)
	{
		this.activated = activated;
	}
	
	public boolean getActivated(boolean activated)
	{
		return activated;
	}
}
