package Object;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import Core.Main;
import Interfaces.Hitable;
import Item.HealPack;
import Object.Effect.Boom;
import Object.Parts.Bottom;
import Object.Parts.Top;
import Object.Parts.Weapon;
import Object.Projectile.Projectile;

public class Container extends GameObject implements Hitable {

	public Top top;
	Bottom bot;
	Weapon weapon;
	boolean foward;

	public Container(int x, int y, int id,byte team, Top top, Bottom bot, Weapon weapon) {
		bot.setLocation(x, y);
		System.out.println(bot.getX() + " " + bot.getY());
		// test code
		this.top = top;
		this.bot = bot;
		this.weapon = weapon;
		this.foward = true;
		setMaster();
		setId(id);
		setTeam(team);
	}

	public Container(int x, int y, int width, int height) {
		setLocation(x, y);
		this.width = width;
		this.height = height;
	}

	// bottom parts command
	public void move(boolean foward) {
		

		this.foward = foward;
		if (foward) {
			bot.setDir(this.foward);
		} else {
			bot.setDir(this.foward);
		}

		bot.setStMove();
	}

	public void jump(boolean dirjump) {
		
		if (bot.getJumpLock())
			return;
		bot.setStJump(dirjump);
		
	}
	
	public boolean isJumping()
	{
		return bot.getJumpLock();
	}

	// weapon parts command
	public void spinAngle(boolean pos) {
		if (pos) {
			weapon.spinAngle(pos);
		} else {
			weapon.spinAngle(pos);
		}
	}

	public void shot() {
		if(weapon.canShot())
			weapon.shot();
	}

	public void reload() {
		weapon.setReload();
	}
	
	//top parts command
	public void skill(){
		top.skill();
	}
	
	public void repair(){
		weapon.reload();
		top.repair();
	}
	
	
	public void dimensionSync(int x, int y, int angle)
	{
		bot.setLocation(x, y);
		setLocation(bot.getX(), bot.getY());
		top.setLocation(x + bot.getWidth() / 2 - top.getWidth() / 2, y - top.getHeight());
		if (foward) {
			weapon.setLocation(bot.getX() - bot.getWidth() / 2, bot.getY() + 15);
		} else {
			weapon.setLocation(bot.getX() + bot.getWidth() / 2, bot.getY() + 15);
		}
		weapon.setAngle(angle);
	}
	
	@Override
	public void hurtSync(int point, boolean isUp)
	{
		if(isUp)
			top.HP = top.HP+point > top.maxHP ? top.maxHP : top.HP + point;
		else
			top.HP = top.HP-point < 0 ? 0 : top.HP - point;
	}

	@Override
	public Rectangle2D getBound() {
		return new Rectangle2D.Float(this.top.x, this.top.y, this.top.width + this.bot.width, this.top.height +this.bot.height);
	}

	@Override
	public boolean isCollision(GameObject other) {
		// TODO Auto-generated method stub
		if(this.top.getBound().intersects(other.getBound())){
			return true;
		}
		if(this.bot.getBound().intersects(other.getBound())){
			return true;
		}
		return false;
	}

	@Override
	public void isShoot(Projectile other) {
		// TODO Auto-generated method stub
		top.isShoot(other);
	}
	
	public void isHeal(HealPack heal) {
		// TODO Auto-generated method stub
		top.isHeal(heal);
	}
	

	@Override
	public void genAftObj()
	{
		Main.camera.getObjList().add(new Boom(this,200,Color.WHITE));
	}

	@Override
	public void draw(Graphics2D g, int cameraX, int cameraY) {

		// TODO Auto-generated method stub
		// g.setColor(Color.BLUE);
		// g.fillRect(x - cameraX, y - cameraY, 40, 40);

		// top.draw(g, cameraX, cameraY);
		bot.draw(g, cameraX, cameraY);
		top.draw(g, cameraX, cameraY);
		weapon.draw(g, foward? cameraX - bot.width/4*3 - top.width/4: cameraX- top.width/4, cameraY + top.height/8);
		// weapon.draw(g, cameraX, cameraY);
	}

	@Override
	public boolean update() {
		// TODO Auto-generated method stub
		synchronized(this)
		{
			bot.update();
			setLocation(bot.getX(), bot.getY());
	
			// set top
			top.setLocation(x + bot.getWidth() / 2 - top.getWidth() / 2, y - top.getHeight());
			top.update();
			top.setDir(this.foward);
	
			// set weapon
			weapon.setDir(this.foward);
			if (foward) {
				weapon.setLocation(bot.getX() - bot.getWidth() / 2, bot.getY() + 15);
			} else {
				weapon.setLocation(bot.getX() + bot.getWidth() / 2, bot.getY() + 15);
			}
			weapon.setShotLocation(foward? bot.x + bot.width/4*3 - top.width/4: bot.x + top.width/4, top.y+top.height/4*3);
			weapon.update();
		
		}
		if(bot.y>2500) top.HP = 0;
		if(top.getHP() <=0 ) return true;
		else	return false;
		
	}
	
	public int getAngle()
	{
		return weapon.getAngle();
	}

	public void setDir(boolean foward) {
		if (foward) {
			this.foward = foward;
			this.top.setDir(foward);
			this.bot.setDir(foward);
			this.weapon.setDir(foward);
		} else {
			this.foward = foward;
			this.top.setDir(foward);
			this.bot.setDir(foward);
			this.weapon.setDir(foward);
		}
	}
	
	public void setId(int id)
	{
		this.id = id;
		this.top.id = this.id;
		this.bot.id = this.id;
		this.weapon.id = this.id;
	}
	
	public void setTeam(byte team)
	{
		this.team = team;
		this.top.team = team;
		this.bot.team = team;
		this.weapon.team = team;
	}
	
	public void setMaster()
	{
		this.weapon.setMaster(this);
		this.top.setMaster(this);
		this.bot.setMaster(this);
	}
	
	public Weapon getWeapon()
	{
		return weapon;
	}
	
	public Top getTop()
	{
		return top;
	}
	
	@Override
	public int getHP()
	{
		return top.getHP();
	}
	
	@Override
	public void setHP(int HP)
	{
		top.setHP(HP);
	}
	
	@Override
	public int getMaxHP()
	{
		return top.maxHP;
	}
	
	public Bottom getBottom()
	{
		return bot;
	}



}
