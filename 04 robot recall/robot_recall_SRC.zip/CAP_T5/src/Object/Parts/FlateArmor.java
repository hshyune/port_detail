package Object.Parts;

import java.awt.Graphics2D;

import Core.Main;
import IMG.ResourceManager;
import Item.Barrier;
import Object.Projectile.MGAmmo;
import Object.Projectile.Missle;
import Object.Projectile.Projectile;

public class FlateArmor extends Top {

	boolean isFlame;
	
	public FlateArmor(int modelNum,int maxHP, int skillDelay, int maxSkill) {
		// TODO Auto-generated constructor stub
		super(modelNum);
		img = ResourceManager.getInstance().getFlate();
		this.width = img[0].getWidth();
		this.height = img[0].getHeight();
		this.isFlame = false;
		
		
		this.skillDelay = skillDelay;
		this.skillStart = skillDelay;
		this.maxSkill = maxSkill;
		this.maxHP = maxHP;
		this.curSkill = this.maxSkill;
		this.HP = this.maxHP;
		
		weight = 3;
	}

	@Override
	public void draw(Graphics2D g, int cameraX, int cameraY) {
		// get bot x,y
		if (foward)
			g.drawImage(img[0], x - cameraX, y - cameraY, null);
		else
			g.drawImage(img[1], x - cameraX, y - cameraY, null);
		// TODO Auto-generated method stub
		drawHPBar(g, cameraX, cameraY);

		if (isFlame) {
			g.drawImage(ResourceManager.getInstance().getFlame(), x - cameraX, y - cameraY - 65, null);
		}

	}
	
	@Override
	public void isShoot(Projectile other) {
		// TODO Auto-generated method stub
		int dmg = other.getDmg();
		
		if(other instanceof Missle)
		{
			dmg *= 1.3;
		}
		else if(other instanceof MGAmmo)
		{
			dmg *= 0.75;
			if(dmg==0) dmg = 1;
		}
		
		HP = HP - dmg;
	}

	public boolean update() {
		if (isFlame) {
			if(skillStart >= 60){
				master.getWeapon().enforce(false);
				isFlame = false;
			}
		}
		if(skillStart<skillDelay)
			skillStart++;
		return false;
	}

	public void skill() {
		if (isFlame) {
			return;
		}
		// set damage increment
		isFlame = true;
		curSkill--;
		skillStart=0;
		master.getWeapon().enforce(true);
	}
	
}
