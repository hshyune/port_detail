package Object.Parts;

import java.awt.Graphics2D;

import Core.Main;
import IMG.ResourceManager;
import Item.HealPack;
import Object.Projectile.Ammo;
import Object.Projectile.MGAmmo;
import Object.Projectile.Projectile;

public class LightArmor extends Top {

	public LightArmor(int modelNum, int maxHP, int skillDelay, int maxSkill) {
		super(modelNum);
		img = ResourceManager.getInstance().getTopImage();
		this.width = img[0].getWidth();
		this.height = img[0].getHeight();

		this.skillDelay = skillDelay;
		this.skillStart = skillDelay;
		this.maxSkill = maxSkill;
		this.maxHP = maxHP;
		this.curSkill = this.maxSkill;
		this.HP = this.maxHP;
		
		weight = 1;
	}

	@Override
	public void draw(Graphics2D g, int cameraX, int cameraY) {
		// get bot x,y
		if (foward)
			g.drawImage(img[0], x - cameraX, y - cameraY, null);
		else
			g.drawImage(img[1], x - cameraX, y - cameraY, null);
		// TODO Auto-generated method stub
		drawHPBar(g, cameraX, cameraY);

	}
	
	@Override
	public void isShoot(Projectile other) {
		// TODO Auto-generated method stub
		int dmg = other.getDmg();
		
		if(other instanceof MGAmmo)
		{
			dmg *= 1.3;
		}
		else if(other instanceof Ammo)
		{
			dmg *= 0.75;
			if(dmg==0) dmg = 1;
		}
		
		HP = HP - dmg;
	}
	
	@Override
	public boolean update() {
		if (skillStart < skillDelay)
			skillStart++;
		return false;
	}
	@Override
	public void skill() {
		if (curSkill<= 0 || skillStart < skillDelay) {
			return;
		}
		if(!Main.gate.isActivated())
		{
			
			HealPack heal;
			if (foward) {
				heal = new HealPack(-1,x + 100, y - 50);
			} else {
				heal = new HealPack(-1,x - 100, y - 50);
			}
			Main.camera.getObjList().add(heal);
		}
		curSkill--;
		skillStart = 0;
	}


}
