package Object.Parts;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import Core.Main;
import Core.Sock;
import IMG.ResourceManager;
import Interfaces.Hitable;
import Item.HealPack;
import Object.Container;
import Object.GameObject;
import Object.Projectile.Projectile;

public class Top extends GameObject implements Hitable {

	
	protected Container master;
	protected int modelNum;
	protected BufferedImage[] img;
	int weight;
	protected boolean foward;
	protected int skillStart;
	protected int skillDelay;
	protected int curSkill;
	protected int maxSkill;
	


	Top(int modelNum) {
		this.modelNum = modelNum;
		this.maxHP = 100;
		this.HP = maxHP;
		this.img = new BufferedImage[2];
		this.foward = true;

	}

	public void setDir(boolean foward) {
		this.foward = foward;
	}
	
	@Override
	public void genAftObj()
	{
		
	}

	@Override
	public void draw(Graphics2D g, int cameraX, int cameraY) {
		drawHPBar(g, x - cameraX, y - cameraY);
		// TODO Auto-generated method stub

	}

	@Override
	public boolean update() {
		// TODO Auto-generated method stub
		return false;
	}

	public void drawHPBar(Graphics2D g, int cameraX, int cameraY) {
		// width 60 height 5
		int blankX;
		int blankY = 20;
		g.setColor(Color.black);
		g.drawRect(x - cameraX, y - cameraY - blankY, 60 + 2, 5 + 2);

		int percentage = (int) (61 * ((double) HP / (double) maxHP));
		if(team== Sock.TRED)
			g.setColor(ResourceManager.makeColorRGBA(255, 0, 0, 255));
		else
			g.setColor(ResourceManager.makeColorRGBA(0, 148, 255, 255));
		
		
		if(Main.gate.isActivated() &&id <6)
		{
			g.setFont(new Font("", Font.BOLD, 12));
			g.drawString(Main.waitr2.getUserName(id),x - cameraX - (Main.waitr2.getUserName(id).length()*3), y - cameraY - blankY-10);
		}
		g.fillRect(x - cameraX + 1, y - cameraY - blankY + 1, percentage, 6);
	}

	public int getDmg() {
		return 0;
	}

	@Override
	public boolean isCollision(GameObject other) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void isShoot(Projectile other) {
		// TODO Auto-generated method stub
		HP = HP - other.getDmg();
	}

	public void isHeal(HealPack heal) {
		// TODO Auto-generated method stub
		if (HP + heal.getHeal() >= maxHP) {
			HP = maxHP;
		} else {
			HP = HP + heal.getHeal();
		}
	}

	public void skill() {

	}

	public void repair()
	{
		HP = maxHP;
		curSkill = maxSkill;
	}
	
	public int getCurSkill()
	{
		return curSkill;
	}
	
	public int getSkillStart()
	{
		return skillStart;
	}
	
	public int getSkillDelay()
	{
		return skillDelay;
	}
	
	public void setMaster(Container master)
	{
		this.master = master;
	}
	
	public int getWeight()
	{
		return weight;
	}
}
