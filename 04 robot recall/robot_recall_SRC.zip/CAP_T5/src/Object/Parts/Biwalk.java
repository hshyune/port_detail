package Object.Parts;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import IMG.ResourceManager;

public class Biwalk extends Bottom {
	BufferedImage nowImg;

	public Biwalk(int modelNum, int mvSpeed, int weight, float jump) {
		super(modelNum);
		// set State Idle
		foward = true;
		if (isFloating()) {
			jumpLock = true;
		} else {
			jumpLock = false;
		}
		vX = 0;
		vY = 0;
		state = IDLE;

		this.img = new BufferedImage[4];
		for (int i = 0; i < 4; i++) {
			this.img[i] = ResourceManager.getInstance().getBottomImage()[i];
		}
		this.width = img[0].getWidth();
		this.height = img[0].getHeight();
		
		this.jumpPower = (int)(height * jump);
		this.mvSpeed = mvSpeed;
		this.weight = weight;
	}

	@Override
	public void draw(Graphics2D g, int cameraX, int cameraY) {
		// TODO Auto-generated method stub
		if (foward) {
			if (x % 100 < 50)
				g.drawImage(img[2], x - cameraX, y - cameraY, null);
			else {
				g.drawImage(img[3], x - cameraX, y - cameraY, null);

			}
		} else {
			if (x % 100 < 50)
				g.drawImage(img[0], x - cameraX, y - cameraY, null);
			else
				g.drawImage(img[1], x - cameraX, y - cameraY, null);

		}
	}
}
