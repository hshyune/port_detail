package Object.Parts;

import java.awt.Color;
import java.awt.Graphics2D;

import Core.Main;
import IMG.ResourceManager;
import Object.Container;
import Object.Projectile.Ammo;

public class MachineGun extends Weapon {
	static int runout[];
	int runoutIndex;
	int totShot;
	
	public MachineGun(int modelNum, int maxBullet, int shotDelay, int reloadDelay, int range, int damage, int totShot) {
		super(modelNum);
		this.reloadStartTime = 0;
		this.maxAngle = 50;
		this.minAngle = 50;
		this.L = ResourceManager.getInstance().getMG("L");
		this.R = ResourceManager.getInstance().getMG("R");
		this.shotLock = false;
		this.index = 0;
		this.drawX = x;
		this.drawY = y;
		runout = new int[5];
		for(int i=0;i<5;i++)
			if(i%2 ==0)
				runout[i] = i*2;
			else
				runout[i] = -(i*2-1);
		
		runoutIndex =0;
		
		this.range = range;
		this.damage = damage;
		this.maxBullet = maxBullet;
		this.curBullet = this.maxBullet;
		this.shotDelay = shotDelay;
		this.shotStart = shotDelay;
		this.reloadDelay = reloadDelay;
		this.totShot = totShot;
		weight = 1;
		
	}

	@Override
	public boolean canShot()
	{
		// delay
		if (shotStart < shotDelay) {
			return false;
		}
		
		// shotLock
		if (shotLock) {
			return false;
		}
		
		return true;
		
	}
	
	@Override
	public void shot() {
		
		
		

		// angle, start xy, team, damage
		int tmpAngle = curAngle;
		if (!foward) {
			if (tmpAngle == 0) {
				tmpAngle += 180;
			} else if (tmpAngle < 0) {
				tmpAngle = 180 - tmpAngle;
			} else if (curAngle > 0) {
				tmpAngle = (180 - tmpAngle);
			}	
		}
		
		int tmpShotX = foward? shotX : shotX +10;
		int tmpShotY = 0;
		
		if(tmpAngle ==0 || tmpAngle==180)
		{
			tmpShotY =  shotY;
		}
		else if(tmpAngle >180 || tmpAngle<0) 
		{
			if(master.getBottom() instanceof Copter)
				tmpShotY = shotY - 10;
			else
				tmpShotY = shotY;
		}
		else
		{
			if(master.getBottom() instanceof Copter)
				tmpShotY = shotY +13;
			else
				tmpShotY = shotY+10;
		}
		
		for(int i=0;i<totShot;i++)
		{
			if( runoutIndex == 4 ) runoutIndex = 0;
			else runoutIndex +=1;
			
			Main.camera.getProjList().add(new Ammo(this,curBullet,range, tmpAngle + runout[runoutIndex], tmpShotX,tmpShotY,team, damage, true,i*2+1));
			curBullet--;
		}
		
		
		shotStart = 0;
		
		// reload
		if (!shotLock && curBullet == 0) {
			setReload();
			return;
		}
		
	}

	@Override
	public void draw(Graphics2D g, int cameraX, int cameraY) {
		// TODO Auto-generated method stub
		if (foward)
			g.drawImage(R[index], drawX - cameraX, drawY - cameraY, null);
		else
			g.drawImage(L[index], drawX - cameraX, drawY - cameraY, null);
	}
	@Override
	public boolean update() {
		if (shotLock) {
			reloadStartTime++;
		}
		if (reloadStartTime >= reloadDelay) {
			reload();
		}
		if(shotStart < shotDelay)
			shotStart++;
		
		
		// set shot X Y
		if (foward) {
			if (curAngle < 10 && curAngle > -10) {
				// -10 < angle < 10
				index = 0;
				drawX = x;
				drawY = y - R[index].getHeight();
			}
			if (curAngle <= -10) {
				// -50 ~ -10
				index = (-curAngle) / 10;
				drawX = x;
				drawY = y - R[index].getHeight();
			}
			if (curAngle >= 10) {
				// 10 ~ 50
				index = (curAngle / 10) + 5;
				drawX = x;
				drawY = y - R[0].getHeight();
			}
		} else {
			if (curAngle < 10 && curAngle > -10) {
				// -10 < angle < 10
				index = 0;
				drawX = x - L[index].getWidth();
				drawY = y - L[index].getHeight();
			}
			if (curAngle <= -10) {
				// -50 ~ -10
				index = (-curAngle) / 10;
				drawX = x - L[index].getWidth();
				drawY = y - L[index].getHeight();
			}
			if (curAngle >= 10) {
				// 10 ~ 50
				index = (curAngle / 10) + 5;
				drawX = x - L[index].getWidth();
				drawY = y - L[0].getHeight();
			}
		}

		return false;
	}

	public void spinAngle(boolean pos) {
		// check angle bound
		if (curAngle > 50) {
			curAngle = 50;
		} else if (curAngle < -50) {
			curAngle = -50;
		}

		// up pos, down neg
		if (pos) {
			this.curAngle -= 2;
		} else {
			this.curAngle += 2;
		}
	}
}

