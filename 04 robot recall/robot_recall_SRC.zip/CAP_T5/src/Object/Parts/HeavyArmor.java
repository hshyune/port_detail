package Object.Parts;

import java.awt.Graphics2D;

import Core.Main;
import IMG.ResourceManager;
import Item.Barrier;
import Object.Projectile.Ammo;
import Object.Projectile.MGAmmo;
import Object.Projectile.Projectile;

public class HeavyArmor extends Top {

	public HeavyArmor(int modelNum, int maxHP, int skillDelay, int maxSkill) {
		// TODO Auto-generated constructor stub
		super(modelNum);
		this.img = ResourceManager.getInstance().getHeavy();
		this.width = img[0].getWidth();
		this.height = img[0].getHeight();

		this.skillDelay = skillDelay;
		this.skillStart = skillDelay;
		this.maxSkill = maxSkill;
		this.maxHP = maxHP;
		this.curSkill = this.maxSkill;
		this.HP = this.maxHP;
		
		weight = 2;
		
		
	}

	@Override
	public void draw(Graphics2D g, int cameraX, int cameraY) {
		// get bot x,y
		if (foward)
			g.drawImage(img[0], x - cameraX, y - cameraY, null);
		else
			g.drawImage(img[1], x - cameraX, y - cameraY, null);
		// TODO Auto-generated method stub
		drawHPBar(g, cameraX, cameraY);
	}
	
	@Override
	public void isShoot(Projectile other) {
		// TODO Auto-generated method stub
		int dmg = other.getDmg();
		
		if(other instanceof Ammo)
		{
			dmg *= 1.3;
		}
		else if(other instanceof MGAmmo)
		{
			dmg *= 0.75;
			if(dmg==0) dmg = 1;
		}
		
		HP = HP - dmg;
	}
	
	@Override
	public boolean update() {
		if (skillStart < skillDelay)
			skillStart++;
		return false;
	}
	@Override
	public void skill() {
		if (curSkill<= 0 || skillStart < skillDelay) {
			return;
		}
		if(!Main.gate.isActivated())
		{
			
			Barrier b;
			if (foward)
				b = new Barrier(team,-1,x + 100, y - 150, foward);
			else
				b = new Barrier(team,-1,x - 100, y - 150, foward);
			Main.camera.getObjList().add(b);
		}
		curSkill--;
		skillStart = 0;
	}

}
