package Object;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Line2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import IMG.ResourceManager;

public class Land extends GameObject {

	BufferedImage tile;
	
	public Land(int x, int y, int width, int height) {
		setLocation(x, y);
		this.width = width;
		this.height = height;
		tile = ResourceManager.getInstance().getLand()[0];
	}

	public BufferedImage makeImage(){
		
		try{
		/*
			BufferedImage originalImage = ImageIO.read(new File("block.jpg"));
			BufferedImage newImage = originalImage.getSubimage(350, 135, 50, 30);
			ImageIO.write(newImage, "jpg", new File("block1.jpg"));
		*/
			
			BufferedImage tileImage = ImageIO.read(new File("bin/IMG/robot.png"));
			
			BufferedImage mergedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
			Graphics2D graphics = (Graphics2D) mergedImage.getGraphics();
			
			int tmp_width = (width / tileImage.getWidth())+2;
			int tmp_height = (height/ tileImage.getHeight())+1;
			
			for(int i=0; i<tmp_width; i++){
				for(int j=0; j<tmp_height; j++){
					graphics.drawImage(tileImage, i*tileImage.getWidth(), j*tileImage.getHeight(), null);
				}
			}
			return mergedImage;
	
			
		} catch (IOException ioe) {
		ioe.printStackTrace();
		}
		return null;
	}
	
	@Override
	public void draw(Graphics2D g, int cameraX, int cameraY) {
		// TODO Auto-generated method stub
		//BufferedImage img= makeImage();
		int dx = x-cameraX;
		int dy = y-cameraY;
		for(int i=0;i<width;i+=74)
			g.drawImage(tile, dx+i, dy, (i+74)>width ? dx+width:(dx+i+74), dy+height, 0,0,74,height, null);
		g.setColor(ResourceManager.makeColorRGBA(0, 0, 0, 200));
		g.drawRect(dx,dy, width, height);
	}

	@Override
	public boolean update() {
		// TODO Auto-generated method stub
		return false;
	}

	public Line2D getTopLine() {
		return new Line2D.Float(x, y, x + width, y);
	}

	@Override
	public void genAftObj() {
		// TODO Auto-generated method stub
		
	}
}
