package Object.Effect;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.Stroke;
import java.util.Random;

import Object.GameObject;

public class Boom extends GameObject{

		int x, y, i = 0, j = 0, k = 0, size;
		int angle = 10;
		int[] ran_num;
		double radcal = Math.PI / 180;
		int xpos1, ypos1, xpos2, ypos2, xpos3, ypos3;
		int stroke = 8;
		int strNum=1;
		int distance = 0;
		GameObject mother;
		Color c;
		Random random;
		int speed;
		boolean t = true;

		public Boom(GameObject mother,int size, Color c) {
			random = new Random();
			ran_num = new int[8];
			for (int cnt = 0; cnt < 8; cnt++) {
				ran_num[cnt] = random.nextInt(45);
			}
			this.mother = mother;
			x = mother.getX()+size/2;
			y = mother.getY()+size/3;
			angle = (int)(Math.random()*360);
			this.c = c;
			this.speed = 12;
			this.size = size;
			this.stroke = size/10> 5 ? 5 : size/10;
		}
		
		@Override
		public boolean update()
		{
			i+=speed;
			j+=speed;
			k+=speed;
			
			if(size/5*strNum <=i)
			{
				stroke = stroke/5 * (6-strNum);
				strNum+=1;
			}
			
			if(i>=size) return true;
			else return false;
		}
		
		@Override
		public void draw(Graphics2D g,int cameraX,int cameraY) {
			

			
			g.setColor(c);
			Stroke stk = g.getStroke();
			
			x -= cameraX;
			y -= cameraY;

			Polygon p1 = new Polygon();
			//Polygon p2 = new Polygon();
			//Polygon p3 = new Polygon();
			Color c = g.getColor();
			xpos1 = (int) (x + ( + i) * Math.cos((angle + 45) * radcal));
			ypos1 = (int) (y + ( + i) * Math.sin((angle + 45) * radcal));
			xpos2 = (int) (x + ( + j) * Math.cos((angle + 45) * radcal));
			ypos2 = (int) (y + ( + j) * Math.sin((angle + 45) * radcal));
			xpos3 = (int) (x + ( + k) * Math.cos((angle + 45) * radcal));
			ypos3 = (int) (y + ( + k) * Math.sin((angle + 45) * radcal));

			g.setStroke(new BasicStroke(stroke<=0 ? 1 : stroke,1,1));
			if(i>24){
			for (int cnt = 0; cnt < 8; cnt++) {
				if (distance <= size ) {
					g.drawLine((int) (x + distance * Math.cos((ran_num[cnt] + 45 * cnt) * radcal)),
							(int) (y + distance * Math.sin((ran_num[cnt] + 45 * cnt) * radcal)),
							(int) (x + (distance+50 -(int)(50*((double)(distance+1)/(double)(size+1)))) * Math.cos((ran_num[cnt] + 45 * cnt) * radcal)),
							(int) (y + (distance+50 -(int)(50*((double)(distance+1)/(double)(size+1)))) * Math.sin((ran_num[cnt] + 45 * cnt) * radcal))
							);
					distance += 2;
				}
			}
			}
			
			g.setStroke(new BasicStroke(stroke));
			if (i < size) {
				p1.addPoint(xpos1, ypos1);
				p1.addPoint((int) (x + ( + i) * Math.cos((angle + 135) * radcal)),
						(int) (y + ( + i) * Math.sin((angle + 135) * radcal)));
				p1.addPoint((int) (x + ( + i) * Math.cos((angle + 225) * radcal)),
						(int) (y + ( + i) * Math.sin((angle + 225) * radcal)));
				p1.addPoint((int) (x + ( + i) * Math.cos((angle + 315) * radcal)),
						(int) (y + ( + i) * Math.sin((angle + 315) * radcal)));
				g.drawPolygon(p1);
			}

			g.setColor(c);

			g.setStroke(stk);
			x += cameraX;
			y += cameraY;
		}
		
		@Override
		public void genAftObj() {
			// TODO Auto-generated method stub
			
		}
}
