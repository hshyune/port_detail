package Object.Projectile;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Stroke;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;

import Core.Main;
import Core.Sock;
import IMG.ResourceManager;
import Interfaces.Hitable;
import Object.GameObject;
import Object.Effect.Boom;
import Object.Parts.Weapon;

public class Missle extends Projectile {

	// �̻��� �׸��� �ʿ�
	private int xpos,ypos,r=-25,r2=0,r3=25;
	private int stroke = 4;
	private int length = 20;
	

	
	// ������

	public Missle(Weapon mother, int id,int range, int angle, int startX, int startY, byte team, int damage, int preload) {

		super(mother,id,angle, team, damage);
		setLocation(startX, startY);
		this.width = 20;
		this.height = 20;
		this.life = 1;
		this.range = range;
		this.dstX = x + (int)(range * Math.cos((angle) *radcal));
		this.dstY = y + (int)(range * Math.sin((angle) *radcal));
		this.width = 20;
		this.height = 20;
		this.preload = preload;

		if(team == Sock.TRED)
			c = ResourceManager.makeColorRGBA(255, 0, 0, 255);
		else if(team == Sock.TBLUE)
			c = ResourceManager.makeColorRGBA(0, 148, 255, 255);
	}
	
	// GAME OBJECT

	@Override
	public void genAftObj() {
		if(life == 0)
		{
			if(team == Sock.TRED)
				Main.camera.getObjList().add(new Boom(this,100,ResourceManager.makeColorRGBA(255, 0, 0, 255)));	
			else if(team == Sock.TBLUE)
				Main.camera.getObjList().add(new Boom(this,100,ResourceManager.makeColorRGBA(0, 148, 255, 255)));
			else
				Main.camera.getObjList().add(new Boom(this,100,Color.WHITE));	
		}
	}
	
	@Override
	public boolean update() {
		
		if(preload>0){ 
			preload--;
			return false;
		}
		
		x+=(range/10 * Math.cos((angle ) *radcal));
		y+=(range/10 * Math.sin((angle ) *radcal));

		if(r>25)
			r=-26;
		if(r2>25)
			r2=-26;
		if(r3>25)
			r3=-26;
		r+=2;
		r2+=2;
		r3+=2;
		
		if( (angle >90 && angle < 270) ? dstX  >= x : dstX <=x) return true;
		//r+=speed;
		return false;
	}
	
	@Override
	public void draw(Graphics2D g, int cameraX, int cameraY) {
		// TODO Auto-generated method stub
		Stroke stk = g.getStroke();
		g.setStroke(new BasicStroke(stroke));

		g.setColor(ResourceManager.makeColorRGBA(38, 38, 38, 255));
		
		x -= cameraX;
		y -= cameraY;
		
		xpos=(int)(x+length * Math.cos((angle) * radcal));
		ypos=(int)(y+ length *  Math.sin((angle) * radcal)); 
		for(int i=-14;i<14;i++){
			g.drawLine( (int)(xpos+i*Math.sin((-angle)*radcal)),(int)(ypos+i*Math.cos((-angle)*radcal)),
					(int)(x+i*Math.sin((-angle)*radcal)),(int)(y+i*Math.cos((-angle)*radcal)));
		}


		for(int i=angle-90;i<angle+90;i++){
			g.drawLine(xpos , ypos,
					xpos + (int) (14 * Math.cos(i * radcal)), ypos + (int) (14 * Math.sin(i * radcal)));
		}

		xpos=(int)(x+(10) * Math.cos((angle+180) * radcal));
		ypos=(int)(y+ (10) *  Math.sin((angle+180) * radcal));
		g.setStroke(new BasicStroke(8));
		g.drawLine(xpos, ypos, (int)(xpos+14*Math.cos((angle+90)*radcal)), (int)(ypos+14*Math.sin((angle+90)*radcal)));
		g.drawLine(xpos, ypos, (int)(xpos+14*Math.cos((angle+270)*radcal)), (int)(ypos+14*Math.sin((angle+270)*radcal)));
		
		g.setColor(c);
		g.setStroke(new BasicStroke(8));
		g.drawLine( (int)(xpos+r*Math.sin((-angle)*radcal)),(int)(ypos+r*Math.cos((-angle)*radcal)),
					(int)(x+14 * Math.cos((angle+180) * radcal)+r*Math.sin((-angle)*radcal)),(int)(y+14 * Math.sin((angle+180) * radcal)+r*Math.cos((-angle)*radcal)));
		g.drawLine( (int)(xpos+(r2)*Math.sin((-angle)*radcal)),(int)(ypos+(r2)*Math.cos((-angle)*radcal)),
				(int)(x+14 * Math.cos((angle+180) * radcal)+(r2)*Math.sin((-angle)*radcal)),(int)(y+14 * Math.sin((angle+180) * radcal)+(r2)*Math.cos((-angle)*radcal)));
		g.drawLine( (int)(xpos+(r3)*Math.sin((-angle)*radcal)),(int)(ypos+(r3)*Math.cos((-angle)*radcal)),
				(int)(x+14 * Math.cos((angle+180) * radcal)+(r3)*Math.sin((-angle)*radcal)),(int)(y+14 * Math.sin((angle+180) * radcal)+(r3)*Math.cos((-angle)*radcal)));

		

		g.setStroke(stk);
		x += cameraX;
		y += cameraY;
	}

	
	//PROJECTILE
	
	@Override
	public boolean isCollision(GameObject other) {
		// TODO Auto-generated method stub
		Rectangle2D bound = new Rectangle2D.Float(x, y, width, height);
		if (bound.intersects(other.getBound())) {
			return true;
		} else
			return false;
	}

	@Override
	public void isShoot(Projectile other) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void attack() {
		// TODO Auto-generated method stub
		if(preload>0) return;
		if(life ==0) return;
		
		ArrayList<GameObject> objectList = Main.camera.getObjList();
		for (GameObject tmp : objectList) {
			if (tmp instanceof Hitable) {
				if (this.isCollision(tmp) && team != tmp.team) {
					if(!Main.gate.isActivated())
					{
						((Hitable) tmp).isShoot(this);
						Main.camera.vib = 7;
					}
					life = 0;
					setEndPoint(this.x, this.y);
				}

			}
		}
	}
}
