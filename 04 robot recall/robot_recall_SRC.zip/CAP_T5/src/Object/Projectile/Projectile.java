package Object.Projectile;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;

import Core.Main;
import Core.Sock;
import IMG.ResourceManager;
import Interfaces.Hitable;
import Object.GameObject;
import Object.Effect.Boom;
import Object.Parts.Weapon;

public abstract class Projectile extends GameObject implements Hitable{

	
	public static final double radcal = Math.PI / 180;
	
	protected int angle, damage, life;

	
	// hitscan
	protected Weapon mother;
	protected int range;
	protected int dstX, dstY;
	protected Line2D scan;
	protected Point2D endPoint;
	protected boolean foward;
	protected int preload;
	protected int tail;
	protected Color c;

	public Projectile() {
		
	}

	public Projectile(Weapon mother, int id,int angle, byte team, int damage) {
		this.mother = mother;
		this.id = id;
		this.angle = angle;
		this.team = team;
		this.damage = damage;

	}

	@Override
	public void genAftObj()
	{
		if(life == 0)
		{
			if(team == Sock.TRED)
				Main.camera.getObjList().add(new Boom(this,60,ResourceManager.makeColorRGBA(255, 0, 0, 255)));	
			else if(team == Sock.TBLUE)
				Main.camera.getObjList().add(new Boom(this,60,ResourceManager.makeColorRGBA(0, 148, 255, 255)));
			else
				Main.camera.getObjList().add(new Boom(this,60,Color.WHITE));	
		}
	}
	
	@Override
	public void draw(Graphics2D g, int cameraX, int cameraY) {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean update() {
		// TODO Auto-generated method stub
		return false;
	}

	public int getDmg() {
		return this.damage;
	}


	abstract public void attack();
	
	public boolean equalId(int motherId, int objId)
	{
		if(mother.id == motherId &&this.id ==objId)
			return true;
		else
			return false;
	}
	
	public void setEndPoint(int x, int y)
	{
		dstX = x;
		dstY = y;
	}
}
