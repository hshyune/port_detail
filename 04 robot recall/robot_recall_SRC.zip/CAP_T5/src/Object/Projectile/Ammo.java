package Object.Projectile;

import java.awt.BasicStroke;
import java.awt.Graphics2D;
import java.awt.Stroke;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.util.ArrayList;

import Core.Main;
import Core.Sock;
import IMG.ResourceManager;
import Interfaces.Hitable;
import Object.GameObject;
import Object.Parts.Weapon;

public class Ammo extends Projectile {
	

	// ������

	public Ammo() {
	}

	public Ammo(Weapon mother, int id,int range, int angle, int startX, int startY, byte team, int damage, boolean foward, int preload) {
		super(mother,id,angle, team, damage);
		setLocation(startX, startY);
		this.life = 1;
		this.range = range;
		this.dstX =  x + (int)(range * Math.cos((angle) *radcal)); //(int) (Math.cos(Math.toRadians(angle)) * range);
		this.dstY =  y + (int)(range * Math.sin((angle) *radcal)); //(int) (Math.sin(Math.toRadians(angle)) * range);
		this.foward = foward;
		this.scan = new Line2D.Float(x, y, dstX, dstY);
		if(team == Sock.TRED)
			c = ResourceManager.makeColorRGBA(255, 0, 0, 255);
		else if(team == Sock.TBLUE)
			c = ResourceManager.makeColorRGBA(0, 148, 255, 255);
		this.preload =preload;
		this.tail = 0;
	}

	// GameObject ���
	
	@Override
	public void draw(Graphics2D g, int cameraX, int cameraY) {
		// TODO Auto-generated method stub
		
		if( (angle >90 && angle < 270) ? dstX  >= x : dstX <=x) return;
		
		Stroke stk = g.getStroke();
		g.setStroke(new BasicStroke(3));
		
		
		g.setColor(ResourceManager.makeColorRGBA(c.getRed(),c.getGreen(),c.getBlue(),150));
		g.drawLine(x- cameraX, y - cameraY, 
				(int)((x-cameraX)+((double)tail*0.3)*Math.cos((angle+180)*radcal)),(int)( (y-cameraY)+((double)tail*0.3)*Math.sin((angle+180)*radcal)));
		
		g.setColor(ResourceManager.makeColorRGBA(c.getRed(),c.getGreen(),c.getBlue(),100));
		g.drawLine((int)((x-cameraX)+((double)tail*0.3)*Math.cos((angle+180)*radcal)), (int)( (y-cameraY)+((double)tail*0.3)*Math.sin((angle+180)*radcal))
				, (int)((x-cameraX)+((double)tail*0.7)*Math.cos((angle+180)*radcal)),(int)( (y-cameraY)+((double)tail*0.7)*Math.sin((angle+180)*radcal)));
		
		g.setColor(ResourceManager.makeColorRGBA(c.getRed(),c.getGreen(),c.getBlue(),50));
		g.drawLine((int)((x-cameraX)+((double)tail*0.7)*Math.cos((angle+180)*radcal)), (int)( (y-cameraY)+((double)tail*0.7)*Math.sin((angle+180)*radcal))
				, (int)((x-cameraX)+((double)tail*1.0)*Math.cos((angle+180)*radcal)),(int)( (y-cameraY)+((double)tail*1.0)*Math.sin((angle+180)*radcal)));
		
		g.setColor(ResourceManager.makeColorRGBA(38, 38, 38, 255));
		int xpos = (int) (x + 10 * Math.cos((angle ) * radcal));
		int ypos = (int) (y + 10 * Math.sin((angle ) * radcal));
		for (int i = -5; i < 5; i++) {
			g.drawLine((int) (x- cameraX + i * Math.sin((-angle) * radcal) ),
					(int) ((y- cameraY + i * Math.cos((-angle) * radcal) )), xpos-cameraX, ypos-cameraY);

		}
		
		g.setStroke(stk);
	}

	@Override
	public boolean update() {
		
		if(preload >0)
		{
			preload --;
			return false;
		}
		
		int nextX = (int)(range/8 * Math.cos((angle ) *radcal));
		int nextY =	(int)(range/8 * Math.sin((angle ) *radcal));
		scan = new Line2D.Float(x, y, x +nextX, y + nextY);
		x+= nextX;
		y+= nextY;
		
		
		if(tail < range/4)
			tail += range/16;
		
		if( (angle >90 && angle < 270) ? dstX  >= x : dstX <=x) return true;
		
		return false;
	}
	
	public Point2D getCollisionPoint(GameObject other) {
		int x, y;

		double a = (scan.getY2() - scan.getY1()) / (scan.getX2() - scan.getX1());
		double b = scan.getY1() - scan.getX1() * a;

		if (foward) {
			x = (int) other.getBound().getMinX();
			y = (int) (a * x + b);
		} else {
			x = (int) other.getBound().getMaxX();
			y = (int) (a * x + b);
		}
		// System.out.println(x + " " + y + " / " + getDistance(x, y));
		return new Point2D.Float(x, y);
	}

	public int getDistance(Point2D p) {
		int diffX = this.x - (int) p.getX();
		int diffY = this.y - (int) p.getY();
		int result = (int) Math.sqrt((double) (diffX * diffX + diffY * diffY));
		return result;
	}
	
	public void setEndPoint(Point2D p) {
		this.endPoint = p;
		this.dstX = (int) p.getX();
		this.dstY = (int) p.getY();
		scan.setLine(new Point2D.Float(x, y), new Point2D.Float(dstX, dstY));
		
	}
	
	// PROJECTILE ���
	
	@Override
	public void attack()
	{
		if(preload>0) return;
		if(life ==0 ) return;
		
		ArrayList<GameObject> tmpList = new ArrayList<GameObject>();
		ArrayList<GameObject> objectList = Main.camera.getObjList();
		for (GameObject tmp : objectList) {
			if (tmp instanceof Hitable) {
				if (this.isCollision(tmp)) {
					if(tmp.team != this.team)
						tmpList.add(tmp);

				}
			}
		}
		
		if (tmpList.size() != 0) {
			int distance = 9999;
			int index = 9999;
			int min = 9999;
			for (int j = 0; j < tmpList.size(); j++) {
				
				distance = this.getDistance(this.getCollisionPoint(tmpList.get(j)));
				
				if (distance < min) {
					min = distance;
					index = j;
				}
			}
			this.setEndPoint(this.getCollisionPoint(tmpList.get(index)));
			life = 0;
			if(!Main.gate.isActivated())
			{
				((Hitable) tmpList.get(index)).isShoot(this);
				Main.camera.vib = 3;
			}
		}
	}
	
	// HITABLE
	
	@Override
	public boolean isCollision(GameObject other) {
		// TODO Auto-generated method stub
		if (scan.intersects(other.getBound())) {
			return true;
		} else
			return false;
	}

	@Override
	public void isShoot(Projectile other) {
		// TODO Auto-generated method stub
		
	}

}
