package Object;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import Core.Sock;

public abstract class GameObject {
	
	public int id;
	protected int x;
	protected int y;
	protected int width;
	protected int height;
	protected boolean life;
	protected int HP;
	protected int maxHP;
	public byte team;

	public GameObject() {
		this.id = -1;
		this.team = Sock.TNONE;
	}

	abstract public void draw(Graphics2D g, int cameraX, int cameraY);

	abstract public boolean update();
	
	abstract public void genAftObj();

	public void setLocation(int x, int y) {
		this.x = x;
		this.y = y;
	}

	public Rectangle2D getBound() {
		return new Rectangle2D.Float(this.x, this.y, this.width, this.height);
	}

	public int getWidth() {
		return this.width;
	}

	public int getHeight() {
		return this.height;
	}
	
	public int getX() {
		return this.x;
	}

	public int getY() {
		return this.y;
	}
	
	
	public void setHP(int HP)
	{
		this.HP = HP;
	}
	
	public int getMaxHP(){
		return this.maxHP;
	}
	
	public int getHP() {
		return this.HP;
	}
	
	public void hurtSync(int point, boolean isUp)
	{
		if(isUp)
			HP = HP+point > maxHP ? maxHP : HP + point;
		else
			HP = HP-point < 0 ? 0 : HP - point;
	}
	
}
