package IMG;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.*;
import javax.imageio.ImageIO;

//single-tone pattern
public class ResourceManager {
	static ResourceManager instance = new ResourceManager();

	public static ResourceManager getInstance() {
		return instance;
	}

	private BufferedImage[] TopImg = new BufferedImage[6];
	private BufferedImage[] HArmorImg = new BufferedImage[2];
	private BufferedImage[] FArmorImg = new BufferedImage[2];

	private BufferedImage[] BotImg = new BufferedImage[12];
	private BufferedImage[] BotQuadImg = new BufferedImage[3];
	private BufferedImage[] CopterImg = new BufferedImage[2];

	private BufferedImage[] MGImgL = new BufferedImage[11];
	private BufferedImage[] MGImgR = new BufferedImage[11];

	private BufferedImage[] RFImgL = new BufferedImage[11];
	private BufferedImage[] RFImgR = new BufferedImage[11];

	private BufferedImage[] RLImgL = new BufferedImage[11];
	private BufferedImage[] RLImgR = new BufferedImage[11];

	private BufferedImage[] shot = new BufferedImage[1];
	private BufferedImage[] heal = new BufferedImage[4];

	private BufferedImage[] barrier = new BufferedImage[2];

	private BufferedImage[] flame = new BufferedImage[1];

	private BufferedImage background;
	private BufferedImage[] land = new BufferedImage[3];

	private BufferedImage title;

	
	private ResourceManager() {
		try {
			// putting img
			File path = new File("./src/IMG");
			String dir = path.getAbsolutePath();
			System.out.println(dir);

			title = ImageIO.read(new File(dir + "\\title.png"));
			
			BotImg[0] = ImageIO.read(new File(dir + "\\Bottom\\Biwalk\\bot_bi_1_L.png"));
			BotImg[1] = ImageIO.read(new File(dir + "\\Bottom\\Biwalk\\bot_bi_2_L.png"));
			BotImg[2] = ImageIO.read(new File(dir + "\\Bottom/Biwalk/bot_bi_1_R.png"));
			BotImg[3] = ImageIO.read(new File(dir + "\\Bottom\\Biwalk\\bot_bi_2_R.png"));

			for (int i = 0; i < 3; i++) {
				BotQuadImg[i] = ImageIO
						.read(new File(dir + "\\Bottom\\Quad\\quad_" + Integer.toString(i + 1) + ".png"));
			}
			
			CopterImg[0] = ImageIO.read(new File(dir + "\\Bottom\\Copter\\copter1.png"));
			CopterImg[1] = ImageIO.read(new File(dir + "\\Bottom\\Copter\\copter2.png"));
			
			HArmorImg[0] = ImageIO.read(new File(dir + "\\Top\\Heavy\\ha_1.png"));
			HArmorImg[1] = ImageIO.read(new File(dir + "\\Top\\Heavy\\ha_2.png"));

			FArmorImg[0] = ImageIO.read(new File(dir + "\\Top\\Flate\\fa_0.png"));
			FArmorImg[1] = ImageIO.read(new File(dir + "\\Top\\Flate\\fa_1.png"));

			TopImg[0] = ImageIO.read(new File(dir + "\\Top\\LightArmor\\Top_R.png"));
			TopImg[1] = ImageIO.read(new File(dir + "\\Top\\LightArmor\\Top_L.png"));

			for (int i = 0; i < 11; i++) {
				String index = Integer.toString(i);
				MGImgL[i] = ImageIO.read(new File(dir + "\\Weapon\\MachineGun\\L\\MG_" + index + ".png"));
				MGImgR[i] = ImageIO.read(new File(dir + "\\Weapon\\MachineGun\\R\\MG_" + index + ".png"));
			}

			for (int i = 0; i < 11; i++) {
				String index = Integer.toString(i);
				RFImgL[i] = ImageIO.read(new File(dir + "\\Weapon\\Rifle\\L\\rf_" + index + ".png"));
				RFImgR[i] = ImageIO.read(new File(dir + "\\Weapon\\Rifle\\R\\rf_" + index + ".png"));
			}

			for (int i = 0; i < 11; i++) {
				String index = Integer.toString(i);
				RLImgL[i] = ImageIO.read(new File(dir + "\\Weapon\\Rocket\\L\\rk_" + index + ".png"));
				RLImgR[i] = ImageIO.read(new File(dir + "\\Weapon\\Rocket\\R\\rk_" + index + ".png"));
			}

			for (int i = 0; i < 4; i++) {
				String index = Integer.toString(i);
				heal[i] = ImageIO.read(new File(dir + "\\Item\\HealPack\\hp_" + index + ".png"));
			}

			barrier[0] = ImageIO.read(new File(dir + "\\Item\\Barrier\\ba_R.png"));
			barrier[1] = ImageIO.read(new File(dir + "\\Item\\Barrier\\ba_L.png"));

			flame[0] = ImageIO.read(new File(dir + "\\Effect\\Flame\\flame.png"));

			background = ImageIO.read(new File(dir + "\\BG\\BG_city.png"));

			land[0] = ImageIO.read(new File(dir + "\\Land\\land1.png"));
			land[1] = ImageIO.read(new File(dir + "\\Land\\land2.png"));
			land[2] = ImageIO.read(new File(dir + "\\Land\\land3.png"));

			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public BufferedImage getTitle() {
		return this.title;
	}
	
	public BufferedImage[] getTopImage() {
		return this.TopImg;
	}

	public BufferedImage[] getBottomImage() {
		return this.BotImg;
	}

	public BufferedImage[] getQuad() {
		return this.BotQuadImg;
	}

	public BufferedImage[] getMG(String str) {
		if (str.equals("L")) {
			return this.MGImgL;
		} else if (str.equals("R")) {
			return this.MGImgR;
		} else {
			return null;
		}
	}

	public BufferedImage[] getRifle(String str) {
		if (str.equals("L")) {
			return this.RFImgL;
		} else if (str.equals("R")) {
			return this.RFImgR;
		} else {
			return null;
		}
	}

	public BufferedImage[] getRocket(String str) {
		if (str.equals("L")) {
			return this.RLImgL;
		} else if (str.equals("R")) {
			return this.RLImgR;
		} else {
			return null;
		}
	}

	public BufferedImage[] getShot() {
		return shot;
	}

	public BufferedImage[] getHeavy() {
		return HArmorImg;
	}

	public BufferedImage[] getFlate() {
		return FArmorImg;
	}

	public BufferedImage[] getHeal() {
		return heal;
	}

	public BufferedImage[] getBarrier() {
		return barrier;
	}

	public BufferedImage getFlame() {
		return flame[0];
	}

	public BufferedImage getBG() {
		return background;
	}

	public BufferedImage[] getLand() {
		return this.land;
	}
	
	public BufferedImage[] getCopter(){
		return this.CopterImg;
	}
	
	public static Color makeColorRGBA(int r, int g, int b, int a)
	{
		return new Color( (float)r/255, (float)g/255, (float)b/255, (float)a/255);
	}
	

}
