package Item;

import java.awt.Color;
import java.awt.Graphics2D;

import Core.Main;
import Core.Sock;
import IMG.ResourceManager;
import Object.Effect.Boom;

public class Barrier extends Item {

	boolean foward;

	public Barrier( byte team,int id,int x, int y, boolean foward) {
		super(id,x, y);
		this.foward = foward;
		this.team = team;
		this.maxHP = 800;
		this.HP = maxHP;
		img = ResourceManager.getInstance().getBarrier();
		// 43 117
		this.width = 43;
		this.height = 117;
		// TODO Auto-generated constructor stub
	}

	@Override
	public void genAftObj()
	{
		Main.camera.getObjList().add(new Boom(this,117,Color.WHITE));
	}
	
	@Override
	public boolean update() {
		if (isFloating()) {
			jumpDown();
		}
		if (HP <= 0)
			return true;
		return false;
	}

	@Override
	public void draw(Graphics2D g, int cameraX, int cameraY) {
		// TODO Auto-generated method stub
		int index;
		if (foward)
			index = 0;
		else
			index = 1;
		g.drawImage(img[index], x - cameraX, y - cameraY, null);
		drawHPBar(g, cameraX, cameraY);
	}

	public void drawHPBar(Graphics2D g, int cameraX, int cameraY) {
		// width 60 height 5
		int blankY = 20;
		int length = 40;
		g.setColor(Color.black);
		g.drawRect(x - cameraX, y - cameraY - blankY, length + 2, 5 + 2);

		int percentage = (int) ((length + 1) * ((double) HP / (double) maxHP));
		if(team == Sock.TRED)
			g.setColor(ResourceManager.makeColorRGBA(114, 14, 5, 255));
		else if(team == Sock.TBLUE)
			g.setColor(ResourceManager.makeColorRGBA(5, 14, 114, 255));
		else
			g.setColor(ResourceManager.makeColorRGBA(5, 114, 14, 255));
		g.fillRect(x - cameraX + 1, y - cameraY - blankY + 1, percentage, 6);
	}
}
