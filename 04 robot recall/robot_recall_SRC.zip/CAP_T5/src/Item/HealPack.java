package Item;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import IMG.ResourceManager;
import Interfaces.Hitable;
import Object.GameObject;

public class HealPack extends Item {

	int life;
	int heal;
	boolean isEatable;

	public HealPack(int id,int x, int y) {
		super(id,x, y);
		img = ResourceManager.getInstance().getHeal();
		this.width = img[0].getWidth();
		this.height = img[0].getHeight();
		this.life = 1;
		this.heal = 250;
		this.maxHP =50;
		this.HP = this.maxHP;
		this.isEatable = false;

		// TODO Auto-generated constructor stub
	}

	public boolean update() {
		if (isFloating()) {
			jumpDown();
		}else{
			isEatable = true;
		}
		if(life == 0 || HP <= 0)
			return true;
		return false;
	}

	@Override
	public void draw(Graphics2D g, int cameraX, int cameraY) {
		// TODO Auto-generated method stub
		g.drawImage(img[1], x - cameraX, y - cameraY, null);
	}
	
	@Override
	public boolean isCollision(GameObject other) {
		// TODO Auto-generated method stub
		if(this.getBound().intersects(other.getBound()) && isEatable){
			return true;
		}
		return false;
	}
	
	public int getHeal(){
		this.life = 0;
		return heal;
	}

}
