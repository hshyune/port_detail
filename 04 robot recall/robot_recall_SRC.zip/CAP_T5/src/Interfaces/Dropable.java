package Interfaces;

public interface Dropable {
	public boolean isFloating();
	public int getLandingPoint();
	public void jumpDown();
}
