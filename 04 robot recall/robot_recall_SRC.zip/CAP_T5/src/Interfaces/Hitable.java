package Interfaces;

import Object.GameObject;
import Object.Projectile.Projectile;

public interface Hitable {
	public boolean isCollision(GameObject other);

	public void isShoot(Projectile other);
}
