package Core;

import java.awt.Font;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;

import IMG.ResourceManager;

public class IdCard {

	private String strId;
	private JLabel team;
	private JLabel icon;
	private JLabel id;
	private JLabel ready;
	
	
	public IdCard()
	{
		
		team = new JLabel();
        team.setOpaque(true);
        team.setHorizontalAlignment(SwingConstants.CENTER);
        team.setBorder(new BevelBorder(BevelBorder.RAISED));
        team.setForeground(ResourceManager.makeColorRGBA(212,147,38,255));
        team.setFont(new Font("", Font.BOLD, 20));
        team.setBackground(ResourceManager.makeColorRGBA(38,38,38,255));
		
        icon = new JLabel();
        icon.setOpaque(true);
        icon.setHorizontalAlignment(SwingConstants.CENTER);
        icon.setBorder(new BevelBorder(BevelBorder.RAISED));
        icon.setForeground(ResourceManager.makeColorRGBA(212,147,38,255));
        icon.setFont(new Font("", Font.BOLD, 20));
        icon.setBackground(ResourceManager.makeColorRGBA(38,38,38,255));
        //icon.setBounds(15, 460, 785, 38);
        
        id = new JLabel();
        id.setOpaque(true);
        id.setHorizontalAlignment(SwingConstants.CENTER);
        id.setBorder(new BevelBorder(BevelBorder.RAISED));
        id.setForeground(ResourceManager.makeColorRGBA(38,38,38,255));
        id.setFont(new Font("", Font.BOLD, 20));
        id.setBackground(ResourceManager.makeColorRGBA(110,80,64,255));
        //id.setBounds(15, 460, 785, 38);
        
        ready = new JLabel("READY");
        ready.setOpaque(true);
        ready.setHorizontalAlignment(SwingConstants.CENTER);
        ready.setBorder(new BevelBorder(BevelBorder.RAISED));
        ready.setForeground(ResourceManager.makeColorRGBA(212,147,38,255));
        ready.setFont(new Font("", Font.BOLD, 20));
        ready.setBackground(ResourceManager.makeColorRGBA(38,38,38,255));
        //ready.setBounds(15, 460, 785, 38);
	}
	
	public void add(JPanel master, int x, int y)
	{
		team.setBounds(x,y,30,60);
		icon.setBounds(x+30,y,170,60);
		id.setBounds(x+200,y,450,60);
		ready.setBounds(x+650,y,135,60);
		
		master.add(team);
		master.add(icon);
		master.add(id);
		master.add(ready);
	}
	
	public void setTeam(byte team)
	{
		switch(team)
		{
		case Sock.TNONE:
			this.team.setBackground(ResourceManager.makeColorRGBA(38,38,38,255));
			break;
		case Sock.TRED:
			this.team.setBackground(ResourceManager.makeColorRGBA(255, 0, 0,255));
			break;
		case Sock.TBLUE:
			this.team.setBackground(ResourceManager.makeColorRGBA(0, 148, 255,255));
			break;
		}
	}
	
	public void setId(String name)
	{
		strId = name;
		id.setText(strId);
	}
	
	public String getId()
	{
		return strId;
	}
	
	public void setReady(boolean isReady)
	{
		if(isReady)
		{
			ready.setForeground(ResourceManager.makeColorRGBA(38,38,38,255));
			ready.setBackground(ResourceManager.makeColorRGBA(212,147,38,255));
		}
		else
		{
			ready.setForeground(ResourceManager.makeColorRGBA(212,147,38,255));
			ready.setBackground(ResourceManager.makeColorRGBA(38,38,38,255));
		}
	}
}
