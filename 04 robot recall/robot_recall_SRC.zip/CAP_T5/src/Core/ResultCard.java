package Core;

import java.awt.Font;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;

import IMG.ResourceManager;

public class ResultCard {

	private JLabel team;
	private JLabel id;
	private JLabel deal;
	private JLabel score;
	
	
	public ResultCard(int index)
	{
		
		team = new JLabel();
        team.setOpaque(true);
        team.setHorizontalAlignment(SwingConstants.CENTER);
        team.setBorder(new BevelBorder(BevelBorder.RAISED));
        team.setForeground(ResourceManager.makeColorRGBA(212,147,38,255));
        team.setFont(new Font("", Font.BOLD, 20));
        team.setBackground(ResourceManager.makeColorRGBA(38,38,38,255));
        
        id = new JLabel(Main.waitr2.getUserName(index));
        id.setOpaque(true);
        id.setHorizontalAlignment(SwingConstants.CENTER);
        id.setBorder(new BevelBorder(BevelBorder.RAISED));
        id.setForeground(ResourceManager.makeColorRGBA(38,38,38,255));
        id.setFont(new Font("", Font.BOLD, 20));
        id.setBackground(ResourceManager.makeColorRGBA(110,80,64,255));
        //id.setBounds(15, 460, 785, 38);
        
        deal = new JLabel();
        deal.setOpaque(true);
        deal.setHorizontalAlignment(SwingConstants.CENTER);
        deal.setBorder(new BevelBorder(BevelBorder.RAISED));
        deal.setForeground(ResourceManager.makeColorRGBA(212,147,38,255));
        deal.setFont(new Font("", Font.BOLD, 20));
        deal.setBackground(ResourceManager.makeColorRGBA(38,38,38,255));
        //deal.setBounds(15, 460, 785, 38);
        
        score = new JLabel("");
        score.setOpaque(true);
        score.setHorizontalAlignment(SwingConstants.CENTER);
        score.setBorder(new BevelBorder(BevelBorder.RAISED));
        score.setForeground(ResourceManager.makeColorRGBA(212,147,38,255));
        score.setFont(new Font("", Font.BOLD, 20));
        score.setBackground(ResourceManager.makeColorRGBA(38,38,38,255));
        //score.setBounds(15, 460, 785, 38);
	}
	
	public void add(JPanel master, int x, int y)
	{
		team.setBounds(x,y,30,60);
		id.setBounds(x+30,y,450,60);
		score.setBounds(x+480,y,200,60);
		deal.setBounds(x+680,y,200,60);
		
		master.add(team);
		master.add(deal);
		master.add(id);
		master.add(score);
	}
	
	public void setTeam(byte team)
	{
		switch(team)
		{
		case Sock.TNONE:
			this.team.setBackground(ResourceManager.makeColorRGBA(38,38,38,255));
			break;
		case Sock.TRED:
			this.team.setBackground(ResourceManager.makeColorRGBA(255, 0, 0,255));
			break;
		case Sock.TBLUE:
			this.team.setBackground(ResourceManager.makeColorRGBA(0, 148, 255,255));
			break;
		}
	}
	
	public void setId(String name)
	{
		id.setText(name);
	}
	
	public void setDeal(int deal)
	{
		this.deal.setText(Integer.toString(deal));
	}
	
	public void setScore(int kill, int death)
	{
		score.setText(kill + " / " + death);
	}
	
}
