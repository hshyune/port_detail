package Core;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;

import IMG.ResourceManager;

public class LoginPage extends JPanel{
	
	private Main master;
	private boolean activated;
		

	private Logo logo;
	private JTextField id;
	private JTextField pw;
	private JButton btnLogin;
	private JButton btnSign; 
	private JButton btnSingle;
	private JLabel sysmsg;

	
	public LoginPage(Main master) 
	{
		this.master = master;
		this.setBounds(0,0,Main.WIDTH,Main.HEIGHT);
		this.setBackground(ResourceManager.makeColorRGBA(19,19,19,255));

		
		
		
		
		//////////////////////////////////////////////////////////
		// �� ������

		
		
		id = new JTextField();
		id.setBounds(351, 433, 325, 23);
		id.setForeground(ResourceManager.makeColorRGBA(212,147,38,255));
		id.setBackground(ResourceManager.makeColorRGBA(68, 68, 68, 255));
		id.setBorder(new BevelBorder(BevelBorder.RAISED));
		id.setColumns(20);
		id.addKeyListener(master);
		setLayout(null);
		this.add(id);
		pw = new JTextField();
		pw.setBounds(351, 483, 325, 23);
		pw.setForeground(ResourceManager.makeColorRGBA(212,147,38,255));
		pw.setBackground(ResourceManager.makeColorRGBA(68, 68, 68, 255));
		pw.setBorder(new BevelBorder(BevelBorder.RAISED));
		pw.setColumns(20);
		pw.addKeyListener(master);
		this.add(pw);
		
		
		
		
	
		// (Main.WIDTH/2 -205) :: �α��� �ڽ� �����ǥ
		
		btnLogin = new JButton("LOGIN");
		btnLogin.setBounds(351, 531, 150, 23);
		btnLogin.setFont(new Font("", Font.BOLD, 15));
		btnLogin.setForeground(Color.WHITE);
		btnLogin.setBackground(ResourceManager.makeColorRGBA(110,80,64,255));
		btnLogin.setBorder(new BevelBorder(BevelBorder.RAISED));
		btnLogin.setFocusPainted(false);
		btnLogin.addActionListener(master);
		this.add(btnLogin);
		
		
		btnSign = new JButton("SIGN");
		btnSign.setBounds(526, 531, 150, 23);
		btnSign.setFont(new Font("", Font.BOLD, 15));
		btnSign.setForeground(Color.WHITE);
		btnSign.setBackground(ResourceManager.makeColorRGBA(110,80,64,255));
		btnSign.setBorder(new BevelBorder(BevelBorder.RAISED));
		btnSign.setFocusPainted(false);
		btnSign.addActionListener(master);
		this.add(btnSign);
		
		btnSingle = new JButton("SINGLE MODE");
		btnSingle.setBounds(351, 561, 325, 25);
		btnSingle.setFont(new Font("", Font.BOLD, 15));
		btnSingle.setForeground(ResourceManager.makeColorRGBA(212,147,38,255));
		btnSingle.setBackground(ResourceManager.makeColorRGBA(68,68,68,255));
		btnSingle.setBorder(new BevelBorder(BevelBorder.RAISED));
		btnSingle.setFocusPainted(false);
		btnSingle.addActionListener(master);
		this.add(btnSingle);
		

        JLabel label = new JLabel("CONNECT _INFO");
        label.setBounds(307, 365, 410, 38);
        label.setOpaque(true);
        label.setHorizontalAlignment(SwingConstants.CENTER);
        label.setBorder(new BevelBorder(BevelBorder.RAISED));
        label.setForeground(ResourceManager.makeColorRGBA(133,161,144,255));
        label.setFont(new Font("", Font.BOLD, 20));
        label.setBackground(ResourceManager.makeColorRGBA(45,69,62,255));
        add(label);
        
        JLabel label_1 = new JLabel("ID");
        label_1.setBounds(351, 409, 55, 23);
        label_1.setOpaque(true);
        label_1.setHorizontalAlignment(SwingConstants.LEFT);
        label_1.setForeground(ResourceManager.makeColorRGBA(212,147,38,255));
        label_1.setFont(new Font("", Font.BOLD, 10));
        label_1.setBackground(ResourceManager.makeColorRGBA(38,38,38,255));
        add(label_1);
        
        JLabel label_2 = new JLabel("PassWord");
        label_2.setBounds(351, 457, 55, 25);
        label_2.setOpaque(true);
        label_2.setHorizontalAlignment(SwingConstants.LEFT);
        label_2.setForeground(ResourceManager.makeColorRGBA(212,147,38,255));
        label_2.setFont(new Font("", Font.BOLD, 10));
        label_2.setBackground(ResourceManager.makeColorRGBA(38,38,38,255));
        add(label_2);
        
        JLabel lblNewLabel = new JLabel(); 
        lblNewLabel.setBounds(307, 400, 410, 220);
		lblNewLabel.setOpaque(true);
		lblNewLabel.setBackground(ResourceManager.makeColorRGBA(38,38,38,255));
		lblNewLabel.setBorder(new BevelBorder(BevelBorder.RAISED));
		this.add(lblNewLabel);
		
		sysmsg = new JLabel();
		sysmsg.setBounds(307, 632, 410, 23);
		sysmsg.setOpaque(true);
		sysmsg.setBackground(ResourceManager.makeColorRGBA(38,38,38,255));
		sysmsg.setBorder(new BevelBorder(BevelBorder.RAISED));
		this.add(sysmsg);
        
		
		logo = new Logo();
		logo.setBounds(107, 25, 710, 400);
        this.add(logo);
       
	}
	
	public void active()
	{
		activated = true;
		logo.work();
		master.getContentPane().add(this);
		master.revalidate();
		master.repaint();
	}
	
	public void inactive()
	{
		activated = false;
		logo.stop();
		master.remove(this);
		master.revalidate();
		master.repaint();
	}
	
	
	public void keyProcess(KeyEvent e)
	{
		if(e.getKeyCode() == KeyEvent.VK_TAB)
		{
			if(id.isFocusOwner())
				pw.requestFocus();
			else if(pw.isFocusOwner())
				id.requestFocus();
		}
	}
	
	public void actionPerformed(ActionEvent e)
	{
		// �α��ο� ���� ������ ���� ���и޼����� ��ȯ�ϰų� ������ ����������
		if(e.getSource() == btnLogin )
		{
			Main.gate.connect();
			Main.gate.sendPak01(true, id.getText(), pw.getText());

		}
		else if(e.getSource() == btnSign )
		{
			Main.gate.connect();
			Main.gate.sendPak01(false, id.getText(), pw.getText());
		}
		else if(e.getSource() == btnSingle)
		{
			// �̱��÷��̷� �Ѱ���
			inactive();
			Main.build.active(BuildPage.LOGIN);
		}
	}
	
	public void setSysmsg(Color c, String msg)
	{
		sysmsg.setForeground(c);
		sysmsg.setText(msg);
	}
	
	boolean isActivated()
	{
		return activated;
	}
}
