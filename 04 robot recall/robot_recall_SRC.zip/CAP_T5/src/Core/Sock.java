package Core;

import java.io.IOException;
import java.net.ConnectException;
import java.net.InetSocketAddress;
import java.net.StandardSocketOptions;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.nio.charset.Charset;
import java.util.Iterator;
import java.util.Scanner;

import IMG.ResourceManager;


public class Sock {

	public static final byte TNONE = 2;
	public static final byte TRED = 0;
	public static final byte TBLUE = 1;

	Main master;
	boolean activated;
	ByteBuffer recvBuffer = ByteBuffer.allocate(4096);
	//ByteBuffer sendBuffer = ByteBuffer.allocate(100);
	SocketChannel sockChannel;
	Selector selector;
	
	int myIndex;
	byte myTeam;
	int []myW;
	int []myT;
	int []myB;
	
	public Sock(Main master) {
		activated = false;	
		this.master = master;
		myIndex = -1;
		myW = new int[3];
		myT = new int[3];
		myB = new int[3];
	}
	public void connect()
	{
		try{
			System.out.println("connecting...");
			sockChannel = SocketChannel.open();
			sockChannel.setOption(StandardSocketOptions.TCP_NODELAY, true);
			sockChannel.configureBlocking(false);
			//sockChannel.connect(new InetSocketAddress("127.0.0.1", 8000));
			sockChannel.connect(new InetSocketAddress("211.249.50.86", 8000));
			selector = Selector.open();
			sockChannel.register(selector, SelectionKey.OP_READ);
			
			while(!sockChannel.finishConnect() || !sockChannel.isRegistered())
			{} // wait
			System.out.println("connected");
			activated = true;
		}catch(ConnectException ce)
		{
			ce.printStackTrace();
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		
	}
	public void disconnect()
	{
		try {
			sockChannel.close();
			activated =false;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void sendPak01(boolean login, String id, String pw)
	{
		// boolean�� ���� ��ȣ����
		// :: 0 �α���  [ ��ü ����/4 ][ ��ȣ/1 ][ ����/4 ][ ���̵�/n ][ ����/4 ][ ��й�ȣ/n ]
		// :: 1 ȸ�� ����  [ ��ü ����/4 ][ ��ȣ/1 ][ ����/4 ][ ���̵�/n ][ ����/4 ][ ��й�ȣ/n ]
		ByteBuffer str1 = encodeString(id);
		ByteBuffer str2 = encodeString(pw);
		int totalLen = 4 + 1 + 4 + str1.limit() + 4 + str2.limit();
		ByteBuffer byteBuffer = ByteBuffer.allocate(totalLen);
		
		//[��ü ����/4]
		byteBuffer.putInt(totalLen);
		
		//[��ȣ/1]
		if(login)
			byteBuffer.put((byte)0);
		else
			byteBuffer.put((byte)1);
		//[�̸�����/4][�̸�/n]
		byteBuffer.putInt(str1.limit());
		byteBuffer.put(str1); 
		//[�������/4][���/n]
		byteBuffer.putInt(str2.limit());
		byteBuffer.put(str2);
		
		byteBuffer.flip();
		// �α��� â Ȱ��ȭ
		send(byteBuffer);
	}
	public void sendPak2(String name)
	{
		// :: 2 �� ����  [ ��ü ����/4 ][ ��ȣ/1 ][ ����/4 ][ ���̸�/n ]
		ByteBuffer str1 = encodeString(name);
		int totalLen = 4 + 1 + 4 + str1.limit();
		ByteBuffer byteBuffer = ByteBuffer.allocate(totalLen);
		
		//[��ü ����/4]
		byteBuffer.putInt(totalLen);
		//[��ȣ/1]
		byteBuffer.put((byte)2);
		//[���̸�����/4][���̸�/n]
		byteBuffer.putInt(str1.limit());
		byteBuffer.put(str1); 
		
		byteBuffer.flip();
		
		send(byteBuffer);
	}
	public void sendPak3(int roomNum)
	{
		// :: 3 �� ���� [ ��ü ����/4 ][ ��ȣ/1 ][ �� ��ȣ /4 ]
		int totalLen = 4 + 1 + 4;
		ByteBuffer byteBuffer = ByteBuffer.allocate(totalLen);
		
		//[��ü ����/4]
		byteBuffer.putInt(totalLen);
		//[��ȣ/1]
		byteBuffer.put((byte)3);
		//[���ȣ/4]
		byteBuffer.putInt(roomNum);
		
		byteBuffer.flip();
		
		send(byteBuffer);
	}
	public void sendPak4()
	{
		// :: 4�� ������[ ��ü ����/4 ][ ��ȣ/1 ]
		int totalLen = 4+1;
		ByteBuffer byteBuffer = ByteBuffer.allocate(totalLen);
		
		//[��ü ����/4]
		byteBuffer.putInt(totalLen);
		//[��ȣ/1]
		byteBuffer.put((byte)4);
		
		byteBuffer.flip();
		
		send(byteBuffer);
	}
	public void sendPak5(int robotNum, int weaponNum, int topNum, int bottomNum)
	{
		// :: 5 �κ� ����  [ ��ü ����/4 ][ ��ȣ/1 ][ �κ� ��ȣ/4 ][ ���� ��ȣ/4 ][ ž ��ȣ/4 ][ ���� ��ȣ/4 ]
		int totalLen = 4 + 1 + 4 + 4 + 4 + 4;
		ByteBuffer byteBuffer = ByteBuffer.allocate(totalLen);
		
		//[��ü ����/4]
		byteBuffer.putInt(totalLen);
		//[��ȣ/1]
		byteBuffer.put((byte)5);
		//[�κ���ȣ/4]
		byteBuffer.putInt(robotNum);
		//[�����ȣ/4]
		byteBuffer.putInt(weaponNum);
		//[��ü��ȣ/4]
		byteBuffer.putInt(topNum);
		//[��ü��ȣ/4]
		byteBuffer.putInt(bottomNum);
		byteBuffer.flip();
		
		send(byteBuffer);
		
	}
	public void sendPak6()
	{
		// :: 6 �غ�  [ ��ü ����/4 ][ ��ȣ/1 ]
		int totalLen = 4 + 1 ;
		ByteBuffer byteBuffer = ByteBuffer.allocate(totalLen);
		
		//[��ü����/4]
		byteBuffer.putInt(totalLen);
		//[��ȣ/1]
		byteBuffer.put((byte)6);
		byteBuffer.flip();
		send(byteBuffer);
	}
	
	public void sendPak7(byte team)
	{
		int totalLen = 4+1+1;
		ByteBuffer byteBuffer = ByteBuffer.allocate(totalLen);
		
		byteBuffer.putInt(totalLen);
		byteBuffer.put((byte)7);
		byteBuffer.put(team);
		
		byteBuffer.flip();
		send(byteBuffer);
	}
	
	public void sendPak8(String msg)
	{
		// :: 8 ä��  [ ��ü ����/4 ][ ��ȣ/1 ][ ����/4 ][ �޼���/n ]
		ByteBuffer str1 = encodeString(msg);
		int totalLen = 4 + 1 + 4 + str1.limit();
		ByteBuffer byteBuffer = ByteBuffer.allocate(totalLen);
		
		//[��ü ����/4]
		byteBuffer.putInt(totalLen);
		//[��ȣ/1]
		byteBuffer.put((byte)8);
		//[�޼���/n]
		byteBuffer.putInt(str1.limit());
		byteBuffer.put(str1); 
		byteBuffer.flip();
		
		send(byteBuffer);
	}
	
	public void sendPak9(char type, boolean flag, int x, int y, int angle)
	{
		
			int totalLen = 4 + 1 + 1 +  1 + 4 + 4 + 4;
			ByteBuffer byteBuffer = ByteBuffer.allocate(totalLen);
			
			byteBuffer.putInt(totalLen);
			byteBuffer.put((byte)9);
            byteBuffer.put((byte)type);
            if(flag)
            	byteBuffer.put((byte)1);
            else
            	byteBuffer.put((byte)0);
            
            
            byteBuffer.putInt(x);
            byteBuffer.putInt(y);
            byteBuffer.putInt(angle);
            
            byteBuffer.flip();
            send(byteBuffer);
            
            
            //System.out.print("[������ ������ ����]" + (int)type);
            //if(flag)
            	//System.out.println("on");
           // else
            	//System.out.println("off");
		
	}
	
	public void sendPak10(byte responNum)
	{
		int totalLen = 4 + 1 + 1;
		ByteBuffer byteBuffer = ByteBuffer.allocate(totalLen);
		byteBuffer.putInt(totalLen);
		byteBuffer.put((byte)10);
        byteBuffer.put((byte)responNum);
        byteBuffer.flip();
        send(byteBuffer);
        
	}

	
	
	// ������ ��ȣ�� ���� �Ⱦ�
	//	up 0, down 1, left 2, right 3, z 4, x 5, c 6, space 7
	private void send(ByteBuffer byteBuffer)
	{
		try
		{
			sockChannel.write(byteBuffer);
		}catch(IOException ie)
		{
			
		}
	}
	
	public void recv() throws IOException
	{
		selector.select(10);
		
		Iterator<SelectionKey> itr = selector.selectedKeys().iterator();
		while(itr.hasNext())
		{
			SelectionKey key = itr.next();
			if(key.isReadable())
			{
				
				recvBuffer.limit(4096);
				
				int len = sockChannel.read(recvBuffer);
				if(len <0)
					break;
				else if(len == 0)
					continue;
				
				recvBuffer.flip();
				 
				recvProc();
				
	            recvBuffer.compact();
				
			}
		}
	}
	
	private void recvProc()
	{
		byte sig;
		
		while(true)
		{
			sig = completeRecv(recvBuffer);
			switch(sig)
			{
			case -1:
				return;
			case 0:
				reactProc();
				break;
			case 1:
				roomProc();
				break;
			case 2:
				channelProc();
				
				break;
			case 3:
				chatProc();
				
				break;
			case 4:
				gameProc();
				break;
				
			}
			recvBuffer.compact();
			recvBuffer.flip();
		}
	}	
	
	// Valid ��ȣ�� ACK ��ȣ�� �ް� ó���Ѵ�.
	private void reactProc()
	{
		byte sig = recvBuffer.get(); 
		switch(sig)
		{
		case 0:
			reactPak0();
			break;
		case 1:
			reactPak1();
			break;
		case 2:
			reactPak2();
			break;
		case 3:
			reactPak3();
			break;
		case 4:
			reactPak4();
			break;
		case 5:
			reactPak5();
			break;
		}
		
	}
	private void reactPak0()
	{
		byte valid = recvBuffer.get();
		if(valid == 1)
		{
			// ���� �������� GUI �ѱ�� ��ȣó��
			//System.out.println("�α��� ����!");
			
			for(int i=0;i<3;i++)
			{
				myW[i] = recvBuffer.getInt();
				myT[i] = recvBuffer.getInt();
				myB[i] = recvBuffer.getInt();
			}
			
			Main.login.inactive();
			Main.waitr1.active();
		}
		else
		{
			disconnect();
			Main.login.setSysmsg(ResourceManager.makeColorRGBA(255, 0, 0, 255), "invalid id");
		}
	}
	private void reactPak1()
	{
		byte valid = recvBuffer.get();
		if(valid == 1)
		{
			Main.login.setSysmsg(ResourceManager.makeColorRGBA(0, 255, 0, 255), "success sign");
			// �����޼���
		}
		else
		{
			Main.login.setSysmsg(ResourceManager.makeColorRGBA(255, 0, 0, 255), "duplicated id");
			// �����޼���
		}
	}
	private void reactPak2()
	{
		int roomId = recvBuffer.getInt();
		String rname = cutString(recvBuffer);
		myIndex = 0;
		Main.waitr1.inactive();
		Main.waitr2.active(roomId,rname);
	}
	private void reactPak3()
	{
		
		byte valid = recvBuffer.get();
		int index = recvBuffer.getInt();
		int roomId = recvBuffer.getInt();
		String rname = cutString(recvBuffer);
		if(valid == 1)
		{
			myIndex = index;
			Main.waitr1.inactive();
			Main.waitr2.active(roomId,rname);
		}
		else
		{
			// �����޼���
		}
	}
	private void reactPak4()
	{
		myIndex = -1;
		Main.waitr2.inactive(true);
		Main.waitr1.active();
		
	}
	private void reactPak5()
	{
		int robotNum=0, WNum=0, TNum=0, BNum;
		byte valid = recvBuffer.get();
		robotNum = recvBuffer.getInt();
		WNum = recvBuffer.getInt();
		TNum = recvBuffer.getInt();
		BNum = recvBuffer.getInt();

		if(valid==1)
		{
			myW[robotNum] = WNum;
			myT[robotNum] = TNum;
			myB[robotNum] = BNum;
			Main.build.buildResult(true);
			// �κ� ó��
		}
		else
		{
			Main.build.buildResult(false);
			// ���� ���� �˸�
		}
	}
	
	
	private void roomProc()
	{
		int rid;
		String rname;
		byte sig = recvBuffer.get();
		switch(sig)
		{
		case 0:
			// �� Ŭ����
			Main.waitr1.clearrJlist();
			Main.waitr1.refreshrJlist();
			break;
		case 1:
			rid = recvBuffer.getInt();
			rname = cutString(recvBuffer);
			// �� �߰�
			Main.waitr1.addrJlist(rid, rname);
			Main.waitr1.refreshrJlist();
			break;
		case 2:
			rid = recvBuffer.getInt();
			// �ش��ϴ� �� id ����
			Main.waitr1.removerJlist(rid);
			Main.waitr1.refreshrJlist();
			break;
		}
	}

	private void channelProc()
	{
		byte sig = recvBuffer.get();
		int index;
		switch(sig)
		{
		case 0:
			index = recvBuffer.getInt();
			byte ready = recvBuffer.get();
			if(ready == 1)
				Main.waitr2.setReady(index, true);
			else
				Main.waitr2.setReady(index, false);
			break;
		case 1:
			index = recvBuffer.getInt();
			String id = cutString(recvBuffer);
			Main.waitr2.setId(index, id);
			break;
		case 2:
			index = recvBuffer.getInt();
			Main.waitr2.setId(index, "");
			Main.waitr2.setReady(index, false);
			Main.waitr2.setTeam(index,TNONE);
			break;
		case 3:
			index = recvBuffer.getInt();
			byte team = recvBuffer.get();
			Main.waitr2.setTeam(index,team);
			if(this.myIndex == index )
			{
				this.myTeam = team;
			}
			break;
		case 4:
			if(Main.waitr2.isActivated())
			{
				Main.waitr2.inactive(false);
				Main.camera.active();
			}
			else
			{
				Main.camera.inactive();
				Main.result.active();
			}
			break;
		case 5:
			index = recvBuffer.getInt();
			int kill = recvBuffer.getInt();
			int death = recvBuffer.getInt();
			int deal = recvBuffer.getInt();
			Main.result.setResult(index, kill, death, deal);
			break;
		}
	}

	private void chatProc()
	{
		String msg = cutString(recvBuffer);
		System.out.println("��Ŷ �׽�Ʈ [ä��] : " + msg);
		if(Main.waitr1.isActivated())
			Main.waitr1.addChatMsg(msg);
		else if(Main.waitr2.isActivated())
			Main.waitr2.addChatMsg(msg);
		else if(Main.camera.isActivated())
		{
			Main.camera.getCTextin().add(0,msg);
			if(Main.camera.getCTextin().size()>7)
				Main.camera.getCTextin().remove(Main.camera.getCTextin().size()-1);
		}
	}
	
	private void gameProc()
	{
		byte sig = recvBuffer.get();
		int id;
		int x;
		int y;
		byte flag;
		byte team;
		switch(sig)
		{
		case 0:
			id = recvBuffer.getInt();
			byte key = recvBuffer.get();
			flag = recvBuffer.get();
			x = recvBuffer.getInt();
			y = recvBuffer.getInt();
			int angle = recvBuffer.getInt();
			Main.wt.userControl(id, key, flag, x, y, angle);
			// ���� ��Ʈ��
			break;
		case 1:
			int actorId = recvBuffer.getInt();
			int reactorId = recvBuffer.getInt();
			int point = recvBuffer.getInt();
			int vib = recvBuffer.getInt();
			flag = recvBuffer.get();
			Main.wt.eventSync(actorId, reactorId, point, vib,flag);
			System.out.println(actorId+" "+ reactorId+" "+ point+" "+ vib+" "+flag);
			// hurt ó��
			break;
		case 2:
			byte type = recvBuffer.get();
			team = recvBuffer.get();
			byte foward = recvBuffer.get();
			id = recvBuffer.getInt();
			int objType = recvBuffer.getInt();
			x = recvBuffer.getInt();
			y = recvBuffer.getInt();
			
			if(type == 1)
				Main.wt.objAdd(team, foward, id, objType, x, y);
			else
				Main.wt.objRemove(id);
			System.out.println("������Ʈ ó��");
			break;
		case 3:
			team = recvBuffer.get();
			id = recvBuffer.getInt();
			int wnum = recvBuffer.getInt();
			int tnum = recvBuffer.getInt();
			int bnum = recvBuffer.getInt();
			x = recvBuffer.getInt();
			y = recvBuffer.getInt();
			Main.wt.userAdd(team,id, x, y, tnum, bnum, wnum);
			if(id == myIndex)
			{
				//System.out.println("mybot : "+myIndex);
				Main.camera.setViewP(id);
			}
			break;
		case 4:
			id = recvBuffer.getInt();
			x = recvBuffer.getInt();
			y = recvBuffer.getInt();
			angle = recvBuffer.getInt();
			int remain = recvBuffer.getInt();
			Main.wt.projAdd(id,x,y,angle,remain);
			break;
		case 5:
			byte purScore = recvBuffer.get();
			byte redScore = recvBuffer.get();
			byte blueScore = recvBuffer.get();
			Main.camera.setScore(purScore,redScore,blueScore);
			break;
		}
	}
	
	
	// ��Ŷ �ٷ�� �Լ�
	
	// 0���� ���� length ��ŭ ���۸� �ڸ��� buffer���� compact�ؼ� ��ȯ
	static ByteBuffer cut( int length, ByteBuffer buffer)
	{
		ByteBuffer _buffer;
		int oldL = buffer.limit();
		buffer.limit(length);
		_buffer = buffer.duplicate(); // ������
		_buffer = _buffer.slice(); // �ʿ���� �κ� �����̽��ؼ� ����
		

		buffer.position(buffer.limit());
		buffer.limit(oldL);
		buffer.compact();
		buffer.flip();
		
		return _buffer;
	}
	
	static ByteBuffer encodeString(String str)
	{
		Charset charset = Charset.forName("UTF-8");
		ByteBuffer _buffer = charset.encode(str);
		return _buffer;
	}
	
	// [ ����/4 ][ �޼��� ] ����� ��Ŷ�� ��Ʈ������ �̾Ƴ���.
	static String cutString(ByteBuffer buffer)
	{
		String _buffer;
		Charset charset = Charset.forName("UTF-8");
		int len = buffer.getInt();
		int oldLimit;
		
		oldLimit = buffer.limit();
		buffer.limit(buffer.position()+len);
		
		_buffer = charset.decode(buffer).toString();
		
		buffer.position(buffer.limit());
		buffer.limit(oldLimit);
		buffer.compact();
		buffer.flip();
		
		return _buffer;
	}
	
	// [ ��ü ����/4 ] üũ  limit�� �� ���� �̻��϶��� �����Ѵ�.
	static byte completeRecv(ByteBuffer buffer)
	{	
		
		if(buffer.limit() < 4)
			return -1;
		
		if(buffer.getInt() > buffer.limit())
		{
			buffer.rewind();
			return -1;
		}
		else
		{
			byte signal = buffer.get();
			buffer.compact();
			buffer.flip();
			return signal;
		}
	}
	
	public static void main(String [] args) throws IOException
	{
		Sock gate = new Sock(null);
		Scanner in = new Scanner(System.in);
		int inf = 0;
		gate.connect();
		while(true)
		{
		
		System.out.println("0");
		gate.sendPak01(true, "���ѳ��ڱ輺ĥ", "��!�Ǵ���~Ȯ������");
		//System.out.println("1");
		//gate.sendPak01(false, "���θ�����̵�", "�׽�Ʈ���1234%");
		//System.out.println("2");
		//gate.sendPak2("roomTest");
		//System.out.println("3");
		//gate.sendPak3(4);
		//System.out.println("4");
		//gate.sendPak5(1, 3, 3);
		//System.out.println("5");
		//gate.sendPak6();
		//System.out.println("6");
		//gate.sendPak7("chat test: �ȳ翩���� ������ �� ������.");
		
		if(inf != 9)
			inf = in.nextInt();
		
		if(inf == 3)
		{
			gate.recv();
		}
		
		}
		
	}
	
	
	// encapsulation
	
	public boolean isActivated()
	{
		return activated;
	}
	
	
	
}
