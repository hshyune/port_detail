package Core;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

import IMG.ResourceManager;


public class Logo extends Canvas implements Runnable{

	private static BufferedImage buff;//�������۸��� �����
	public static Graphics2D gc2;//�������۸��� �׷��� ���ؽ�Ʈ
	private Thread thread; // ��Ŀ ���� ������
	private int delay;//���� ������. 1/1000�� ����.
	private long pretime;//���� ������ �����ϱ� ���� �ð� üũ��
	
	ArrayList<ArcDesign> ad2;
	
	public Logo()
	{
		
		delay =18;

		ad2 = new ArrayList<ArcDesign>();
		
		for(int i=0;i<8;i++)
		{
			if(i%2 ==1)
			{
				ad2.add(new ArcDesign(190,190,115,18,4,0,0,false,45*i,40,40,new Color(0.2f, 0.2f, 0.2f, 1.0f)));
				ad2.add(new ArcDesign(190,190,95,3,4,0,0,false,45*i,40,40,new Color(0.1f, 0.1f, 0.1f, 1.0f)));
			}
			else
			{
				ad2.add(new ArcDesign(190,190,115,18,4,0,0,false,45*i,40,40,new Color(0.1f, 0.1f, 0.1f, 1.0f)));
				ad2.add(new ArcDesign(190,190,95,3,4,0,0,false,45*i,40,40,new Color(0.2f, 0.2f, 0.2f, 1.0f)));
			}
		}
		// �߰�
		ad2.add(new ArcDesign(190,190,143,2,4,0,1,true,240,110,110,ResourceManager.makeColorRGBA(110,80,64,255)));
		ad2.add(new ArcDesign(190,190,143,2,4,0,1,true,150,30,30,ResourceManager.makeColorRGBA(110,80,64,255)));
		// ����
		ad2.add(new ArcDesign(190,190,117,2,4,0,1,true,0,30,30,ResourceManager.makeColorRGBA(45,69,62,255)));
		ad2.add(new ArcDesign(190,190,117,2,4,0,1,true,40,130,130,ResourceManager.makeColorRGBA(110,80,64,255)));
		ad2.add(new ArcDesign(190,190,117,2,4,0,1,true,240,80,80,ResourceManager.makeColorRGBA(110,80,64,255)));
		// �ٱ�
		ad2.add(new ArcDesign(190,190,155,5,4,0,1,true,20,80,80,ResourceManager.makeColorRGBA(110,80,64,255)));
		
		ad2.add(new ArcDesign(190,190,167,1,3,0,3,true,270,217,247,ResourceManager.makeColorRGBA(212,147,38,255)));
		ad2.add(new ArcDesign(190,190,175,10,4,0,1,false,280,50,50,ResourceManager.makeColorRGBA(110,80,64,255)));
		// ��
		ad2.add(new ArcDesign(190,190,127,2,2,0,2,true,0,120,120,ResourceManager.makeColorRGBA(133,161,144,230)));
		ad2.add(new ArcDesign(190,190,127,2,2,0,2,true,140,80,80,ResourceManager.makeColorRGBA(212,147,38,255)));
		ad2.add(new ArcDesign(190,190,127,2,2,0,2,true,270,30,30,ResourceManager.makeColorRGBA(133,161,144,230)));
		ad2.add(new ArcDesign(190,190,127,2,2,0,2,true,330,20,20,ResourceManager.makeColorRGBA(212,147,38,255)));
		

	//	work();
	}
	
	public void work()
	{
		thread = new Thread(this);
		thread.start();
	}
	
	public void stop()
	{
		thread.interrupt();
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		while(true){
			try{
				pretime=System.currentTimeMillis();
				for(ArcDesign temp: ad2)
					temp.update();
				repaint();

				long nowTime = System.currentTimeMillis();
				if(nowTime-pretime<delay)
					Thread.sleep(delay-(nowTime-pretime)<0?1:delay-(nowTime-pretime));
			}catch(InterruptedException e)
			{
				return;
			}catch(Exception e){
				e.printStackTrace();
			}
		}
	}
	
	@Override
	public void paint(Graphics g) {
		// TODO Auto-generated method stub
		if(gc2==null){
			
			buff = new BufferedImage(710,400, BufferedImage.TYPE_INT_ARGB);//������ũ�� ����
			if(buff!=null)
				gc2 = buff.createGraphics();
			return;
		}
		update(g);
	}
	
	@Override
	public void update(Graphics g) {
		// TODO Auto-generated method stub
		if(gc2==null) return;
		
		//System.out.println("update");
		dblpaint();//������ũ�� ���ۿ� �׸���
		//g.drawImage((Image)getScaledImage(buff, mainFrame.gGameWidth, mainFrame.gGameHeight), 0,0, mainFrame.gGameWidth, mainFrame.gGameHeight, this);//������ũ�� ���۸� ����ȭ�鿡 �׸���.
		g.drawImage(buff, 0,0,710,400, this);//������ũ�� ���۸� ����ȭ�鿡 �׸���.
		
	}
	
	public void dblpaint()
	{
		//System.out.println("run");
		gc2.setColor(ResourceManager.makeColorRGBA(19, 19, 19, 255));
		gc2.fillRect(0,0,1423,755);

		for(ArcDesign temp: ad2)
			temp.paint(gc2);
		
		gc2.drawImage(ResourceManager.getInstance().getTitle(), 380, 130, this);
		
		
		
	}
	
	
	
	
	
}
