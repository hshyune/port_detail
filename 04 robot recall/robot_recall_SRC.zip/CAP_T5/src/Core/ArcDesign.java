package Core;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Stroke;

import IMG.ResourceManager;

public class ArcDesign {

	// �߽��� x,y ������ r
	int x;
	int y;
	int r;

	
	// ������ ������
	int anStart;
	
	// ������ ����
	int anLenI;
	int anLenC;
	int anLenE;
	
	// ������ ����
	Color c;
	// ������ ����
	int thick;
	int stroke;
	// Ȯ��ӵ�
	int exSpeed;
	// ȸ���ӵ�
	int rotSpeed;
	
	boolean right;
	boolean extend;
	
	int alpha;
	boolean albool;
	
	public ArcDesign(int x, int y, int r, int thick, int stroke, int exSpeed, int rotSpeed, boolean right,  int anStart, int anLenI, int anLenE, Color c)
	{
		this.x = x;
		this.y = y;
		this.r = r;
		this.thick = thick;
		this.stroke = stroke;
		this.exSpeed = exSpeed;
		this.rotSpeed = rotSpeed;
		this.right = right;

		this.anStart = anStart;
		this.anLenI = anLenI;
		this.anLenC = anLenI;
		this.anLenE = anLenE;
		this.c = c;
		alpha = c.getAlpha();
		albool = true;

	}
	
	public void update()
	{
		if(extend)
		{
			anLenC = anLenI < anLenE ? anLenI + exSpeed : anLenI - exSpeed;
			if(anLenI < anLenE ? anLenC >= anLenE : anLenC <= anLenE )
				extend = false;
		}
		else
		{
			anLenC = anLenI < anLenE ? anLenI - exSpeed : anLenI + exSpeed;
			if(anLenI < anLenE ? anLenC <= anLenE : anLenC >= anLenE )
				extend = true;
		}
		
		
		if(right)
			anStart -= rotSpeed;
		else
			anStart += rotSpeed;
		
		if(albool)
		{
			if(alpha- 200 >= c.getAlpha()) albool = false;
			c = ResourceManager.makeColorRGBA(c.getRed(),c.getGreen(),c.getBlue(),c.getAlpha() -5);
		}
		else
		{
			if(alpha <= c.getAlpha()+5) albool = true;
			c = ResourceManager.makeColorRGBA(c.getRed(),c.getGreen(),c.getBlue(),c.getAlpha() +5);
		}
	}
	
	public void paint(Graphics2D gc)
	{
		
		Stroke s = gc.getStroke();
		gc.setStroke(new BasicStroke(stroke,2,2));
		gc.setColor(c);

		for(int j=0;j<thick;j++)
		{
			
				
			gc.drawArc(x-r-j, y-r-j, (r+j)*2, (r+j)*2, anStart, anLenC);
			//gc.drawLine(x + (int)(coss*r), y + (int)(sins*r), x + (int)(coss*(r+thick)),y+ (int)(sins*(r+thick)) );
		}
		gc.setStroke(s);
	}
	
	
}
