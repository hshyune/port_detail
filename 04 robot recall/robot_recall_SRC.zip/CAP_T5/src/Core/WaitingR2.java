package Core;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;

import IMG.ResourceManager;

public class WaitingR2 extends JPanel{
	
	
	private Main master;
	private boolean activated;
	
	private JLabel labelrid;
	private JLabel labelrname; 
	
	private JTextArea cTextin;
	
	private JButton btnTRed;
	private JButton btnTBlue;
	
	private JButton btnReady;
	private JButton btnBuild;
	private JButton btnOut;
	
	private IdCard idCard[];
	
	public WaitingR2(Main master) {
		
		this.setBounds(0,0,Main.WIDTH,Main.HEIGHT);
		this.setBackground(ResourceManager.makeColorRGBA(19,19,19,255));
		setLayout(null);
		this.master = master;
		
		
		btnTRed = new JButton("RED TEAM");
		btnTRed.setFont(new Font("", Font.BOLD, 20));
		btnTRed.setForeground(ResourceManager.makeColorRGBA(255, 0, 0,255));
		btnTRed.setBounds(814,276, 175, 50);
		btnTRed.setBackground(ResourceManager.makeColorRGBA(38,38,38,255));
		btnTRed.setBorder(new BevelBorder(BevelBorder.RAISED));
		btnTRed.setFocusPainted(false);
		btnTRed.addActionListener(master);
		this.add(btnTRed);
		
		btnTBlue = new JButton("BLUE TEAM");
		btnTBlue.setFont(new Font("", Font.BOLD, 20));
		btnTBlue.setForeground(ResourceManager.makeColorRGBA(0, 148, 255,255));
		btnTBlue.setBounds(814,326, 175, 50);
		btnTBlue.setBackground(ResourceManager.makeColorRGBA(38,38,38,255));
		btnTBlue.setBorder(new BevelBorder(BevelBorder.RAISED));
		btnTBlue.setFocusPainted(false);
		btnTBlue.addActionListener(master);
		this.add(btnTBlue);
		
		btnReady = new JButton("READY");
		btnReady.setFont(new Font("", Font.BOLD, 20));
		btnReady.setForeground(ResourceManager.makeColorRGBA(212,147,38,255));
		btnReady.setBounds(814,388, 175, 100);
		btnReady.setBackground(ResourceManager.makeColorRGBA(38,38,38,255));
		btnReady.setBorder(new BevelBorder(BevelBorder.RAISED));
		btnReady.setFocusPainted(false);
		btnReady.addActionListener(master);
		this.add(btnReady);
		
		btnBuild = new JButton("Build ROBOT");
		btnBuild.setFont(new Font("", Font.BOLD, 20));
		btnBuild.setForeground(ResourceManager.makeColorRGBA(133,161,144,255));
		btnBuild.setBounds(814, 500, 175, 100);
		btnBuild.setBackground(ResourceManager.makeColorRGBA(45,69,62,255));
		btnBuild.setBorder(new BevelBorder(BevelBorder.RAISED));
		btnBuild.setFocusPainted(false);
		btnBuild.addActionListener(master);
		this.add(btnBuild);
		
		btnOut = new JButton("OUT");
		btnOut.setFont(new Font("", Font.BOLD, 20));
		btnOut.setForeground(ResourceManager.makeColorRGBA(133,161,144,255));
		btnOut.setBounds(814, 612, 175, 100);
		btnOut.setBackground(ResourceManager.makeColorRGBA(45,69,62,255));
		btnOut.setBorder(new BevelBorder(BevelBorder.RAISED));
		btnOut.setFocusPainted(false);
		btnOut.addActionListener(master);
		this.add(btnOut);
		
		
		
		
		
		// ���� ����Ʈ
		
		 labelrid = new JLabel();
	     labelrid.setOpaque(true);
	     labelrid.setHorizontalAlignment(SwingConstants.CENTER);
	     labelrid.setBorder(new BevelBorder(BevelBorder.RAISED));
	     labelrid.setFont(new Font("", Font.BOLD, 20));
	     labelrid.setForeground(ResourceManager.makeColorRGBA(38,38,38,255));
	     labelrid.setBackground(ResourceManager.makeColorRGBA(212,147,38,255));
	     labelrid.setBounds(15, 30, 115, 38);
	     add(labelrid);
	     
	     labelrname = new JLabel();
	     labelrname.setOpaque(true);
	     labelrname.setHorizontalAlignment(SwingConstants.CENTER);
	     labelrname.setBorder(new BevelBorder(BevelBorder.RAISED));
	     labelrname.setFont(new Font("", Font.BOLD, 20));
	     labelrname.setBackground(ResourceManager.makeColorRGBA(38,38,38,255));
	     labelrname.setForeground(ResourceManager.makeColorRGBA(212,147,38,255));
	     labelrname.setBounds(130, 30, 669, 38);
	     add(labelrname);
	     
		
		 JLabel label1 = new JLabel("USER LIST");
	     label1.setOpaque(true);
	     label1.setHorizontalAlignment(SwingConstants.CENTER);
	     label1.setBorder(new BevelBorder(BevelBorder.RAISED));
	     label1.setForeground(ResourceManager.makeColorRGBA(133,161,144,255));
	     label1.setFont(new Font("", Font.BOLD, 20));
	     label1.setBackground(ResourceManager.makeColorRGBA(45,69,62,255));
	     label1.setBounds(15, 68, 785, 38);
	     add(label1);
		
	     idCard = new IdCard[6];
		for(int i=0;i<6;i++)
		{
			idCard[i] = new IdCard();
			idCard[i].add(this,15,106+ 60*i);
		}
        // ä�� ����Ʈ
        
        JLabel label2 = new JLabel("CHAT LOG");
        label2.setOpaque(true);
        label2.setHorizontalAlignment(SwingConstants.CENTER);
        label2.setBorder(new BevelBorder(BevelBorder.RAISED));
        label2.setForeground(ResourceManager.makeColorRGBA(133,161,144,255));
        label2.setFont(new Font("", Font.BOLD, 20));
        label2.setBackground(ResourceManager.makeColorRGBA(45,69,62,255));
        label2.setBounds(15, 466, 785, 38);
        add(label2);
        
        JScrollPane scrollPane2 = new JScrollPane();
		scrollPane2.setBorder(new BevelBorder(BevelBorder.RAISED));
		scrollPane2.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane2.setBackground(ResourceManager.makeColorRGBA(38, 38, 38, 255));
        scrollPane2.setBounds(15, 506, 785, 183);
        add(scrollPane2);
        
        cTextin = new JTextArea();
		cTextin.setOpaque(true);
		cTextin.setLineWrap(true);
		cTextin.setWrapStyleWord(true);
		cTextin.setEditable(false);
		cTextin.setBackground(ResourceManager.makeColorRGBA(68, 68, 68, 255));
		cTextin.setForeground(ResourceManager.makeColorRGBA(212,147,38,255));
		cTextin.setFont(new Font("����", Font.BOLD, 15));
		cTextin.setBounds(100, 43, 277, 553);
		cTextin.setText("");
		scrollPane2.setViewportView(cTextin);
        
		//�׽�Ʈ��
		
	}
	
	public void addChatMsg(String msg)
	{
		cTextin.append(msg + "\n");
	}
	
	public void setReady(int index, boolean ready)
	{
		idCard[index].setReady(ready);
	}
	
	public void setId(int index, String name)
	{
		idCard[index].setId(name);
	}
	
	public void setTeam(int index,byte team)
	{
		idCard[index].setTeam(team);
	}
	
	public void inactive(boolean isOut)
	{
		if(isOut)
		{
			for(int i=0;i<6;i++)
			{
				setReady(i,false);
				setId(i,"");
			}
			cTextin.setText("");
		}
		activated = false;
		this.remove(Main.cTextout);
		master.remove(this);
		master.revalidate();
		master.repaint();
	}
	
	public void active(int rid, String rname)
	{
		labelrname.setText(rname);
		labelrid.setText(Integer.toString(rid));
		this.add(Main.cTextout);
		activated = true;
		master.getContentPane().add(this);
		master.revalidate();
		master.repaint();
		Main.cTextout.setBounds(15, 689, 785, 23);
		Main.cTextout.requestFocusInWindow();
	}
	
	public void active()
	{	
		activated = true;
		this.add(Main.cTextout);
		master.getContentPane().add(this);
		master.revalidate();
		master.repaint();
		Main.cTextout.setBounds(15, 689, 785, 23);
		Main.cTextout.requestFocusInWindow();
	}
	
	
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		 // ActionEvent �� �߻���Ų ��ư ��ü�� ��ȯ�Ѵ�
		
		if(e.getSource() == btnOut)
		{
			Main.gate.sendPak4();
		}
		else if(e.getSource() == btnBuild)
		{
			inactive(false);
			Main.build.active(BuildPage.WAIT2);
			// go to build room
		}
		else if(e.getSource() == btnReady)
		{
			Main.gate.sendPak6();
		}
		else if(e.getSource() == btnTRed)
		{
			Main.gate.sendPak7(Sock.TRED);
		}
		else if(e.getSource() == btnTBlue)
		{
			Main.gate.sendPak7(Sock.TBLUE);
		}
		Main.cTextout.requestFocusInWindow();
	
	}
	
	public String getUserName(int index)
	{
		return idCard[index].getId();
	}
	
	boolean isActivated()
	{
		return activated;
	}

}
