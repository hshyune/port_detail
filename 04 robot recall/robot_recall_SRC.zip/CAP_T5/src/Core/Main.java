package Core;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.BitSet;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.border.BevelBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import IMG.ResourceManager;


public class Main extends JFrame implements KeyListener, ActionListener, ListSelectionListener {

	

	public static final int WIDTH = 1024;
	public static final int HEIGHT = 768;
	public static Camera camera;
	public static WorkerThread wt;
	public static Remocon mctrl ;
	public static LoginPage login;
	public static WaitingR1 waitr1;
	public static WaitingR2 waitr2;
	public static BuildPage build;
	public static ResultPage result;
	
	public static JTextField cTextout;
	public static Sock gate;
	private static BitSet pressLock; // ��Ƽ�÷��̿��� �ѹ� �������� ������ ��ȣó���� �����ʰ� �ϱ����� ��
	private static boolean enterLock;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Main();
	}

	private Main() {
		
		mctrl = new Remocon();
		Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
		int f_xpos = (int) (screen.getWidth() / 2 - WIDTH / 2);
		int f_ypos = (int) (screen.getHeight() / 2 - HEIGHT / 2);

		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("test Frame");
		getContentPane().setLayout(null);
		setBounds(f_xpos, f_ypos, WIDTH, HEIGHT);
		setResizable(false);
		setFocusable(true);
		setVisible(true);
		addKeyListener(this);
		setLayout(null);
		 

		login = new LoginPage(this);
		waitr1 = new WaitingR1(this);
		waitr2 = new WaitingR2(this);
		build = new BuildPage(this);
		result = new ResultPage(this);
		gate = new Sock(this);
		
		camera = new Camera(this);
		camera.setBounds(0, 0, WIDTH, HEIGHT);
		wt = new WorkerThread(this);
		
		cTextout = new JTextField();
		cTextout.setBounds(15, 689, 785, 23);
		cTextout.setForeground(ResourceManager.makeColorRGBA(212,147,38,255));
		cTextout.setBackground(ResourceManager.makeColorRGBA(68, 68, 68, 255));
		cTextout.setBorder(new BevelBorder(BevelBorder.RAISED));
		cTextout.setColumns(100);	
		cTextout.addKeyListener(this);
		
		pressLock = new BitSet(30);
		enterLock = false;
		login.active();
	
		
		
	}
	
	
	private void keyOperate(char type, boolean flag)
	{
		if(camera.isActivated())
		{
			if(gate.isActivated())
			{
				
				if(wt.userCtrl[gate.myIndex].getReceiver().getTop().getHP() >0)
				{
				
					int x = wt.userCtrl[gate.myIndex].getReceiver().getX();
					int y = wt.userCtrl[gate.myIndex].getReceiver().getY();
					int angle = wt.userCtrl[gate.myIndex].getReceiver().getAngle();
					//System.out.println("multi key input : " +(int)type+flag);
					if(flag)
					{
						if(!pressLock.get(type))
						{
							gate.sendPak9(type,flag,x,y,angle);
							pressLock.set(type);
						}
					}
					else
					{
						{
							gate.sendPak9(type,flag, x,y,angle);
							pressLock.clear(type);
						}
					}
				}
				else
				{
					if(type ==2)
						camera.swapViewP(false);
					else if(type ==3)
						camera.swapViewP(true);
				}
			}
			else
			{
				if(flag)
					mctrl.set(type);
				else
					mctrl.clear(type);
			}
		}
	}
	
	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		
		
		// GAME PLAY CMD
		if(!cTextout.isFocusOwner())
		{
		
			switch (e.getKeyCode()) {
			case KeyEvent.VK_UP:
				keyOperate((char)0,true);
				break;
			case KeyEvent.VK_DOWN:
				keyOperate((char)1,true);
				break;
			case KeyEvent.VK_LEFT:
				keyOperate((char)2,true);
				break;
			case KeyEvent.VK_RIGHT:
				keyOperate((char)3,true);
				break;
			case KeyEvent.VK_Z:
				keyOperate((char)4,true);
				break;
			case KeyEvent.VK_X:
				keyOperate((char)5,true);
				break;
			case KeyEvent.VK_C:
				keyOperate((char)6,true);
				break;
			case KeyEvent.VK_V:
				keyOperate((char)7,true);
				break;
			case KeyEvent.VK_SPACE:
				keyOperate((char)8,true);
				break;
			// id <-> pw focus
			case KeyEvent.VK_TAB:
				if(login.isActivated())
					login.keyProcess(e);
				break;
			case KeyEvent.VK_1:
				camera.setResponNum(11);
				break;
			case KeyEvent.VK_2:
				camera.setResponNum(12);
				break;
			case KeyEvent.VK_3:
				camera.setResponNum(13);
				break;
			}
		
		}
		
		// CHAT CMD
		if(e.getKeyCode() ==KeyEvent.VK_ENTER)
		{
			if(!enterLock)
			{

				if(cTextout.isFocusOwner())
				{
					if(gate.isActivated() && cTextout.getText().length()>0)
					{
						gate.sendPak8(cTextout.getText());
						cTextout.setText("");
						requestFocusInWindow();
					}
				}
				else
				{
					cTextout.requestFocusInWindow();
				}
			}
			enterLock = true;
		}
	}
	

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		switch (e.getKeyCode()) {
		case KeyEvent.VK_UP:
			keyOperate((char)0,false);
			break;
		case KeyEvent.VK_DOWN:
			keyOperate((char)1,false);
			break;
		case KeyEvent.VK_LEFT:
			keyOperate((char)2,false);
			break;
		case KeyEvent.VK_RIGHT:
			keyOperate((char)3,false);
			break;
		case KeyEvent.VK_Z:
			keyOperate((char)4,false);
			break;
		case KeyEvent.VK_X:
			keyOperate((char)5,false);
			break;
		case KeyEvent.VK_C:
			keyOperate((char)6,false);
			break;
		case KeyEvent.VK_V:
			keyOperate((char)7,false);
			break;
		case KeyEvent.VK_SPACE:
			keyOperate((char)8,false);
			break;
		case KeyEvent.VK_ENTER:
			enterLock = false;
			break;
		}
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
		if(login.isActivated())
			login.actionPerformed(e);
		if(waitr1.isActivated())
			waitr1.actionPerformed(e);
		if(waitr2.isActivated())
			waitr2.actionPerformed(e);
		if(build.isActivated())
			build.actionPerformed(e);
		if(result.isActivated())
			result.actionPerformed(e);
			
	}

	@Override
	public void valueChanged(ListSelectionEvent e) {
		// TODO Auto-generated method stub
		if(waitr1.isActivated())
			waitr1.valueChanged(e);
		if(build.isActivated())
			build.valueChanged(e);
	}

}
