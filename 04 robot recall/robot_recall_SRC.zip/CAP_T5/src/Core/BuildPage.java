package Core;
import java.awt.Canvas;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;
import javax.swing.event.ListSelectionEvent;

import IMG.ResourceManager;
import Object.ContainerFactory;


public class BuildPage extends JPanel {
	
	public static final int WAIT1 =1;
	public static final int WAIT2 =2;
	public static final int LOGIN =3;
	
	private Main master;
	private boolean activated;
	
	private JButton []btnBot;
	private JButton []btnPart;
	private JButton btnBuild;
	private JButton btnOut;
	
	private ArrayList<String> wList;
	private ArrayList<String> tList;
	private ArrayList<String> bList;
	private JList list;
	private Canvas BotImage;
	private JLabel BotW;
	private JLabel BotT;
	private JLabel BotB;
	private JLabel BuildResult;
	
	private Image wImg = null;
	private Image tImg = null;
	private Image bImg = null;
	
	private int prevPage;
	
	private int robot, model, weapon, top, bottom;
	
	
	public BuildPage(Main master) {
	
		this.setBounds(0,0,Main.WIDTH,Main.HEIGHT);
		this.setBackground(ResourceManager.makeColorRGBA(19,19,19,255));
		setLayout(null);
		this.master = master;
		
		robot = 0;
		
		btnBot = new JButton[3];
		for(int i=0;i<3;i++)
		{
			btnBot[i] = new JButton("ROBOT"+ (i+1));
			btnBot[i].setFont(new Font("", Font.BOLD, 15));
			btnBot[i].setForeground(ResourceManager.makeColorRGBA(212,147,38,255));
			btnBot[i].setBounds(50 + i*100, 77, 100, 23);
			btnBot[i].setBackground(ResourceManager.makeColorRGBA(38,38,38,255));
			btnBot[i].setBorder(new BevelBorder(BevelBorder.RAISED));
			btnBot[i].setFocusPainted(false);
			btnBot[i].addActionListener(master);
			this.add(btnBot[i]);
		}
		 
		
		btnPart = new JButton[3];
		for(int i=0;i<3;i++)
		{
			btnPart[i] = new JButton();
			btnPart[i].setFont(new Font("", Font.BOLD, 15));
			btnPart[i].setForeground(ResourceManager.makeColorRGBA(212,147,38,255));
			btnPart[i].setBounds(50 + i*130, 350, 130, 23);
			btnPart[i].setBackground(ResourceManager.makeColorRGBA(38,38,38,255));
			btnPart[i].setBorder(new BevelBorder(BevelBorder.RAISED));
			btnPart[i].setFocusPainted(false);
			btnPart[i].addActionListener(master);
			this.add(btnPart[i]);
		}
		
		btnPart[0].setText("WEAPON");
		btnPart[1].setText("TOP");
		btnPart[2].setText("BOTTOM");
		
		
		btnBuild = new JButton("Build");
		btnBuild.setFont(new Font("", Font.BOLD, 15));
		btnBuild.setForeground(ResourceManager.makeColorRGBA(38,38,38,255));
		btnBuild.setBounds(750, 485, 200, 38);
		btnBuild.setBackground(ResourceManager.makeColorRGBA(212,147,38,255));
		btnBuild.setBorder(new BevelBorder(BevelBorder.RAISED));
		btnBuild.setFocusPainted(false);
		btnBuild.addActionListener(master);
		this.add(btnBuild);
		
		btnOut = new JButton("Out");
		btnOut.setFont(new Font("", Font.BOLD, 15));
		btnOut.setForeground(ResourceManager.makeColorRGBA(38,38,38,255));
		btnOut.setBounds(536, 485, 200, 38);
		btnOut.setBackground(ResourceManager.makeColorRGBA(212,147,38,255));
		btnOut.setBorder(new BevelBorder(BevelBorder.RAISED));
		btnOut.setFocusPainted(false);
		btnOut.addActionListener(master);
		this.add(btnOut);
		
		
	
		BotImage = new Canvas()
		{
			
			@Override
			public void paint (Graphics g) {
				g.setColor(ResourceManager.makeColorRGBA(38,38,38,255));
				g.fillRect(0, 0, 300, 200);
				if(bImg != null)
					g.drawImage(bImg,150 - bImg.getWidth(this)/2,100, null);
				if(tImg != null)
					g.drawImage(tImg,150 - tImg.getWidth(this)/2,100 - tImg.getHeight(this), null);
				if(wImg != null)
					g.drawImage(wImg,150 - bImg.getWidth(this)/3 + tImg.getWidth(this)/4,80, null);
			    
			}
		};
        BotImage.setForeground(ResourceManager.makeColorRGBA(212,147,38,255));
        BotImage.setFont(new Font("", Font.BOLD, 20));
        BotImage.setBackground(ResourceManager.makeColorRGBA(45,69,62,255));
        BotImage.setBounds(50, 100, 300, 200);
        add(BotImage);
        
        BotW = new JLabel("Weapon Model : ");
        BotW.setOpaque(true);
        BotW.setHorizontalAlignment(SwingConstants.CENTER);
        BotW.setForeground(ResourceManager.makeColorRGBA(212,147,38,255));
        BotW.setFont(new Font("", Font.BOLD, 20));
        BotW.setBackground(ResourceManager.makeColorRGBA(38,38,38,255));
        BotW.setBounds(364, 100, 586, 38);
        add(BotW);
        
        BotT = new JLabel("Top Model : ");
        BotT.setOpaque(true);
        BotT.setHorizontalAlignment(SwingConstants.CENTER);
        BotT.setForeground(ResourceManager.makeColorRGBA(212,147,38,255));
        BotT.setFont(new Font("", Font.BOLD, 20));
        BotT.setBackground(ResourceManager.makeColorRGBA(38,38,38,255));
        BotT.setBounds(364, 150, 586, 38);
        add(BotT);
        
        BotB = new JLabel("Bottom Model : ");
        BotB.setOpaque(true);
        BotB.setHorizontalAlignment(SwingConstants.CENTER);
        BotB.setForeground(ResourceManager.makeColorRGBA(212,147,38,255));
        BotB.setFont(new Font("", Font.BOLD, 20));
        BotB.setBackground(ResourceManager.makeColorRGBA(38,38,38,255));
        BotB.setBounds(364, 200, 586, 38);
        add(BotB);
        
        BuildResult = new JLabel();
        BuildResult.setOpaque(true);
        BuildResult.setHorizontalAlignment(SwingConstants.CENTER);
        BuildResult.setForeground(ResourceManager.makeColorRGBA(212,147,38,255));
        BuildResult.setFont(new Font("", Font.BOLD, 20));
        BuildResult.setBackground(ResourceManager.makeColorRGBA(38,38,38,255));
        BuildResult.setBounds(50, 485, 472, 38);
        add(BuildResult);
        
        
        
        // ���丮�� ��Ī�Ǵ� ������ ������ֽø� �˴ϴ�.
        wList = new ArrayList<String>();
        wList.add("0.��Ʋ����- �ſ� ���� �߻�, �ſ� ���� ������, ª�� ��Ÿ�, W 1");
        wList.add("1.SplitG7 - ���� �߻�, �߰� ������, �ſ� ª�� ��Ÿ�, W 1");
        wList.add("2.MG84- ���� �߻�, ���� ������, ª�� ��Ÿ�, W 1");
        wList.add("3.��ü����- ���� �߻�, ���� ������, �ſ� �� ��Ÿ�, W 2");
        wList.add("4.M16- ���� �߻�, �߰� ������, �߰� ��Ÿ�, W 2");
        wList.add("5.R.I.P- �߰� �߻�, �߰� ������, �� ��Ÿ�, W 2");
        wList.add("6.Angkimotti- �ſ� ���� �߻�, �ſ� ���� ������, ª�� ��Ÿ�, W 3");
        //modelList.add("��������");
        //modelList.add("������");
        
        tList = new ArrayList<String>();
        tList.add("0.LA_ASS - ü��300, ����ŰƮ 2��, W 1");
        tList.add("1.LA-NOM - ü��230, ����ŰƮ 3��, W 1");
        tList.add("2.LA_SUP - ü��150, ����ŰƮ 5��, W 1");
        tList.add("3.HA_ASS - ü��700, �溮 1��, W 2");
        tList.add("4.HA-NOM - ü��600, �溮 2��, W 2");
        tList.add("5.HA_SUP - ü��400, �溮 4��, W 2");
        tList.add("6.FA_ASS - ü��500, ��ȭ��ġ 1��, W 3");
        tList.add("7.FA-NOM - ü��450, ��ȭ��ġ 3��, W 3");
        tList.add("8.FA_STR - ü��350, ��ȭ��ġ 5��, W 3");
        
        bList = new ArrayList<String>();
        bList.add("0.���� ��Ŀ1 - �ſ� ���� �ӵ�, ���� 3 ���� ����");
        bList.add("1.���� ��Ŀ2 - �ſ� ���� �ӵ�, ���� 4 ���� ����");
        bList.add("2.���� ��Ŀ1 - ���� �ӵ�, ���� 5 ���� ����");
        bList.add("3.���� ��Ŀ2 - ���� �ӵ�, ���� 6 ���� ����");
        bList.add("4.���� ����1 - ���� �ӵ�, ���� ���, ���� 2 ���� ����");
        bList.add("5.���� ����2 - ���� �ӵ�, ���� ���, ���� 3 ���� ����");
        bList.add("6.���� ����3 - ���� �ӵ�, ��Ⱓ ���� ���, ���� 3 ���� ����");
        
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(50, 373, 900, 100);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setBorder(new BevelBorder(BevelBorder.RAISED));
        scrollPane.setBackground(ResourceManager.makeColorRGBA(38, 38, 38, 255));
        add(scrollPane);
        list = new JList();
        scrollPane.setViewportView(list);
        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
       // list.setListData(wList.toArray()); //����Ʈ�� �����Ͱ� �� ��� ����
        list.addListSelectionListener(master);
        list.setBackground(ResourceManager.makeColorRGBA(68,68,68,255));
        list.setFont(new Font("", Font.BOLD, 15));
        list.setForeground(ResourceManager.makeColorRGBA(212,147,38,255));
        
       
	}
	
	public void selectButton(String type, int index)
	{
		if(type.equals("BOT"))
		{
			if(Main.gate.isActivated())
			{
				// ���þȵ� ��ư ����������
				for(int i=0;i<3;i++)
				{
					if(i == index)
					{
						btnBot[i].setForeground(ResourceManager.makeColorRGBA(38,38,38,255));
						btnBot[i].setBackground(ResourceManager.makeColorRGBA(212,147,38,255));
					}
					else
					{
						btnBot[i].setForeground(ResourceManager.makeColorRGBA(212,147,38,255));
						btnBot[i].setBackground(ResourceManager.makeColorRGBA(38,38,38,255));
					}
				}
				robot = index;
				weapon = Main.gate.myW[index];
				top = Main.gate.myT[index];
				bottom = Main.gate.myB[index];
			}
		}
		else if(type.equals("PART"))
		{
			for(int i=0;i<3;i++)
			{
				if(i == index)
				{
					btnPart[i].setForeground(ResourceManager.makeColorRGBA(38,38,38,255));
					btnPart[i].setBackground(ResourceManager.makeColorRGBA(212,147,38,255));
				}
				else
				{
					btnPart[i].setForeground(ResourceManager.makeColorRGBA(212,147,38,255));
					btnPart[i].setBackground(ResourceManager.makeColorRGBA(38,38,38,255));
				}
			}
			switch(index)
			{
			case 0:
				list.setListData(wList.toArray());
				break;
			case 1:
				list.setListData(tList.toArray()); 
				break;
			case 2:
				list.setListData(bList.toArray()); 
				break;
			}
			model = index;
		}
	}
	
	public void botPaint()
	{
		
		if(weapon <3)
		{
			wImg = ResourceManager.getInstance().getMG("R")[0];
		}
		else if(weapon <6)
		{
			wImg = ResourceManager.getInstance().getRifle("R")[0];
		}
		else
		{
			wImg = ResourceManager.getInstance().getRocket("R")[0];
		}
		
		if(top <3)
		{
			tImg = ResourceManager.getInstance().getTopImage()[0];
		}
		else if(top <6)
		{
			tImg = ResourceManager.getInstance().getHeavy()[0];
		}
		else
		{
			tImg = ResourceManager.getInstance().getFlate()[0];
		}
		
		if(bottom <2)
		{
			bImg = ResourceManager.getInstance().getBottomImage()[2];
		}
		else if(bottom <4)
		{
			bImg = ResourceManager.getInstance().getQuad()[2];
		}
		else
		{
			bImg = ResourceManager.getInstance().getCopter()[1];
		}
		BotImage.repaint();
		//BotImage.paint(BotImage.getGraphics());;
	}
	
	public void active(int prevPage)
	{
		
		if(Main.gate.isActivated())
		{
			robot = 0;
			selectButton("BOT",0);
			weapon = Main.gate.myW[0];
			top = Main.gate.myT[0];
			bottom = Main.gate.myB[0];
		
		}
		else
		{
			weapon = 0;
			top = 0;
			bottom = 0;
		}
		botPaint();
		this.prevPage = prevPage;
		activated = true;
		master.getContentPane().add(this);
		master.revalidate();
		master.repaint();
	}
	
	public void inactive()
	{
		BuildResult.setText("");
		activated = false;
		master.remove(this);
		master.revalidate();
		master.repaint();
		
	}
	
	public void buildResult(boolean success)
	{
		if(success)
		{
			BuildResult.setText("BUILD SUCCESS!");
		}
		else
		{
			BuildResult.setText("BUILD FAILED...");
		}
	}
	
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		 // ActionEvent �� �߻���Ų ��ư ��ü�� ��ȯ�Ѵ�
		
		for(int i=0;i<3;i++)
			if(e.getSource() == btnBot[i])
			{
				selectButton("BOT",i);
			}
		
		for(int i=0;i<3;i++)
			if(e.getSource() == btnPart[i])
			{
				selectButton("PART",i);
			}
		
		if(Main.gate.isActivated())
		{
			if(e.getSource() == btnOut)
			{
				switch(prevPage)
				{
				case WAIT1:
					inactive();
					Main.waitr1.active();
					break;
				case WAIT2:
					inactive();
					Main.waitr2.active();
					break;
				}
			}
			else if(e.getSource() == btnBuild)
			{
				Main.gate.sendPak5(robot,weapon,top,bottom);
			}
		}else
		{
			if(e.getSource() == btnOut)
			{
				inactive();
				Main.login.active();
			}
			else if(e.getSource() == btnBuild)
			{
				Main.mctrl.setReceiver(ContainerFactory.genContainer(Sock.TBLUE, 500, 0, 0, weapon, top, bottom));
				inactive();
				Main.camera.getObjList().add(Main.mctrl.getReceiver());
				Main.camera.setViewP(Main.mctrl.getReceiver());
				Main.camera.active();
			}
		}
		
		BotW.setText("Weapon Model : " + weapon);
		BotT.setText("Top Model : " + top);
		BotB.setText("Bottom Model : " + bottom);

		botPaint();
	
	}
	
	public void valueChanged(ListSelectionEvent e) {
		
		
		if(e.getSource() == list)
		{
			int sel =-1;
			String selected = (String) list.getSelectedValue();
			if(selected != null) 
			{
				sel = Integer.parseInt(selected.substring(0, selected.indexOf('.')));
				switch(model)
				{
				case 0:
					weapon = sel;
					break;
				case 1:
					top = sel;
					break;
				case 2:
					bottom = sel;
					break;
				}
				System.out.println(weapon +"/"+top+"/"+bottom);
			}
		}
		
		BotW.setText("Weapon Model : " + weapon);
		BotT.setText("Top Model : " + top);
		BotB.setText("Bottom Model : " + bottom);
		
		botPaint();
	}
	
	boolean isActivated()
	{
		return activated;
	}

}
