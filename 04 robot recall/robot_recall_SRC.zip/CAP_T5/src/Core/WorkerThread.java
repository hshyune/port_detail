package Core;

import java.util.ArrayList;

import Item.Barrier;
import Item.HealPack;
import Item.Item;
import Object.Container;
import Object.ContainerFactory;
import Object.GameObject;
import Object.Projectile.Projectile;

public class WorkerThread implements Runnable {
	
	public static final int ITEM = 1;
	public static final int HEALPACK = 2;
	public static final int BARRIER = 3;
	
	Main master;
	Thread thread;
	int delay;
	Remocon userCtrl[];
	long boxCount = 0;

	WorkerThread() {

	}

	public WorkerThread( Main master) {
		
		userCtrl = new Remocon[6];
		for(int i=0;i<6;i++)
			userCtrl[i] = new Remocon();
		
		this.master = master;
		this.thread = new Thread(this);
		this.delay = 25;


		thread.start();
	}
	
	

	@Override
	public void run() {
		// TODO Auto-generated method stub
		long pretime, nowtime, difftime;
		while (true) {
			try {
				
				pretime = System.currentTimeMillis();
				
				
				
				if(Main.gate.isActivated())
					Main.gate.recv();
				else if(Main.camera.isActivated()&&boxCount >7000)
				{
					System.out.println("box get");
					boxCount = 0;
					Main.camera.getObjList().add(new Item(-1,(int)(Math.random()*1200),0));
				}
					
				
				if(Main.camera.isActivated())
				{
					
					if(!Main.cTextout.isFocusOwner())
					{
						master.requestFocusInWindow();
					}
					
					if(Main.gate.isActivated())
					{
						for(int i=0;i<6;i++)
							userCtrl[i].keyProcess();
					}
					else
					{
						Main.mctrl.keyProcess();
					}
					Main.camera.repaint();
					//master.requestFocusInWindow();
				}
				
				
				
				//master.revalidate();
				//master.repaint();

				nowtime = System.currentTimeMillis();
				difftime = nowtime - pretime;
				if (difftime < delay) {
					boxCount+= delay;
					Thread.sleep(delay - difftime);
				} else {
					boxCount+= difftime;
					Thread.sleep(1);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}
	
	
	
	////////////////////////////////////////////////////////////////////////////////
	// ��Ƽ�÷��̿� Sync �Լ�////////////////////////////////////////////////////////////
	
	
	public void userControl(int index, byte type, byte flag, int syncX, int syncY, int angle)
	{
		
		synchronized (userCtrl[index].getReceiver())
		{
			if(userCtrl[index] != null)
				if(flag ==1)
				{
					userCtrl[index].set((char)type);
					if(syncX >0 && syncY >0)
						userCtrl[index].sync(syncX,syncY,angle);
				}
				else
				{
					userCtrl[index].clear((char)type);
					if(syncX >0 && syncY >0)
						userCtrl[index].sync(syncX,syncY,angle);
				}
		}
		
	//	System.out.println(index +" �κ� ���� : "+ (int)type+(int)flag + "�������� :" +syncX+","+syncY + 
	//		"view point" + Main.camera.getViewP().id + "���� : " + Main.camera.getViewP().getX() + "," + Main.camera.getViewP().getY());
	}
	
	public void userAdd(byte team, int index, int x, int y, int topNum, int bottomNum, int weaponNum)
	{
		Container bot;
		bot = ContainerFactory.genContainer(team,x,y,index, weaponNum, topNum, bottomNum);

		userCtrl[index].setReceiver(bot);
		
		synchronized (Main.camera.getObjList())
		{
			Main.camera.getObjList().add(bot);
		}
	}
	
	
	public void objAdd(byte team, byte foward, int id, int objType, int x, int y)
	{
		synchronized (Main.camera.getObjList())
		{
			switch(objType)
			{
			case 0: // container
				break;
			case ITEM:
				Main.camera.getObjList().add(new Item(id,x,y));
				break;
			case HEALPACK:
				Main.camera.getObjList().add(new HealPack(id,x,y));
				break;
			case BARRIER:
				if(foward ==1)
					Main.camera.getObjList().add(new Barrier(team,id,x + 100, y - 150, true));
				else
					Main.camera.getObjList().add(new Barrier(team,id,x + 100, y - 150, false));
				break;
			}
		}
	}
	
	public void objRemove(int id)
	{
		synchronized (Main.camera.getObjList())
		{
			ArrayList<GameObject> remover = new ArrayList<GameObject>();
			int len;
			for(GameObject g: Main.camera.getObjList())
				if(g.id == id)
					remover.add(g);
			
			len = remover.size();
			for(int i=0;i<len;i++)
			{
					remover.get(i).setHP(0);
					remover.get(i).genAftObj();
					Main.camera.getObjList().remove(remover.get(i));
					System.out.println("��ü ����");
					
			}
		}
	}
	
	
	public void projAdd(int id, int shotX,int shotY, int angle, int remain)
	{
		userCtrl[id].shotSync(shotX,shotY,angle,remain);
	}
	
	public void eventSync(int actor,int reactor,  int point, int vib, byte isUp )
	{
		if(actor == Main.gate.myIndex || reactor == Main.gate.myIndex)
			Main.camera.vib = vib;
		synchronized (Main.camera.getObjList())
		{
			for(GameObject gobj : Main.camera.getObjList())
				if(gobj.id ==  reactor)
					if(isUp==1)
						gobj.hurtSync(point,true);
					else
						gobj.hurtSync(point, false);
		}
	}
	
	
	
}
