package Core;

import java.awt.Font;
import java.awt.event.ActionEvent;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;

import IMG.ResourceManager;

public class ResultPage extends JPanel{

	private Main master;
	private boolean activated;
	
	private ResultCard idCard[];
	private JButton btnOut;
	
	
	public ResultPage(Main master)
	{
		this.master = master;
		activated = false;
		
		idCard = new ResultCard[6];
		for(int i=0;i<6;i++)
		{
			idCard[i]= new ResultCard(i);
			idCard[i].add(this, 25, 60+i*60);
		}

		this.setBounds(0,0,Main.WIDTH,Main.HEIGHT);
		this.setBackground(ResourceManager.makeColorRGBA(19,19,19,255));
		setLayout(null);
		this.master = master;
		
		
		JLabel label1 = new JLabel();
        label1.setOpaque(true);
        label1.setHorizontalAlignment(SwingConstants.CENTER);
        label1.setBorder(new BevelBorder(BevelBorder.RAISED));
        label1.setForeground(ResourceManager.makeColorRGBA(212,147,38,255));
        label1.setFont(new Font("", Font.BOLD, 20));
        label1.setBackground(ResourceManager.makeColorRGBA(38,38,38,255));
        label1.setBounds(25,20,30,40);
        add(label1);
        
        JLabel label2 = new JLabel("ID");
        label2.setOpaque(true);
        label2.setHorizontalAlignment(SwingConstants.CENTER);
        label2.setBorder(new BevelBorder(BevelBorder.RAISED));
        label2.setForeground(ResourceManager.makeColorRGBA(212,147,38,255));
        label2.setFont(new Font("", Font.BOLD, 20));
        label2.setBackground(ResourceManager.makeColorRGBA(38,38,38,255));
        label2.setBounds(55,20,450,40);
        add(label2);
        
        JLabel label3 = new JLabel("KILL /DEATH");
        label3.setOpaque(true);
        label3.setHorizontalAlignment(SwingConstants.CENTER);
        label3.setBorder(new BevelBorder(BevelBorder.RAISED));
        label3.setForeground(ResourceManager.makeColorRGBA(212,147,38,255));
        label3.setFont(new Font("", Font.BOLD, 20));
        label3.setBackground(ResourceManager.makeColorRGBA(38,38,38,255));
        label3.setBounds(505,20,200,40);
        add(label3);
        
        JLabel label4 = new JLabel("ELAPSED DAMAGE");
        label4.setOpaque(true);
        label4.setHorizontalAlignment(SwingConstants.CENTER);
        label4.setBorder(new BevelBorder(BevelBorder.RAISED));
        label4.setForeground(ResourceManager.makeColorRGBA(212,147,38,255));
        label4.setFont(new Font("", Font.BOLD, 20));
        label4.setBackground(ResourceManager.makeColorRGBA(38,38,38,255));
        label4.setBounds(705,20,200,40);
        add(label4);
        
        btnOut = new JButton("OUT");
		btnOut.setFont(new Font("", Font.BOLD, 20));
		btnOut.setForeground(ResourceManager.makeColorRGBA(133,161,144,255));
		btnOut.setBounds(705, 450, 200, 40);
		btnOut.setBackground(ResourceManager.makeColorRGBA(45,69,62,255));
		btnOut.setBorder(new BevelBorder(BevelBorder.RAISED));
		btnOut.setFocusPainted(false);
		btnOut.addActionListener(master);
		this.add(btnOut);
        
	}
	
	public void setResult(int index, int kill, int death, int eDmg)
	{
		idCard[index].setId(Main.waitr2.getUserName(index));
		idCard[index].setScore(kill, death);
		idCard[index].setDeal(eDmg);
	}
	
	public void active()
	{
		activated = true;
		master.getContentPane().add(this);
		master.revalidate();
		master.repaint();
	}
	
	public void inactive()
	{
		activated = false;
		master.remove(this);
		master.revalidate();
		master.repaint();
	}
	
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource() == btnOut)
		{
			inactive();
			Main.waitr2.active();
		}
	}
	
	public boolean isActivated()
	{
		return activated;
	}
	
}
