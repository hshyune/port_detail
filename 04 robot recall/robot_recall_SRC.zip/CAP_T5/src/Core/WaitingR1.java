package Core;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;
import javax.swing.event.ListSelectionEvent;

import IMG.ResourceManager;

public class WaitingR1 extends JPanel{

	private Main master;
	private boolean activated;
	
	private ArrayList<String> roomList; // [id] :: name ���
	private int selRindex;
	
	private JList<String> rJlist;
	private JTextArea cTextin;
	private JTextField rnameout;
	private JButton btnJoin;
	private JButton btnCreate;
	private JButton btnBuild;
	private JButton btnOut;
	
	public WaitingR1(Main master) {
		
		this.setBackground(ResourceManager.makeColorRGBA(19,19,19,255));
		this.setBounds(0,0,Main.WIDTH,Main.HEIGHT);
		setLayout(null);
		this.addKeyListener(master);
		this.master = master;
		
		rnameout = new JTextField();
		rnameout.setBounds(814,388,175,23);
		rnameout.setForeground(ResourceManager.makeColorRGBA(212,147,38,255));
		rnameout.setBackground(ResourceManager.makeColorRGBA(68, 68, 68, 255));
		rnameout.setBorder(new BevelBorder(BevelBorder.RAISED));
		rnameout.setColumns(20);
		rnameout.addKeyListener(master);
		this.add(rnameout);
		
		btnJoin = new JButton("Join ROOM");
		btnJoin.setFont(new Font("", Font.BOLD, 20));
		btnJoin.setForeground(ResourceManager.makeColorRGBA(133,161,144,255));
		btnJoin.setBounds(814, 276, 175, 100);
		btnJoin.setBackground(ResourceManager.makeColorRGBA(45,69,62,255));
		btnJoin.setBorder(new BevelBorder(BevelBorder.RAISED));
		btnJoin.setFocusPainted(false);
		btnJoin.addActionListener(master);
		this.add(btnJoin);
		
		btnCreate = new JButton("Create ROOM");
		btnCreate.setFont(new Font("", Font.BOLD, 20));
		btnCreate.setForeground(ResourceManager.makeColorRGBA(133,161,144,255));
		btnCreate.setBounds(814, 411, 175, 77);
		btnCreate.setBackground(ResourceManager.makeColorRGBA(45,69,62,255));
		btnCreate.setBorder(new BevelBorder(BevelBorder.RAISED));
		btnCreate.setFocusPainted(false);
		btnCreate.addActionListener(master);
		this.add(btnCreate);
		
		btnBuild = new JButton("Build ROBOT");
		btnBuild.setFont(new Font("", Font.BOLD, 20));
		btnBuild.setForeground(ResourceManager.makeColorRGBA(133,161,144,255));
		btnBuild.setBounds(814, 500, 175, 100);
		btnBuild.setBackground(ResourceManager.makeColorRGBA(45,69,62,255));
		btnBuild.setBorder(new BevelBorder(BevelBorder.RAISED));
		btnBuild.setFocusPainted(false);
		btnBuild.addActionListener(master);
		this.add(btnBuild);
		
		btnOut = new JButton("OUT");
		btnOut.setFont(new Font("", Font.BOLD, 20));
		btnOut.setForeground(ResourceManager.makeColorRGBA(133,161,144,255));
		btnOut.setBounds(814, 612, 175, 100);
		btnOut.setBackground(ResourceManager.makeColorRGBA(45,69,62,255));
		btnOut.setBorder(new BevelBorder(BevelBorder.RAISED));
		btnOut.setFocusPainted(false);
		btnOut.addActionListener(master);
		this.add(btnOut);
		
		roomList = new ArrayList<String>();
		//roomList.add("[-1]unground");
		selRindex = -1;
		
		
		
		// ���� ����Ʈ
		
		 JLabel label1 = new JLabel("ROOM LIST");
	     label1.setOpaque(true);
	     label1.setHorizontalAlignment(SwingConstants.CENTER);
	     label1.setBorder(new BevelBorder(BevelBorder.RAISED));
	     label1.setForeground(ResourceManager.makeColorRGBA(133,161,144,255));
	     label1.setFont(new Font("", Font.BOLD, 20));
	     label1.setBackground(ResourceManager.makeColorRGBA(45,69,62,255));
	     label1.setBounds(15, 134, 785, 38);
	     add(label1);
		
		JScrollPane scrollPane1 = new JScrollPane();
		scrollPane1.setBorder(new BevelBorder(BevelBorder.RAISED));
		scrollPane1.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane1.setBackground(ResourceManager.makeColorRGBA(38, 38, 38, 255));
        scrollPane1.setBounds(15, 172, 785, 250);
        add(scrollPane1);
        rJlist = new JList<String>();
        scrollPane1.setViewportView(rJlist);
        rJlist.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        
        rJlist.setListData(roomList.toArray(new String[roomList.size()])); //����Ʈ�� �����Ͱ� �� ��� ����
        rJlist.addListSelectionListener(master);
        rJlist.setBackground(ResourceManager.makeColorRGBA(68,68,68,255));
        rJlist.setFont(new Font("", Font.BOLD, 15));
        rJlist.setForeground(ResourceManager.makeColorRGBA(212,147,38,255));
        
        // ä�� ����Ʈ
        
        JLabel label2 = new JLabel("CHAT LOG");
        label2.setOpaque(true);
        label2.setHorizontalAlignment(SwingConstants.CENTER);
        label2.setBorder(new BevelBorder(BevelBorder.RAISED));
        label2.setForeground(ResourceManager.makeColorRGBA(133,161,144,255));
        label2.setFont(new Font("", Font.BOLD, 20));
        label2.setBackground(ResourceManager.makeColorRGBA(45,69,62,255));
        label2.setBounds(15, 422, 785, 38);
        add(label2);
        
        JScrollPane scrollPane2 = new JScrollPane();
		scrollPane2.setBorder(new BevelBorder(BevelBorder.RAISED));
		scrollPane2.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane2.setBackground(ResourceManager.makeColorRGBA(38, 38, 38, 255));
        scrollPane2.setBounds(15, 460, 785, 230);
        add(scrollPane2);
        
        cTextin = new JTextArea();
		cTextin.setOpaque(true);
		cTextin.setLineWrap(true);
		cTextin.setWrapStyleWord(true);
		cTextin.setEditable(false);
		cTextin.setBackground(ResourceManager.makeColorRGBA(68, 68, 68, 255));
		cTextin.setForeground(ResourceManager.makeColorRGBA(212,147,38,255));
		cTextin.setFont(new Font("����", Font.BOLD, 15));
		cTextin.setBounds(100, 43, 277, 553);
		cTextin.setText("");
		scrollPane2.setViewportView(cTextin);
        
		
		
	}
	
	public void addChatMsg(String msg)
	{
		System.out.println("add chat");
		cTextin.append(msg + "\n");
	}
	
	public void clearrJlist()
	{
		roomList.clear();
	}
	
	public void addrJlist(int id, String name)
	{
		roomList.add("["+id+"]"+name);
	}
	
	public void removerJlist(int id)
	{
		for(int i=0;i<roomList.size();i++)
			if(roomList.get(i).startsWith("["+id+"]"))
			{
				roomList.remove(i);
			}
	}

	public void refreshrJlist()
	{
		rJlist.setListData((roomList.toArray(new String[roomList.size()])));
		rJlist.revalidate();
		rJlist.repaint();
	}
	
	
	public void active()
	{
		activated = true;
		rnameout.setText("");
		
		Main.cTextout.setText("");
		Main.cTextout.setBounds(15, 690, 785, 23);
		this.add(Main.cTextout);
		Main.cTextout.requestFocusInWindow();
		
		master.getContentPane().add(this);
		master.revalidate();
		master.repaint();
		
	}
	
	public void inactive()
	{
		activated = false;
		cTextin.setText("");
		this.remove(Main.cTextout);
		master.remove(this);
		master.revalidate();
		master.repaint();
	}
	
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		 // ActionEvent �� �߻���Ų ��ư ��ü�� ��ȯ�Ѵ�
		if(e.getSource() == btnJoin)
		{
			Main.gate.sendPak3(selRindex);
		}
		else if(e.getSource() == btnCreate)
		{
			Main.gate.sendPak2(rnameout.getText());
		}
		else if(e.getSource() == btnBuild)
		{
			inactive();
			Main.build.active(BuildPage.WAIT1);
		}
		else if(e.getSource() ==btnOut)
		{
			Main.gate.disconnect();
			inactive();
			Main.login.active();
		}
		Main.cTextout.requestFocusInWindow();
	}
	
	public void valueChanged(ListSelectionEvent e) {
	
		if(e.getSource() == rJlist)
		{
			String selected = (String) rJlist.getSelectedValue();
			if(selected == null) selRindex = -1;
			else selRindex = Integer.parseInt(selected.substring(1, selected.indexOf(']')));
			//System.out.println(selRindex);
		}
	}
	
	
	boolean isActivated()
	{
		return activated;
	}

}
