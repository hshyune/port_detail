package Core;

import Object.Container;
import java.util.BitSet;

public class Remocon {
	Container receiver;
	BitSet keyset;

	public Remocon()
	{
		keyset = new BitSet(30);
		this.receiver = null;
	}
	public Remocon(Container container) {
		keyset = new BitSet(30);
		this.receiver = container;
	}

	public void keyProcess() {
		if(receiver != null)
		{
			if(keyset.cardinality()==1)
				singleKeyProcess();
			else
				multiKeyProcess();
		}
	}
	
	public void set(char index)
	{
		keyset.set(index);
	}
	
	public void clear(char index)
	{
		keyset.clear(index);
	}
	
	public void shotSync(int shotX, int shotY, int angle, int remain)
	{
		receiver.getWeapon().setShotLocation(shotX, shotY);
		receiver.getWeapon().setAngle(angle);
		receiver.getWeapon().setCurBullet(remain);
		receiver.getWeapon().shot();
	}
	
	
	public void sync(int x, int y, int angle)
	{
		if(receiver != null)
		{
			synchronized(receiver)
			{
				receiver.dimensionSync(x, y,angle);
			}
		}
	}
	

	// up 0, down 1, left 2, right 3, z 4, x 5, c 6, v 7, space 8
	private void singleKeyProcess() {
		if (keyset.get(0)) {
			// spin angle up
			receiver.spinAngle(true);
		}
		if (keyset.get(1)) {
			// spin angle down
			receiver.spinAngle(false);
		}
		if (keyset.get(2)) {
			// move left
			receiver.move(false);
		}
		if (keyset.get(3)) {
			// move right
			receiver.move(true);
		}
		if (keyset.get(4)) {
			// jump straight
			receiver.jump(false);
		}
		if (keyset.get(5)) {
			receiver.skill();
		}
		if (keyset.get(8)) {
			receiver.shot();
		}
		if (keyset.get(7)) {
			// reload
			receiver.reload();
		}
	}
	

	private void multiKeyProcess() {
		if (keyset.get(0)) {
			// spin angle up
			receiver.spinAngle(true);
		}
		if (keyset.get(1)) {
			// spin angle down
			receiver.spinAngle(false);
		}
		if (keyset.get(2)) {
			// move left
			receiver.move(false);
		}
		if (keyset.get(3)) {
			// move right
			receiver.move(true);
		}
		if (keyset.get(4)) {
			// dirjump
			if (keyset.get(2) || keyset.get(3)) {
				receiver.jump(true);
			}
		}
		if (keyset.get(5)) {
			receiver.skill();
		}
		if (keyset.get(8)) {
			// shot
			receiver.shot();
		}
		if (keyset.get(7)) {
			// reload
			receiver.reload();
		}
	}
	
	public void clear(){
		keyset.clear();
	}

	public Container getReceiver() {
		return this.receiver;
	}

	public void setReceiver(Container receiver) {
		this.receiver = receiver;
	}

}
