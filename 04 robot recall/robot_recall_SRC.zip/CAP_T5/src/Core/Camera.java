package Core;

import java.awt.BasicStroke;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Stroke;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.JTextField;
import javax.swing.border.BevelBorder;

import IMG.ResourceManager;
import Item.HealPack;
import Object.Container;
import Object.GameObject;
import Object.Land;
import Object.Projectile.Projectile;

public class Camera extends Canvas {
	
	Main master;
	boolean activated;
	
	public BufferedImage buff;
	public Graphics2D g2d;
	private Container viewPoint;
	private ArrayList<Projectile> projectileList;
	private ArrayList<GameObject> objectList;
	public int vib = 0;

	private ArrayList<String> cTextin;
	
	protected int observIndex = 0;
	protected boolean gameOver = false;
	protected byte responNum = 11;
	protected long responStart = 0;
	protected long responDelay = 0;
	
	protected byte purScore = 0;
	protected byte score[];
	
	public Camera(Main master) {
		this.master = master;
		activated = false;
		this.projectileList = new ArrayList<Projectile>();
		this.objectList = new ArrayList<GameObject>();
		cTextin = new ArrayList<String>();
		score = new byte[2];

	}
	@Override
	public void paint(Graphics g) {
		if (g2d == null) {
			buff = new BufferedImage(Main.WIDTH, Main.HEIGHT-58, BufferedImage.TYPE_INT_ARGB);
			if (buff != null) {
				g2d = buff.createGraphics();
			}
			return;
		}
		update(g);
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, Main.WIDTH, Main.HEIGHT-58);
	}
	@Override
	public void update(Graphics g) {
		if (g2d == null)
			return;
		updateAll();
		dblpaint();
		g.drawImage(buff, 0, 0, Main.WIDTH, Main.HEIGHT-58, this);
	}
	
	
	public void dblpaint() {
		
		// die state draw
		if(viewPoint == null)
		{
			
			diePaint();
			return;
		}
		
		
		gamePaint();
		uiPaint();
	}
	
	public void diePaint()
	{
		g2d.setColor(ResourceManager.makeColorRGBA(38, 38, 38, 255));
		g2d.fillRect(0, 0, Main.WIDTH, Main.HEIGHT);
		g2d.setColor(Color.RED);
		g2d.drawRect(300, 300, Main.WIDTH-600, 100);
		
		
		g2d.setFont(new Font("", Font.BOLD, 25));
		g2d.drawString("DISCONNECT", Main.WIDTH/2 - 16*5 , 330);
		g2d.setFont(new Font("", Font.BOLD, 15));
		g2d.drawString("respon type : " + (responNum-10) , 320 , 350);
		g2d.drawString("respon time : " + (responDelay-responStart) , 320 , 370);
	}
	
	public void gamePaint()
	{
		// set view Point
		// view point set camera X,Y
		int cameraX = this.viewPoint.getX() - (Main.WIDTH / 2)
				+ (int) (Math.random() > 0.5 ? vib * Math.random() * 10 : -(vib * Math.random() * 10));
		int cameraY = this.viewPoint.getY() - (Main.HEIGHT / 2)
				+ (int) (Math.random() > 0.5 ? vib * Math.random() * 10 : -(vib * Math.random() * 10));
		// draw background
		g2d.drawImage(ResourceManager.getInstance().getBG(), 0, 0, Main.WIDTH, Main.HEIGHT, this);
		// draw Bullets
		synchronized ( projectileList )
		{
			
			for (int i=0;i<projectileList.size();i++)
				projectileList.get(i).draw(g2d, cameraX, cameraY);
		}
		if (vib <= 0) {
			vib = 0;
		} else {
			vib--;
		}
		// draw Objects
		synchronized ( objectList )
		{
			
			for (int i=0;i<objectList.size();i++)
				objectList.get(i).draw(g2d, cameraX, cameraY);
		}
		
	}	
	
	public void uiPaint()
	{
		Stroke s;
		// 1. SCORE VIEW
		
		g2d.setColor(ResourceManager.makeColorRGBA(255, 255, 255, 150));
		if(Main.gate.isActivated())
		{
			// Multi play ui :: [RED SCORE[Purpose Score]BLUE SCORE] 
			g2d.setColor(ResourceManager.makeColorRGBA(38, 38, 38, 150));
			g2d.fillRect(Main.WIDTH/2-150, 0, 300, 130);
			g2d.setColor(ResourceManager.makeColorRGBA(255, 255, 255, 150));
			g2d.setFont(new Font("", Font.BOLD, 30));
			g2d.drawString("SCORE",Main.WIDTH/2- 55, 40);
			g2d.setFont(new Font("", Font.BOLD, 20));
			
			g2d.setColor(ResourceManager.makeColorRGBA(255, 0, 0, 150));
			g2d.drawString("red", Main.WIDTH/2-140, 58);
			g2d.setColor(ResourceManager.makeColorRGBA(0, 148, 255, 150));
			g2d.drawString("blue", Main.WIDTH/2+100, 58);
			g2d.setColor(ResourceManager.makeColorRGBA(255, 255, 255, 150));
			g2d.drawString("purpose", Main.WIDTH/2-36, 58);
			g2d.setFont(new Font("", Font.BOLD, 25));
			g2d.setColor(ResourceManager.makeColorRGBA(255, 0, 0, 150));
			g2d.drawString(Integer.toString(score[Sock.TRED]), Main.WIDTH/2-130, 90);
			g2d.setColor(ResourceManager.makeColorRGBA(0, 148, 255, 150));
			g2d.drawString(Integer.toString(score[Sock.TBLUE]), Main.WIDTH/2+110, 90);
			g2d.setFont(new Font("", Font.BOLD, 35));
			g2d.setColor(ResourceManager.makeColorRGBA(255, 255, 255, 150));
			g2d.drawString(Integer.toString(purScore), Main.WIDTH/2-11, 90);
			
		}
		else
		{
			// Single play ui :: score draw
		}
		
		// RESPON STATE VIEW
		
		if(gameOver)
		{
			s = g2d.getStroke();
			g2d.setStroke(new BasicStroke(10,2,2));
			g2d.setColor(ResourceManager.makeColorRGBA(38, 38, 38, 150));
			g2d.drawArc(Main.WIDTH- 110, 10, 100, 100, 90,240);
			g2d.setColor(ResourceManager.makeColorRGBA(255, 255, 255, 150));
			g2d.drawArc(Main.WIDTH- 110, 10, 100, 100, 90,(int)(240*((double)(responDelay-responStart)/(double)5000)));
			g2d.setStroke(s);
			g2d.setFont(new Font("", Font.BOLD, 25));
			g2d.drawString("Respon", Main.WIDTH- 70, 70);
		}
		
		
		// 3. INTERFACE VIEW

		g2d.setFont(new Font("", Font.BOLD, 25));
		
		int cBullet = viewPoint.getWeapon().getCurBullet();
		g2d.drawRect(Main.WIDTH-200,Main.HEIGHT-160, 150, 10);
		if( cBullet >0)
		{
			g2d.drawString("B : " + cBullet , Main.WIDTH-200,Main.HEIGHT-120);
			g2d.fillRect(Main.WIDTH-200,Main.HEIGHT-160, (int)(150*((double)viewPoint.getWeapon().getShotStart()/(double)viewPoint.getWeapon().getShotDelay())), 10);
		}
		else
		{
			g2d.drawString("Reloading...",Main.WIDTH-200,Main.HEIGHT-120);
			g2d.fillRect(Main.WIDTH-200,Main.HEIGHT-160, (int)(150*((double)viewPoint.getWeapon().getReloadStart()/(double)viewPoint.getWeapon().getReloadDelay())), 10);
		}
		g2d.drawString("S : " +  viewPoint.getTop().getCurSkill(), Main.WIDTH-200,Main.HEIGHT-70);
		g2d.drawRect(Main.WIDTH-200,Main.HEIGHT-110, 150, 10);
		g2d.fillRect(Main.WIDTH-200,Main.HEIGHT-110, (int)(150*((double)viewPoint.getTop().getSkillStart()/(double)viewPoint.getTop().getSkillDelay())), 10);
	
	
		s = g2d.getStroke();
		g2d.setStroke(new BasicStroke(10,2,2));
		g2d.setColor(ResourceManager.makeColorRGBA(38, 38, 38, 150));
		g2d.drawArc(Main.WIDTH- 350, Main.HEIGHT-170, 100, 100, 90,240);
		g2d.setColor(ResourceManager.makeColorRGBA(255, 255, 255, 150));
		g2d.drawArc(Main.WIDTH- 350, Main.HEIGHT-170, 100, 100, 90,(int)(240*((double)viewPoint.getHP()/(double)viewPoint.getMaxHP())));
		g2d.setStroke(s);
		g2d.setFont(new Font("", Font.BOLD, 45));
		g2d.drawString(Integer.toString(viewPoint.getHP()), Main.WIDTH- 310, Main.HEIGHT-115);
		
		//4. CHAT VIEW
		g2d.setFont(new Font("", Font.BOLD, 12));
		
		for(int i=0;i<cTextin.size();i++)
		{
			g2d.drawString(cTextin.get(i),10, Main.HEIGHT-100 - i*11);
		}
		

		
	}
	
	
	public void setViewP(Container obj) {
		this.viewPoint = obj;
	}
	
	public void setViewP(int id)
	{
		
		synchronized (Main.camera.getObjList())
		{
			setViewP(Main.wt.userCtrl[id].getReceiver());
		}
	}
	
	public void swapViewP(boolean right)
	{
		if(right)
		{
			do
			{
				if(observIndex==5) observIndex = 0;
				else observIndex ++;
				setViewP(observIndex);
			}while(viewPoint == null);
			
		}
		else
		{
			do
			{
				if(observIndex==0) observIndex = 5;
				else observIndex --;
				setViewP(observIndex);
			}while(viewPoint == null);
		}
		
	}
	
	public void clearViewP()
	{
		viewPoint = null;
	}
	
	public GameObject getViewP()
	{
		return viewPoint;
	}

	public ArrayList<GameObject> getObjList() {
		return this.objectList;
	}

	public ArrayList<Projectile> getProjList() {
		return this.projectileList;
	}

	
	public void updateForSingle(){
		// implements isCollision()
		

		// healpack
		for (GameObject lhs : objectList) {
			if (lhs instanceof HealPack) {
				for (GameObject rhs : objectList) {
					if(rhs instanceof Container){
						if(((Container) rhs).isCollision((HealPack)lhs)){
							((Container) rhs).isHeal((HealPack) lhs);
						}
					}
				}
			}
		}
	}
	
	public void updateForMulti(){
		
		
		if(gameOver)
		{
			responStart = System.currentTimeMillis();
			if(responStart >= responDelay)
			{
				gameOver = false;
				Main.gate.sendPak10(responNum);
			}
		}
		else if(Main.wt.userCtrl[Main.gate.myIndex].getReceiver().getHP()<=0 )
		{
			gameOver = true;
			clearViewP();
			responStart = System.currentTimeMillis();
			responDelay = System.currentTimeMillis()+5000;
		}
		
		
	}
	
	public void updateAll() {
			
		
		int size; 
		synchronized ( objectList )
		{
		
			size = this.objectList.size();
			for (int i = 0; i < size; i++) {
				if (objectList.get(i).update()) {
					if(!Main.gate.isActivated())
					{
						objectList.get(i).genAftObj();
						objectList.remove(i);
						i--;
						size--;
					}
				}
			}
		
		}
		
		synchronized ( projectileList )
		{
		
			size = this.projectileList.size();
			for (int i = 0; i < size; i++) {
				if (projectileList.get(i).update()) {
					projectileList.get(i).genAftObj();
					projectileList.remove(i);
					i--;
					size--;
				}
			}
		}
		
		// shot
		size = this.projectileList.size();
		for (int i = 0; i < size; i++) 
			projectileList.get(i).attack();
		
		if(!Main.gate.isActivated())
		{
			updateForSingle();
		}
		else
		{
			updateForMulti();
		}
		
	}
	
	public void landSetting()
	{
		//bottom
		objectList.add(new Land(0, 700, 500, 37));
		objectList.add(new Land(460, 650, 300, 20));
		objectList.add(new Land(800, 650, 300, 20));
		objectList.add(new Land(1050, 700, 580, 37));
						
		//mid
		objectList.add(new Land(50, 620, 200, 30));
		objectList.add(new Land(50, 500, 200, 30));
		objectList.add(new Land(230, 570, 170, 20));
		objectList.add(new Land(450, 530, 650, 37));
		objectList.add(new Land(1100, 600, 150, 20));
		objectList.add(new Land(1230, 650, 200, 20));
		objectList.add(new Land(1350, 560, 280, 30));
							
		//top
		objectList.add(new Land(80, 430, 100, 20));
		objectList.add(new Land(160, 360, 250, 30));
		objectList.add(new Land(400, 420, 200, 20));
		objectList.add(new Land(580, 350, 350, 30));
		objectList.add(new Land(900, 450, 350, 30));
		objectList.add(new Land(1280, 380, 350, 30));
				
	}
	
	public void active()
	{
		landSetting();
		Main.camera.setBounds(0,0,Main.WIDTH,Main.HEIGHT-58);
		Main.cTextout.setBounds(0,Main.HEIGHT-58,Main.WIDTH,23);
		master.getContentPane().add(Main.camera);
		master.add(Main.cTextout);
		activated = true;
	}
	
	public void inactive()
	{
		for(int i=0;i<6;i++)
			Main.wt.userCtrl[i].clear();
		master.remove(Main.camera);
		master.remove(Main.cTextout);
		Main.camera.getObjList().clear();
		Main.camera.getProjList().clear();
		activated = false;
	}
	
	public boolean isActivated()
	{
		return activated;
	}
	
	public void setResponNum(int num)
	{
		responNum = (byte)num;
	}
	
	public void setScore(byte p, byte r, byte b)
	{
		purScore = p;
		score[Sock.TRED] = r;
		score[Sock.TBLUE] =b;
	}
	
	public ArrayList<String> getCTextin()
	{
		return cTextin;
	}
	
}
